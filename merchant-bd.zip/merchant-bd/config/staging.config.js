// 预发布环境

module.exports = {
    NODE_ENV: 'production',
    BASE_API: '//msinner.jr.jd.com/gw/generic/bt/h5/m'
}
