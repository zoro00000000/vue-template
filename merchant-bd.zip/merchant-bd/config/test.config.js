// 测试环境

module.exports = {
    NODE_ENV: 'development',
    BASE_API: '//mstest.jr.jd.com/gw/generic/bt/h5/m'
}
