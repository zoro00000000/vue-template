// 线上环境

module.exports = {
    NODE_ENV: 'production',
    BASE_API: '//ms.jr.jd.com/gw/generic/bt/h5/m'
}
