/**
 * WebviewTester
 * 检测是否处于 webview 内
 * 2019/09/02
 */
export default {
    isInThirdPartWebview () {
        return (this.isInMicroMessenger()
            || this.isInQQ()
            || this.isInWeibo()
            || this.isInJdApp()
            || this.isInJdJrApp())
            && !this.isInYocial()
    },

    isInWebview () {
        return this.isInThirdPartWebview()
            || this.isInYocial()
    },

    isInMicroMessenger () {
        return /MicroMessenger/i.test(navigator.userAgent)
    },

    isInQQ () {
        return /\sQQ/.test(navigator.userAgent)
    },

    isInWeibo () {
        return /Weibo/i.test(navigator.userAgent)
    },

    isInYocial () {
        return /yocial/i.test(navigator.userAgent)
    },

    isInJdApp () {
        // https://cf.jd.com/pages/viewpage.action?pageId=163683133
        return /^jdapp\W/.test(navigator.userAgent)
    },

    isInJdJrApp () {
        // https://cf.jd.com/pages/viewpage.action?pageId=181277416
        return /JDJR-App/.test(navigator.userAgent)
    },

    isIE () {
        const ua = navigator.userAgent

        const msie = ua.indexOf('MSIE ')
        if (msie > 0) {
            // IE 10 or older => return version number
            return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10)
        }

        const trident = ua.indexOf('Trident/')
        if (trident > 0) {
            // IE 11 => return version number
            const rv = ua.indexOf('rv:')
            return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10)
        }

        const edge = ua.indexOf('Edge/')
        if (edge > 0) {
            // Edge (IE 12+) => return version number
            return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10)
        }

        // other browser
        return false
    },

    isAppleDevices () {
        return /ipad|iphone|ipod|Macintosh/ig.test(navigator.userAgent)
    },

    isAndroidDevices () {
        return /Android/ig.test(navigator.userAgent)
    }
}
