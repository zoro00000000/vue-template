/**
 * 
 * 自定义校验
 */

// 去除空格校验
export const validatorSpace = value => {
    const pattern = new RegExp(/^\s+|\s+$/g)
    if (pattern.test(value)) {
        // this.$toast('请输入非空格内容')
        // callback('请输入非空格内容')
        return false
    }
    return true
}

// 身份证校验
export const validatorIdCard = value => {
    const id = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|30|31)|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}([0-9]|x|X)$/
    if (!id.test(value)) {
        // this.$toast('身份证号码不正确')
        // callback('身份证号码不正确')
        return false
    }
    return true
}

// 邮箱校验
export const validatorEmail = value => {
    if (!value) return false
    // const reg = new RegExp('^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$')
    const reg = /^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/
    if (!reg.test(value)) {
        // this.$toast('邮箱格式错误')
        return false
    }
    return true
}

// 手机号校验
export const validatorPhone = value => {
    if (!value) return false
    const reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/
    if (!reg.test(value)) {
        return false
    }
    return true
}

// 座机校验
export const validatorTel = value => {
    if (!value) return false
    const regTel = /^([0-9]{3,4}-)?[0-9]{7,8}$/
    const regPhone = /^[1][3,4,5,6,7,8,9][0-9]{9}$/
    if (regTel.test(value) || regPhone.test(value)) {
        // console.log('tel:', !regTel.test(value))
        return true
    }
    return false
}
