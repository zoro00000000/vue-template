export function setupWebViewJavascriptBridge (callback) {
    if (window.WebViewJavascriptBridge) {
        return callback(window.WebViewJavascriptBridge)
    }
    if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback)
    }
    const WVJBIframe = document.createElement('iframe')

    window.WVJBCallbacks = [callback]
    document.addEventListener('WebViewJavascriptBridgeReady', () => {
        const tasks = window.WVJBCallbacks || []

        window.WVJBCallbacks = []
        tasks.forEach(cb => cb(window.WebViewJavascriptBridge))
    })
    WVJBIframe.style.display = 'none'
    WVJBIframe.src = 'https://__bridge_loaded__'
    document.documentElement.appendChild(WVJBIframe)
    setTimeout(() => {
        document.documentElement.removeChild(WVJBIframe)
    }, 0)
}

export function callHandler (name, data, callback) {
    if (!callback) {
        callback = ''
    }
    setupWebViewJavascriptBridge(bridge => {
        bridge.callHandler(name, data, callback)
    })
}

/**
 * 调用Native函数
 * @param name
 * @param data
 * @param options
 * @return {Promise<any>}
 */
export function callNative (name, data, options = {
    timeout: 0
}) {
    return new Promise((resolve, reject) => {
        let id

        if (options.timeout) {
            id = setTimeout(() => reject('timeout'), options.timeout)
        }

        setupWebViewJavascriptBridge(bridge => {
            // 数据返回可能是 JS Object 或者 String
            bridge.callHandler(name, data, res => {
                if (id) clearTimeout(id)

                try {
                    resolve((res && typeof res === 'string')
                        ? JSON.parse(res)
                        : res)
                } catch (e) {
                    reject(e)
                }
            })
        })
    })
}

/**
 * 注册Native事件监听函数
 * @param name
 * @param {(data: any, cb?:function) => void} resolve - 回调函数
 */
export function handleNativeCall (name, resolve) {
    setupWebViewJavascriptBridge(bridge => {
        bridge.registerHandler(name, resolve)
    })
}

export function registerHandler (name, shareData) {
    setupWebViewJavascriptBridge(bridge => {
        /* eslint-disable-next-line */
        bridge.registerHandler(name, function (datas, responseCallback) {
            if (responseCallback) {
                responseCallback(datas)
            }

            callNative('jsCallShare', {
                ...shareData
            })
        })
    })
}

// https://cf.jd.com/pages/viewpage.action?pageId=265629986
// 默认支持类型：1:微信好友；2：微信朋友圈；3:QQ；4:QQ空间； 5:微博；
// 注意，iOS： number， Android：string

export const SHARE_TYPES = {
    wechat: 1,
    wechatMoments: 2,
    qq: 3,
    qqMoments: 4,
    weibo: 5
}
export default {
    callHandler
}
