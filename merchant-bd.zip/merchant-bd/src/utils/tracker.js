// 奇点 2.0 埋点方法

/**
 * 点击事件 埋点
 *
 * @export
 * @param {*} cls
 * @param {*} [data={}]
 */
export function log (cls, data = {}) {
    if (!window.__qd__) return

    try {
        window.__qd__.click({
            cls,
            v: {
                ...data
            }
        })
    } catch (e) {
        console.log(e)
    }
}

/**
 * 曝光埋点
 *
 * @export
 * @param {*} cls
 * @param {*} [data={}]
 */
export function imp (cls, data = {}) {
    if (!window.__qd__) return

    try {
        window.__qd__.imp({
            cls,
            v: {
                ...data
            }
        })
    } catch (e) {
        console.log(e)
    }
}

/**
 * 打开页面埋点
 *
 * @export
 * @param {*} [data={}]
 */
export function page (data = {}) {
    if (!window.__qd__) return

    try {
        window.__qd__.page({
            ...data
        })
    } catch (e) {
        console.log(e)
    }
}

/**
 * 关闭页面埋点
 *
 * @export
 * @param {*} [data={}]
 */
export function closePage (data = {}) {
    if (!window.__qd__) return

    try {
        window.__qd__.closePage({
            ...data
        })
    } catch (e) {
        console.log(e)
    }
}
