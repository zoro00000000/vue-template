// 从 url 上获取？后面的参数

const ESC = {
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    '&': '&amp;'
}

// 特殊字符转换
const escapeChar = a => ESC[a] || a

export const escape = s => s.replace(/[<>"&]/g, escapeChar)

export const getQueryParams = url => {
    const queryObj = {}
    const params = new URL(url).searchParams

    for (const [key, value] of params) {
        queryObj[key] = escape(value)
    }

    return queryObj
}
