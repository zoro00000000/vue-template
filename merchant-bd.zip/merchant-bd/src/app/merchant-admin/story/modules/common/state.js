/**
 * 公共数据
 */

const state = {
    commonData: {
        test: 1,
        demo: 2
    }
}

export default state
