/**
 * 获取vuex commonData
 * @param {*} state 
 */

export const commonData = state => state.commonData
