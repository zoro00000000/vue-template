import axios from 'axios'
import filterRepetition from './filterRepetition'

// eslint-disable-next-line import/no-dynamic-require
const configEnv = require(`@config/${process.env.VUE_APP_BUILD_ENV}.config`)
const apiHostname = configEnv.BASE_API
// const apiHostname = '//mstest.jr.jd.com/gw/generic/bt/h5/m'

console.log('apiHostname:', apiHostname)

// 创建 axios 对象
const instance = axios.create({
    baseURL: configEnv.BASE_API,
    // baseURL: '//mstest.jr.jd.com/gw/generic/bt/h5/m',
    timeout: 5000,
    withCredentials: true
})

// 设置全局的请求次数、请求间隙
instance.defaults.retry = 3
instance.defaults.retryDelay = 1000

// 防止重复请求
export const reqList = []

/**
 * 阻止重复请求
 * @param {array} reqList - 请求缓存列表
 * @param {string} url - 当前请求地址
 * @param {function} cancel - 请求中断函数
 * @param {string} errorMessage - 请求中断时需要显示的错误信息
 */
const stopRepeatRequest = (requestList, url, cancel, errorMessage) => {
    const errorMsg = errorMessage || ''
    for (let i = 0; i < requestList.length; i++) {
        if (requestList[i] === url && (filterRepetition.indexOf(url.replace(`${apiHostname}/`, ''))) >= 0) {
            cancel(errorMsg)
            return
        }
    }
    reqList.push(url)
}

/**
 * 允许某个请求可以继续进行
 * @param {array} reqList 全部请求列表
 * @param {string} url 请求地址
 */
const allowRequest = (requestList, url) => {
    for (let i = 0; i < requestList.length; i++) {
        if (requestList[i] === url) {
            reqList.splice(i, 1)
            break
        }
    }
}

// 添加 请求拦截器  
// 接口 请求前拦截
instance.interceptors.request.use(config => {
    let cancel
    // 设置cancelToken对象
    config.cancelToken = new axios.CancelToken((c => {
        cancel = c
    }))
    // 阻止重复请求。当上个请求未完成时，相同的请求不会进行
    stopRepeatRequest(reqList, config.url, cancel, `${config.url} 请求被中断`)
    // TODO: 可以做一些请求前的 统一配置处理
    if (config.config) {
        for (const item in config.config) {
            config[item] = config.config[item]
        }
        if (config.config.cache) {
            config.url += /\?/g.test(config.url) ? `&_=${new Date().getTime()}` : `?_=${new Date().getTime()}`
        }
    }

    // TODO: 针对 请求类型做 处理
    if (config.method === 'post') {
        console.log('post')
    } else if (config.method === 'get') {
        console.log('get')
    }

    // ! 针对于 JD 的网关层做的特殊处理 接口入参必须是这种格式
    config.data = `reqData=${JSON.stringify(config.data)}`

    return config
}, error => Promise.reject(error))

// 接口 请求后拦截
instance.interceptors.response.use(response => {
    // 增加延迟，相同请求不得在短时间内重复发送
    setTimeout(() => {
        allowRequest(reqList, response.config.url)
    }, 100)

    // ! 网关层处理
    const result = response.data
    const always = (response.config.config && response.config.config.always) ? response.config.config.always : false
    
    // 网关接口响应失败
    if (!always) {
        if (result.resultCode && result.resultCode !== 0) {
            // 未登录
            if (result.resultCode === 3) {
                console.log('未登陆')
                // const localUrl = encodeURIComponent(`${window.location.protocol}//${window.location.host}${window.location.pathname}#/business/performance/company`)
                // const newUrl = `//plogin.m.jd.com/user/login.action?appid=566&wxautologin=false&returnurl=${localUrl}`
                // window.location.href = newUrl
                return result
            } else {
                console.log('系统异常，请稍后重试~~')
            }
            return false
        }
    }
    // TODO: 做一些请求成功后的处理 比如 回参 的状态码处理
    
    return result
}, error => {
    // 请求错误时做些事
    if (axios.isCancel(error)) {
        console.log(error.message)
    } else {
        // 增加延迟，相同请求不得在短时间内重复发送
        setTimeout(() => {
            allowRequest(reqList, error.config.url)
        }, 100)

        return Promise.reject(error)
    }
})

// 暴露出方法
export const fetch = instance
