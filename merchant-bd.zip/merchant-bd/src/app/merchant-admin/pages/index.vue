<template>
    <div class="main-container">
        <div class="main-title">merchant-admin main 首页</div>
        <div @click="jumpPage('/test')">点击跳转到 test admin项目页面</div>
        <div @click="jumpPage('/demo')">点击跳转到 demo admin项目页面</div>
    </div>
</template>

<script>
    // import configEnv from '../../config/dev.env'
    import api from '../api'
    
    export default {
        created () {
            console.log('process.env:', process.env.VUE_APP_BUILD_ENV)
            console.log(api)
            // const configEnv = require([`../../config/${process.env.VUE_APP_BUILD_ENV}.env`], resolve)
            // console.log('process.env:', process.env.VUE_APP_BUILD_ENV)
            // const apiHostname = configEnv.BASE_API
            // console.log('apiHostname:', apiHostname)
            api.main.mainDemoInfo({ data: 1 }).then(res => {
                console.log(res)
            })
        },
        methods: {
            jumpPage (path) {
                this.$router.push({
                    path
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .main-container {
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: aliceblue;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;

        .main-title {
            font-size: 0.2rem;
            color: #000000;
            box-sizing: content-box;
        }
    }
</style>
