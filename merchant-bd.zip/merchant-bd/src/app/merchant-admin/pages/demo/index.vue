<template>
    <div class="demo-container">
        <div class="demo-title">demo 项目页面</div>
        <div @click="jumpPage">点击跳转到 test 页面</div>
    </div>
</template>

<script>
    export default {
        methods: {
            jumpPage () {
                this.$router.push({
                    path: '/test'
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .demo-container {
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: aliceblue;

        .demo-title {
            font-size: 0.2rem;
            color: #000000;
        }
    }
</style>
