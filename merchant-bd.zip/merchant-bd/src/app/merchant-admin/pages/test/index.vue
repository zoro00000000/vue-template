<template>
    <div class="test-container">
        <div class="test-title">test 页面</div>
        <div @click="jumpPage">点击跳转到 demo 页面</div>
    </div>
</template>

<script>
    export default {
        methods: {
            jumpPage () {
                this.$router.push({
                    path: '/demo'
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .test-container {
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: aliceblue;

        .test-title {
            font-size: 0.2rem;
            color: #000000;
        }
    }
</style>
