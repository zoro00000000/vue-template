/**
 * ! 路由
 * ? main
 * @param {}
 */

const mainComponent = () => import('../../pages')

const router = [
    {
        path: '*',
        name: '/main',
        component: mainComponent,
        meta: {
            keepAlive: false,
            title: 'admin 项目首页'
        }
    }
]

export default router
