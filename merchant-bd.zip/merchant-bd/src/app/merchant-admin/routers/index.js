import Vue from 'vue'
import VueRouter from 'vue-router'
import routes from './routes'

Vue.use(VueRouter)

const routerPage = new VueRouter({
    routes
})

// 新增路由拦截
routerPage.beforeEach((to, from, next) => {
    console.log('路由拦截beforeEach：', to, from)
    next()
})

routerPage.afterEach((to, from) => {
    console.log('路由拦截afterEach：', to, from)
    // 路由请求后处理
    const title = to.meta.title || 'liong-cli'
    document.title = title
})

export default routerPage
