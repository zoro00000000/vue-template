import Vue from 'vue'
import router from './routers'
import store from './story'
import App from './App.vue'

console.log('process.env.VUE_APP_BUILD_ENV', process.env.VUE_APP_BUILD_ENV)
new Vue({
    render: h => h(App),
    router,
    store
}).$mount('#app')
