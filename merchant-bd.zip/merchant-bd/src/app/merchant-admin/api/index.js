// 合并所有接口
import * as main from './main'

console.log(main)

export default {
    main
}
