import { fetch } from '../server'

// const configEnv = require(`../../config/${process.env.VUE_APP_BUILD_ENV}.config`)
// const apiHostname = configEnv.BASE_API

/**
 * liong-cli
 * ?接口（0.0）
 * 测试接口
 * @export
 * @param {*} param
 * @returns
 */

export const mainDemoInfo = param => fetch({
    // url: `${apiHostname}/queryAgentMerchantBaseInfo`,
    url: '/queryBDStaffInfoByPin',
    method: 'post',
    data: param
    // data: `reqData=${JSON.stringify(param)}`
})
