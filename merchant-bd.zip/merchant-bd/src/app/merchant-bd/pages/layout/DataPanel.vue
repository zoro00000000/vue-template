<template>
    <div class="main" @click="go">
        <div class="text-top">
                {{number}}
        </div>
        <div class="text-bottom">
                {{desc}}
        </div>
    </div>
</template>

<script>
    export default {
        name: 'DataPanel',
        props: ['number', 'desc'],
        methods: {
            go () {
                this.$emit('go')
            }
        }
    }
</script>

<style lang="scss" scoped>
    .main {
        width: 1rem;
        height: .6rem;
        background-color: white;
        text-align: center;

        .text-top{
            width: 1rem;
            height: .3rem;
            font-size: .15rem;
            display: table-cell;
            vertical-align: bottom;
        }

        .text-bottom{
            width: 100%;
            height: .3rem;
            line-height: .3rem;
            font-size: .14rem;
            color: #BBBBBB;
        }
    }
</style>
