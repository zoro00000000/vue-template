<template>
    <div class="main" :class="mb? 'border': ''" @click="clickHandle">
        <div v-if="alias">
            <!--  title 分上线  content 分上下       -->
            <div class="icon">
                <!--  用户头像  -->
                <img :src="icon">
            </div>
            <div class="report_cell_define">
                <cell-group :border="false">
                    <cell clstag="jr|keycount|dl_qyyj|wdsj" size="large" is-link label-class="label" :label="duty" :value="sum" :border="false">
                        <template slot="title">
                            <!-- <span class="user-name" style="font-size: .16rem;color: #2E2D2F">{{name}}</span>
                            <img class ="icon-phone" @click.stop="phoneClickHandle" src="@/assets/img/icon_phone.png" alt="">
                            <span style="font-size: .14rem;color: #848484">&nbsp;{{comment}}条评论</span> -->
                            <div class="user-info-box">
                                <div class="user-name" style="font-size: .16rem;color: #2E2D2F">{{name}}</div>
                                <div class="user-icon-box">
                                    <img class="icon-phone" @click.stop="phoneClickHandle" src="@/merchant-bd/assets/img/icon_phone.png" alt="">
                                </div>
                                <div class="user-comments" style="font-size: .14rem;color: #848484">&nbsp;{{comment}}条评论</div>
                            </div>
                        </template>
                        <template slot="default">
                            <div class="cell-status">
                                <div>
                                    <span style="font-size: .15rem;color: #F0250F;font-weight: 500;">
                                        {{status}}
                                    </span>
                                </div>
                                <div>
                                    <span style="font-size: .14rem;color: #BBBBBB;">
                                        {{date}}
                                    </span>
                                </div>
                            </div>
                        </template>
                    </cell>
                </cell-group>
            </div>
            <div style="clear: both"></div>
        </div>

        <!--  title 在中间  content 分上下       -->
        <div v-else-if="normal" class="normal_cell_define">
            <cell :title="name" size="large" >
                <template slot="default">
                    <div>
                        <div style="text-overflow: ellipsis; white-space: nowrap; overflow: hidden; color: #848484;">
                            <span style="font-size: .16rem; color: #848484; font-weight: 500;">
                                {{contentTop}}
                            </span>
                        </div>
                        <div>
                            <span style="font-size: .14rem;color: #BBBBBB;">
                                {{contentBottom}}
                            </span>
                        </div>
                    </div>
                </template>
            </cell>
        </div>

        <div v-else-if="one" class="one_cell_define">
            <cell size="large" :value="date">
                <template slot="title">
                    <div class="title">
                        {{name}}
                        <div class="tips" @click="tips" v-if="tipText">
                            <van-icon name="warning-o" color="#F0250F"/>
                        </div>
                    </div>
                </template>
            </cell>
        </div>
        <!--  组件默认行为  并有头像框  大区专员 + 省专员样式     -->
        <div v-else>
            <div class="icon">
                <img :src="icon">
            </div>
            <div class="report_cell">
                <cell-group>
                    <cell :title="name" :value="hasNext ? sum:''" size="large" :label="duty"  :is-link="hasNext">
                        <button v-if="exit" class="cell_button_style" @click="clickChange($event)">退出登录</button>
                    </cell>
                </cell-group>
            </div>
            <div style="clear: both"></div>
        </div>
    </div>
</template>

<script>
    import { Cell, CellGroup } from 'vant'

    export default {
        name: 'iteam',
        components: {
            Cell,
            CellGroup
        },
        props: {
            contentTop: {
                type: String,
                default () {
                    return ''
                }
            },
            contentBottom: {
                type: String,
                default () {
                    return ''
                }
            },
            name: {
                type: String,
                default () {
                    return ''
                }
            },
            comment: {
                // type: String,
                default () {
                    return ''
                }
            },
            tel: {
                type: String,
                default () {
                    return ''
                }
            },
            mb: {
                type: Boolean,
                default () {
                    return false
                }
            },
            duty: {
                // name下方文字
                type: String,
                default () {
                    return '暂无信息'
                }
            },
            sum: {
                type: [String, Number],
                default () {
                    return 0
                }
            },
            alias: {
                type: Boolean,
                default () {
                    return false
                }
            },
            normal: {
                type: Boolean,
                default () {
                    return false
                }
            },
            one: {
                type: Boolean,
                default () {
                    return false
                }
            },
            tipText: {
                type: String,
                default: ''
            },
            icon: {
                type: String,
                default: ''
            },
            status: {
                type: String,
                default: ''
            },
            date: {
                type: String,
                default: ''
            },
            hasNext: {
                type: Boolean,
                default: true
            },
            exit: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            tips () {
                this.$dialog.alert({
                    message: this.tipText
                }).then(() => {
                    // on close
                })
            },
            clickHandle () {
                console.log('click')
                this.$emit('click')
            },
            phoneClickHandle () {
                this.$emit('phoneClick')
            },
            clickChange (e) {
                // 阻止冒泡事件
                e.stopPropagation()
                this.$emit('exitEvent', true)
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import "../../assets/css/_mixin.scss";
    .main {
        width: 100%;
        height: .8rem;
        font-size: .15rem;
        border-bottom: 1px solid rgba(204, 204, 204, .2);
        //@include border-1px-bottom();
        /*box-shadow:0px 0.02rem 0.05rem 0px rgba(238,241,244,1);*/

        .tips {
            display: inline;
            vertical-align: middle;
        }

        /deep/ .van-ellipsis {
            font-size: 0.15rem;
        }

        .label{
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            -ms-text-overflow: ellipsis;
        }
        .icon-phone{
            width: .15rem;
            height: .15rem;
            // vertical-align: middle;
            margin-left: .1rem;
            vertical-align: top;
        }
        .icon {
            height: .8rem;
            width: 15%;
            float: left;
            text-align: right;
            background-color: white;

            img{
                width: 0.5rem;
                height: .5rem;
                margin-top: .16rem;
            }
        }
        .one_cell_define {
            width: 100%;
            height: .5rem;
            float: left;

            /deep/ .van-cell__title {
                flex: 1;
                -webkit-flex: 1;
                -webkit-box-flex: 1;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/ .van-cell__title span {
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/.van-cell {
                height: .8rem;
            }

            /deep/.van-cell--large {
                padding-top: .16rem;
            }

            /deep/.van-cell__title {
                line-height: .56rem;
            }

            /deep/.van-cell__value {
                line-height: .56rem;
                color: #BBBBBB
            }

            /deep/.van-cell__right-icon {
                line-height: .56rem;
            }
        }
        .normal_cell_define{
            width: 100%;
            height: .5rem;
            background-color: #2c3e50;
            float: left;

            /deep/ .van-cell__title {
                flex: 2;
                -webkit-flex: 2;
                -webkit-box-flex: 2;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/ .van-cell__title span {
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/.van-cell {
                height: .8rem;
            }

            /deep/.van-cell__title {
                line-height: .54rem;
            }

            /deep/.van-cell--large {
                padding-top: .16rem;
            }

            /deep/.van-cell__value {
                color: red;
            }

            /deep/.van-cell__right-icon {
                line-height: .56rem;
            }
        }
        .report_cell_define{
            width: 85%;
            height: .5rem;
            background-color: #2c3e50;
            float: left;
            padding: auto;

            /deep/ .van-cell__title {
                flex: 2;
                -webkit-flex: 2;
                -webkit-box-flex: 2;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                justify-content: center;
                // align-items: center;
            }
            
            /deep/ .van-cell__title span {
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/.van-cell-group {
                height: .8rem;
            }

            /deep/.van-cell {
                height: .8rem;
            }

            /deep/.van-cell--large {
                padding-top: .16rem;
            }

            /deep/.van-cell__value {
                color: red;
            }

            /deep/.van-cell__right-icon {
                line-height: .52rem;
            }

            .user-info-box {
                display: flex;
                align-items: center;

                .user-name {
                    width: 2rem;
                    line-height: 0.16rem;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    overflow: hidden;
                }

                .user-icon-box {
                    // display: flex;
                    // align-items: center;
                    margin-right: 0.1rem;
                    line-height: 0.16rem;
                    .icon-phone {
                        line-height: 0.16rem;
                    }
                }

                .user-comments {
                    line-height: 0.16rem;
                }
            }

            .cell-status {
                height: 0.52rem;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }
        }
        .report_cell {
            width: 85%;
            // height: .5rem;
            height: auto;
            background-color: #2c3e50;
            float: left;
            padding: auto;

            /deep/ .van-cell__title {
                flex: 2;
                -webkit-flex: 2;
                -webkit-box-flex: 2;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/ .van-cell__title span {
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /deep/.van-cell-group {
                height: .8rem;
            }

            /deep/.van-cell {
                height: .8rem;
            }

            /deep/.van-cell--large {
                padding-top: .16rem;
                padding-bottom: 0.16rem;
            }

            /deep/.van-cell__value {
                // line-height: .56rem;
                color: red;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }

            /deep/.van-cell__right-icon {
                line-height: .48rem;
            }

            /deep/.van-cell__title {
                display: flex;
                flex-direction: column;
                justify-content: space-between;
            }

            .cell_button_style {
                background-color: #FFFFFF;
                border: none;
                height: 0.52rem;
                line-height: 0.52rem;
            }
        }
    }

    .border{
        margin-bottom: .15rem;
    }
</style>
