<template>
    <div class="upload-image-container">
        <van-uploader
            v-model="fileList"
            multiple
            :before-read="beforeReader"
            :before-delete="deleteImage"
            class="img"
            :style="'background: url(' + getImageUrl(imgBgUrl) + '); background-size: 100% 100%; display: block'"
        />

        <div class="bottom-title">{{bottomTitle}}</div>

        <!-- 新增图片裁剪插件 -->
        <transition name="van-fade">
            <div class="cropper-loading" v-if="showCropperLoading">
                <van-loading size="1rem" color="#ffffff" vertical>图片加载中...</van-loading>
            </div>
            <div class="cropper-container" v-if="showCropper">
                <div class="copper-box">
                    <vueCropper
                        class="vue-cropper-box"
                        ref="cropper"
                        :img="cropperOption.img"
                        :outputSize="cropperOption.size"
                        :outputType="cropperOption.outputType"
                        :info="true"
                        :canScale="true"
                        :autoCrop="true"
                        :autoCropWidth="cropperWidth"
                        :autoCropHeight="cropperHeight"
                        :fixed="true"
                        :fixedNumber="[4, 3]"
                        :fixedBox="true"
                        :canMoveBox="false"
                        :mode="'100% auto'"
                    ></vueCropper>
                </div>

                <div class="img-swipe-box">
                    <swiper 
                        class="swiper gallery-thumbs" 
                        :options="swiperOptionThumbs" 
                        ref="swiperThumbs"
                        @slide-change="handleChangeSlide"
                    >
                        <swiper-slide 
                            v-for="(item, index) in base64Imgs" 
                            :key="index" 
                            :style="'background-image: url(' + item.imgUrl + ');'" 
                            class="slide-1"
                        >
                        </swiper-slide>
                    </swiper>
                </div>

                <div class="cropper-btn">
                    <button @click="cancelEvent">取消</button>
                    <button @click="rotateRight">旋转</button>
                    <button class="button-color" @click="cropperImg('blob')">提交</button>
                </div>
            </div>
        </transition>
    </div>
</template>

<script>
    // 引入图片裁剪插件
    import { VueCropper } from 'vue-cropper'
    // 引入图片轮播组件
    import { Swiper, SwiperSlide } from 'vue-awesome-swiper'
    // 上传图片接口
    import { uploadImage, uploadImageORC } from '@/merchant-bd/api'
    // 中台系统 URL
    import { imgHost } from '../../utils/constV'
    // 引入 图片旋转方法
    import { rotatePhotoImg } from '../../utils/rotatePhotoImg'
    import 'swiper/css/swiper.css'

    export default {
        name: 'uploadImg',
        props: {
            imgBgUrl: {
                type: String,
                default () {
                    return ''
                }
            },
            bottomTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            initData: {
                type: Array,
                default () {
                    return []
                }
            },
            // vant 可以显示的数据结构
            file: {
                type: Array,
                default () {
                    return []
                }
            },
            isORC: {
                type: Boolean,
                default () {
                    return false
                }
            },
            type: {
                type: String,
                default () {
                    return 'P'
                }
            },
            merchantId: {
                type: [String, Number]
            },
            title: {
                type: String,
                default () {
                    return '经营人身份证信息'
                }
            },
            imageType: {
                type: Number,
                default: 5
            },
            // 要提交给服务器的数据结构
            initFile: {
                type: Array,
                default () {
                    return []
                }
            }
        },
        components: {
            VueCropper,
            Swiper,
            SwiperSlide
        },
        data () {
            return {
                // title: '身份证',
                images: {},
                fileList: this.file,
                imgFile: [],
                base64URL: '',
                idCardInfo: {},
                showCropper: false,
                cropperOption: {},
                cropperImgData: '',
                swiperOptionThumbs: {
                    loop: false,
                    loopedSlides: 5, // looped slides should be the same
                    spaceBetween: 10,
                    centeredSlides: true,
                    slidesPerView: 'auto',
                    touchRatio: 0.2,
                    slideToClickedSlide: true
                },
                base64Imgs: [],
                showCropperLoading: false,
                cropperWidth: 375,
                cropperHeight: this.cropperWidth * (3 / 4)
            }
        },
        watch: {
            file (newValue) {
                this.fileList = newValue
            },
            imgFile (newValue) {
                this.$emit('addAlbums', newValue)
            },
            // 将获取到的身份证信息返回给组件
            idCardInfo (newValue) {
                this.$emit('idCardInfo', newValue)
            }
        },
        beforeMount () {
            const h = document.documentElement.clientHeight || document.body.clientHeight
            console.log(h)
        },
        created () {
            this.imgFile = this.initFile
            this.cropperWidth = window.innerWidth
        },
        methods: {
            deleteImage (file, index) {
                console.log(`index is ${index.index}`)
                this.imgFile.splice(index.index, 1)
                return new Promise(res => res())
            },
            beforeReader (file, index) {
                this.resetData()
                console.log('图片上传前获取到的文件')
                console.log(file)
                const newFile = Array.isArray(file) ? file[0] : file
                // ? 同城需求
                // ? 增加图片裁剪功能
                this.showCropperLoading = true

                // 处理图片旋转问题
                rotatePhotoImg(newFile, 'base64').then(base64 => {
                    this.showCropperLoading = false
                    this.showCropper = true
                    // console.log('newBase64Img:', base64)
                    this.base64Imgs.push({
                        imgUrl: base64,
                        index: index.index || 0
                    })
                    this.cropperOption = {
                        img: base64,
                        size: 0.1,
                        outputType: 'jpg'
                    }
                })
            },
            /**
             * 图片压缩 并上传OCR
             * @param seq
             */
            compressionImage (file) {
                const img = new Image()
                const fileSize = file.size
                const fileType = file.type || 'image/jpeg'
                console.log(`原始图片的大小是 ${fileSize}`)

                const reader = new FileReader()
                reader.readAsDataURL(file)
                reader.onload = event => {
                    const canvas = document.createElement('canvas')
                    const context = canvas.getContext('2d')

                    img.src = event.target.result
                    img.onload = () => {
                        this.imgURL = event.target.result
                        canvas.width = img.width || 1080
                        canvas.height = img.height || 1920
                        context.clearRect(0, 0, img.width, img.height)
                        context.drawImage(img, 0, 0, img.width, img.height)
                        const dataurl = canvas.toDataURL(fileType, 0.1)
                        // 执行 orc 身份证识别
                        this.uploadIdCard(dataurl)
                    }
                }
            },
            // 将base64转换为文件
            dataURLtoFile (dataurl, filename) {
                const arr = dataurl.split(',')
                const mime = arr[0].match(/:(.*?);/)[1]
                const bstr = atob(arr[1]) 
                let n = bstr.length 
                const u8arr = new Uint8Array(n)
                while (n--) {
                    u8arr[n] = bstr.charCodeAt(n)
                }
                return new File([u8arr], filename, { type: mime })
            },
            // 新压缩方法
            imgReady (file, index) {
                const _this = this
                return new Promise((reslove, reject) => {
                    const reader = new FileReader()
                    const img = new Image()
                    const fileName = file.name || new Date().getTime()
                    // const fileSize = file.size
                    // const fileType = file.type || 'image/jpeg'
                    const fileType = 'image/jpeg'
                    reader.readAsDataURL(file)
                    reader.onload = event => {
                        const canvas = document.createElement('canvas')
                        const context = canvas.getContext('2d')

                        img.src = event.target.result
                        img.onload = () => {
                            // 压缩图片
                            canvas.width = img.width || 1080
                            canvas.height = img.height || 1920
                            context.clearRect(0, 0, img.width, img.height)
                            context.drawImage(img, 0, 0, img.width, img.height)
                            const dataurl = canvas.toDataURL(fileType, 0.1)

                            const newFile = this.dataURLtoFile(dataurl, fileName)

                            if (_this.isORC) {
                                // const context = canvas.getContext('2d')
                                canvas.width = img.width || 1080
                                canvas.height = img.height || 1920
                                context.clearRect(0, 0, img.width, img.height)
                                context.drawImage(img, 0, 0, img.width, img.height)
                                const compressBase64 = canvas.toDataURL(fileType, 0.1)
                                // console.log('compressBase64:', compressBase64)
                                // 执行 orc 身份证识别
                                _this.uploadIdCard(compressBase64)
                            }

                            if (newFile.size > 5000000) {
                                this.$toast('图片过大 请压缩上传')
                                reject()
                                return ''
                            }

                            const param = new FormData()
                            param.append('file', newFile)
                            param.append('client', 'h5')
                            // console.log('参数', param, newFile)
                            uploadImage(param, res => {
                                if (parseFloat(res.msg).toString() !== 'NaN') {
                                    this.$toast.fail('图片格式有误')
                                    reject()
                                    return
                                }
                                if (res.id === '1') {
                                    const imgInfo = {
                                        categoryType: this.imageType,
                                        imageUrl: res.msg,
                                        sortOrder: index.index,
                                        tag: this.topTitle || this.title,
                                        venderId: this.merchantId
                                    }
                                    this.imgFile.push(imgInfo)
                                    this.fileList = [{
                                        url: imgHost + res.msg,
                                        isImage: true
                                    }]
                                    reslove()
                                    // console.log(`图片信息上传成功 ${JSON.stringify(imgInfo)}`)k
                                } else {
                                    this.$toast('图片上传失败 请稍后再试~')
                                    reject()
                                }
                            }).catch(e => {
                                console.log('错误', e)
                            })
                        }
                    }
                })
            },
            // OCR 身份证上传(不需要压缩的情况)
            uploadIdCard (file) {
                const _this = this
                const param2 = {
                    imgBase64: '',
                    type: this.type,
                    merchantId: this.merchantId.toString()
                }
                // 获取到的base64文件
                _this.base64URL = file
                const newBase64URL = file.replace(/\r|\n/g, '')
                    .replace('data:image/jgp;base64,', '')
                    .replace('data:image/png;base64,', '')
                    .replace('data:image/jpeg;base64,', '')
                param2.imgBase64 = newBase64URL

                uploadImageORC(param2, res => {
                    // console.log('----------------')
                    // console.log(res)
                    if (res.resultData.result.code === '0000') {
                        _this.idCardInfo = res.resultData.data
                        _this.$emit('idCardInfo', res.resultData.data)
                    } else {
                        this.$toast.clear()
                        this.$toast.fail(res.resultData.result.info)
                    }
                })
                // }
            },
            // 获取图片
            getImageUrl (url) {
                let urlString = require('../../assets/img/auth/idCardFront.png')
                switch (url) {
                    case 'idCardFront':
                        urlString = require('../../assets/img/auth/idCardFront.png')
                        break
                    case 'idCardBack':
                        urlString = require('../../assets/img/auth/idCardBack.png')
                        break
                    case 'idCardHand':
                        urlString = require('../../assets/img/auth/idCardHand.png')
                        break
                    default:
                        break
                }
                return urlString
            },
            // 新增图片裁剪的方法
            changeScale (num) { 
                num = num || 1 
                this.$refs.cropper.changeScale(num) 
            },
            rotateLeft () { 
                this.$refs.cropper.rotateLeft() 
            }, 
            rotateRight () { 
                this.$refs.cropper.rotateRight() 
            }, 
            // 实时预览函数 
            realTime (data) { 
                this.previews = data 
            }, 
            // 确定裁剪
            cropperImg (type) { 
                // 输出 
                if (type === 'blob') { 
                    this.$refs.cropper.getCropBlob(data => { 
                        console.log('裁剪后的图片blob')
                        console.log(data)
                        this.uploadCropperImg(data, 1)
                    }) 
                } else { 
                    this.$refs.cropper.getCropData(data => { 
                        console.log('裁剪后的图片base64')
                        console.log(data)
                        this.cropperImgData = data
                        this.uploadCropperImg(data, 1)
                    }) 
                } 
                this.showCropper = false
            },
            // 取消
            cancelEvent () {
                this.showCropper = false
            },
            // 同城
            // ! 图片裁剪 上传功能
            uploadCropperImg (file, index) {
                this.$toast.loading({
                    message: '上传中...',
                    forbidClick: true
                })
                // 大于1M 压缩上传
                if (file.size > 1000000) {
                    console.log(`图片大小是${file.size} 大于1M 进行压缩上传`)
                    // 压缩图片 上传服务器
                    return this.imgReady(file, index)
                } else {
                    console.log(`图片大小是${file.size} 正常上传`)
                    const param = new FormData()
                    param.append('file', file)
                    param.append('client', 'h5')

                    if (this.isORC) {
                        // 执行 orc 身份证识别
                        this.compressionImage(file)
                    }

                    return uploadImage(param, res => {
                        if (parseFloat(res.msg).toString() !== 'NaN') {
                            this.$toast.fail('图片格式有误')
                            Promise.reject()
                            return
                        }
                        if (res.id === '1') {
                            // 返回给父组件的 data
                            const imgInfo = {
                                categoryType: this.imageType,
                                imageUrl: res.msg,
                                sortOrder: index.index,
                                tag: this.topTitle || this.title,
                                venderId: this.merchantId
                            }
                            this.imgFile.push(imgInfo)
                            console.log(`图片信息上传成功 ${JSON.stringify(imgInfo)}`)
                            // 上传图片组件 展示的  data
                            this.fileList = [{
                                url: imgHost + res.msg,
                                isImage: true
                            }]
                            this.$toast.clear()
                            this.$toast.success('上传成功')
                        } else {
                            this.$toast.clear()
                            this.$toast.fail('上传失败,图片格式有误')
                            Promise.reject()
                        }
                    })
                }
            },
            // slide 切换事件
            handleChangeSlide () {
                // 切换 slide 的 index 事件
                console.log('Click slide!', this.$refs.swiperThumbs.$swiper.activeIndex)
            },
            // 重置数据
            resetData () {
                // 重置数据
                this.cropperOption = {}
                this.base64Imgs = []
            }
        }
    }
</script>

<style lang="scss" scoped>
.upload-image-container {
    width: 100%;
    height: auto;
    padding: 0.08rem 0.16rem 0.2rem 0.16rem;
    box-sizing: border-box;
    // margin-bottom: 0.28rem;

    /deep/.van-uploader__preview-delete:before {
        content: "";
    }

    /deep/.van-uploader__preview-delete {
        width: 0.16rem;
        height: 0.16rem;
        position: absolute;
        top: 0.08rem;
        right: 0.08rem;
        background: rgba(0, 0, 0, 0) url("../../assets/img/icon_del2x.png");
        background-size: 0.16rem 0.16rem;
    }

    /deep/ .van-uploader__wrapper {
        flex-wrap: wrap;
    }

    /deep/ .van-icon-clear:before {
        color: rgba(0, 0, 0, 0.3);
        font-size: 0.16rem;
        position: absolute;
        top: 0.16rem;
        right: 0.16rem;
    }

    /deep/ .van-uploader__preview_upload {
        width: 100%;
        height: 2.11rem;
    }

    /deep/ .van-uploader__input {
        width: 100%;
        height: 2.11rem;
    }

    /deep/ .van-uploader__preview,
    /deep/ .van-uploader__upload {
        width: 100%;
        height: 2.11rem;
        margin: 0;
        border: 1px solid #f4f4f4;
        background: #f4f4f4;
    }

    /deep/ .van-uploader__preview-image {
        width: 100%;
        height: 2.11rem;
    }

    .img {
        width: 100%;
        height: 2.11rem;;
        // background: url('../../assets/img/auth/idCardBack.png');
        background-size: 100% 100%;
        // overflow: hidden;

        /deep/ .van-uploader__wrapper {
            width: 100%;
            height: 2.11rem;
        }

        /deep/ .van-uploader__upload-icon::before {
            content: "";
        }

        /deep/ .van-uploader__upload-icon {
            background-image: url('../../assets/img/auth/camera.png');
            background-size: 100% 100%;
            width: 0.97rem;
            height: 0.97rem;
        }

        /deep/ .van-uploader__upload {
            width: 100%;
            height: 2.11rem;;
            background: none;
            border: none;
            margin: 0;
            align-items: center;
            justify-content: center;
        }
    }

    .bottom-title {
        font-size: 0.13rem;
        line-height: 0.13rem;
        font-weight: 400;
        color: #7F7F7F;
        text-align: center;
        margin-top: 0.12rem;
        // margin-bottom: 0.28rem;
    }

    // 新增图片裁剪
    .cropper-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 999;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;

        /deep/ .van-loading__text {
            color: #FFFFFF;
        }
    }
    .cropper-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 99999;
        background-color: rgba(0, 0, 0, 0.6);
        .vue-cropper-box {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 999;
        }

        .vue-cropper {
            background-image: none;
            // background-color: rgba(0, 0, 0, 0.6);
        }

        .img-swipe-box {
            position: absolute;
            bottom: 0.5rem;
            width: 100%;
            height: 0.7rem;
            // background-color: #FFFFFF;
            z-index: 9999;

            .swiper {
                .swiper-slide {
                    background-size: cover;
                    background-position: center;
                }

                 &.gallery-thumbs {
                    height: 100%;
                    box-sizing: border-box;
                    padding: 0.12rem 0;
                }
                &.gallery-thumbs .swiper-slide {
                    width: 20%;
                    height: 100%;
                    opacity: 0.4;
                }
                &.gallery-thumbs .swiper-slide-active {
                    box-sizing: border-box;
                    opacity: 1;
                    border: 0.02rem solid #F0250F;
                }
            }
        }

        .cropper-btn {
            position: absolute;
            width: 100%;
            height: 0.5rem;
            bottom: 0;
            display: flex;
            justify-content: space-around;
            font-size: 0.15rem;
            color: #FFFFFF;
            z-index: 9999;
            button {
                flex: 1;
                background-color: rgba(0, 0, 0, 0);
                border: none;
            }

            .button-color {
                color: #F0250F;
                background-color: rgba(0, 0, 0, 0);
                border: none;
            }
        }
    }
}
</style>
