<template>
    <div :class="showFirst ? 'bt1' : 'bto'" class="album_container">
        <div :class="showFirst ? 'bg1' : 'bg0'" class="top_title" v-if="topTitle">
            <div class="top_left">{{ topTitle }}</div>
            <div class="top_right"></div>
            <div style="clear: both"></div>
            <!-- 同城新增 -->
            <div v-if="topText" class="top-text">{{ topText }}</div>
        </div>
        <!--   资质上传     -->
        <template v-if="type2">
            <template v-if="showFirst">
                <div class="ablum2" :class="isBottomBorder ? 'border' : ''">
                <div class="album_top">
                    <div v-if="!disabledMenu">
                        <van-dropdown-menu :overlay="false">
                            <van-dropdown-item
                                v-model="title"
                                :options="iteams"
                                :title="title"
                                title-class="title_style"
                            >
                            </van-dropdown-item>
                        </van-dropdown-menu>
                    </div>

                    <div v-else-if="disabledMenu" class="header-box">
                        <div v-show="headerTitle" class="header-title">
                            {{ headerTitle }}
                        </div>
                        <div v-show="headerText" class="header-text">
                            {{ headerText }}
                        </div>
                    </div>
                </div>
                <div class="album_bottom">
                    <van-uploader
                        v-model="fileList"
                        upload-text="添加照片"
                        :max-count="100"
                        multiple
                        :before-read="beforeReader"
                        :before-delete="deleteImage"
                        class="img"
                    >
                    </van-uploader>
                </div>
                </div>
            </template>
        </template>
        <!-- 门店门头或logo、店内环境 -->
        <template v-else>
            <div class="ablum" :class="isBottomBorder ? 'border' : ''">
                <van-uploader
                    v-model="fileList"
                    upload-text="添加照片"
                    multiple
                    :max-count="100"
                    :before-read="beforeReader"
                    :before-delete="deleteImage"
                    class="img"
                >
                </van-uploader>
            </div>
        </template>

        <!-- 新增图片裁剪功能 -->
        <div name="van-fade">
            <div class="cropper-loading" v-if="showCropperLoading">
                <van-loading size="1rem" color="#ffffff" vertical>图片加载中...</van-loading>
            </div>

            <div class="cropper-container" v-if="showCropper">
                <div class="copper-box">
                    <vueCropper
                        class="vue-cropper-box"
                        ref="cropper"
                        :img="cropperOption.img"
                        :outputSize="cropperOption.size"
                        :outputType="cropperOption.outputType"
                        :autoCropWidth="cropperWidth"
                        :autoCropHeight="cropperWidth"
                        :info="true"
                        :canScale="true"
                        :autoCrop="true"
                        :fixed="true"
                        :fixedNumber="fixedNumber"
                        :fixedBox="true"
                        :canMoveBox="false"
                        :mode="'100% auto'"
                    ></vueCropper>
                </div>

                <div class="img-swipe-box">
                    <swiper 
                        class="swiper gallery-thumbs" 
                        :options="swiperOptionThumbs" 
                        ref="swiperThumbs"
                        @slide-change="handleChangeSlide"
                    >
                        <swiper-slide 
                            v-for="(item, index) in base64Imgs" 
                            :key="index" 
                            :style="'background-image: url(' + item.imgUrl + ');'" 
                            class="slide-1"
                        >
                        </swiper-slide>
                    </swiper>
                </div>

                <div class="cropper-btn">
                    <button @click="cancelEvent">取消</button>
                    <button @click="rotateRight">旋转</button>
                    <button @click="cropperImg('blob')">裁剪</button>
                    <button class="button-color" @click="confirmEvent">提交({{base64Imgs.length || 1}})</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    // 引入图片裁剪插件
    import { VueCropper } from 'vue-cropper'
    import { uploadImage } from '@/merchant-bd/api' 
    // 引入图片轮播组件
    import { Swiper, SwiperSlide } from 'vue-awesome-swiper'
    import { imgHost } from '../../utils/constV'
    // 引入 图片旋转方法
    import { rotatePhotoImg } from '../../utils/rotatePhotoImg'
    import 'swiper/css/swiper.css'

    export default {
        name: 'albumManage',
        props: {
            topTitle: {
                type: String
            },
            topTips: {
                type: String
            },
            isBottomBorder: {
                type: String
            },
            type2: {
                type: String
            },
            // 针对补充材料的特殊处理
            fileData: {
                type: Object
            },
            showFirst: {
                type: Boolean,
                default: true
            },
            merchantId: {
                type: [String, Number]
            },
            imageType: {
                type: Number,
                default: 5
            },
            // vant 可以显示的数据结构
            file: {
                type: Array,
                default () {
                    return []
                }
            },
            // 要提交给服务器的数据结构
            initFile: {
                type: Array,
                default () {
                    return []
                }
            },
            // 新增隐藏 selecet 组件
            disabledMenu: {
                type: Boolean,
                default () {
                    return false
                }
            },
            headerTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            headerText: {
                type: String,
                default () {
                    return ''
                }
            },
            // 同城新增
            topText: {
                type: String,
                default () {
                    return ''
                }
            },
            // 图片裁剪比例
            fixedNumber: {
                type: Array,
                default () {
                    return [4, 3]
                }
            }
        },
        components: {
            VueCropper,
            Swiper,
            SwiperSlide
        },
        data () {
            return {
                iteams: [
                    { text: '行业特殊资质许可证', value: '行业特殊资质许可证' }
                ],
                title: '行业特殊资质许可证',
                images: [],
                test: '',
                fileList: this.file,
                // 要提交的图片数据的集合
                imgFile: [],
                showCropper: false,
                cropperOption: {},
                cropperImgData: '',
                swiperOptionThumbs: {
                    loop: false,
                    loopedSlides: 5, // looped slides should be the same
                    spaceBetween: 10,
                    centeredSlides: true,
                    slidesPerView: 'auto',
                    touchRatio: 0.2,
                    slideToClickedSlide: true
                },
                base64Imgs: [],
                showCropperLoading: false,
                allCropperImgs: [],
                cropperImgIndex: 0,
                count: 0,
                cropperWidth: 375,
                loadingCount: 0,
                cropperCounts: 0,
                timer: {}
            }
        },
        watch: {
            file (newValue) {
                // console.log('file:', this.fileList)
                this.fileList = newValue
            },
            imgFile (newValue) {
                // console.log(JSON.stringify(newValue))
                this.$emit('addAlbums', newValue)
            },
            initFile (newValue) {
                this.imgFile = newValue
            }
            // title (newValue) {
            //     this.imgFile = this.imgFile.map(value => ({
            //         categoryType: value.categoryType,
            //         imageUrl: value.imageUrl,
            //         sortOrder: value.sortOrder,
            //         tag: value.tag,
            //         venderId: value.venderId
            //     }))
            //     this.$emit('addAlbums', this.imgFile)
            // }
        },
        beforeCreate () {
            // console.log('beforeCreate')
        },
        created () {
            // 组件实例化前
            // console.log('window.innerWidth')
            // console.log(window.innerWidth)
            this.cropperWidth = window.innerWidth
            // 针对补充材料的特殊处理
            if (this.fileData) {
                // console.log('this.fileData:', this.fileData)
                const baseUrl = imgHost
                this.title = this.fileData.tag
                this.fileData.images.forEach(value => {
                    const otherObj = {
                        categoryType: value.type,
                        imageUrl: value.imgUrl,
                        sortOrder: value.orderBy,
                        tag: value.tag,
                        venderId: this.merchantId
                    }
                    this.imgFile.push(otherObj)
                })
                this.fileList = this.imgFile.map(value => ({
                    url: baseUrl + value.imageUrl,
                    isImage: true
                }))
            } else {
                // console.log('初始化的数据图片数据是')
                // console.log('this.initFile:', this.initFile)
                this.imgFile = this.initFile
            }
        },
        methods: {
            deleteImage (file, index) {
                // console.log(`index is ${index.index}`)
                this.imgFile.splice(index.index, 1)
                return new Promise(res => res())
            },
            beforeReader (file, index) {
                const _this = this
                this.resetData()
                // console.log('图片上传前获取到的文件')
                // console.log(file)
                // ? 同城需求
                // ? 增加图片裁剪功能
                this.showCropperLoading = true
                // 判断是多张图片上传还是单张
                if (Array.isArray(file)) {
                    if (file.length > 9) {
                        this.$toast('多图上传不要超过9张')
                        setTimeout(() => {
                            // console.log('隐藏裁剪框')
                            _this.showCropperLoading = false
                            _this.showCropper = false
                        }, 2000)
                        return false
                    }
                    if (this.fileList.length + file.length > 100) {
                        this.$toast('图片最多100张')
                        setTimeout(() => {
                            // console.log('隐藏裁剪框')
                            _this.showCropperLoading = false
                            _this.showCropper = false
                        }, 2000)
                        return false
                    }
                    // 先放几个空数据到数组里
                    file.map(item => {
                        this.base64Imgs.push({})
                        this.allCropperImgs.push({})
                        return item
                    })
                    // const all = []
                    file.forEach((value, i) => {
                        // all.push(this.upload(value, index++))
                        // console.log(value)
                        // all.push(
                        rotatePhotoImg(value, 'base64').then(base64 => {
                            console.log('newBase64Img:', base64)
                            this.cropperCounts++
                            // 新方法
                            const newImg = {
                                imgUrl: base64,
                                index: index.index || 0
                            }
                            this.base64Imgs.splice(i, 1, newImg)
                            const newCropperImg = {
                                img: base64,
                                size: 0.1,
                                outputType: 'jpg'
                            }
                            this.allCropperImgs.splice(i, 1, newCropperImg)

                            // 裁剪图片初始化只显示第一张
                            if (i === 0) {
                                this.cropperOption = {
                                    img: base64,
                                    size: 0.1,
                                    outputType: 'jpg'
                                }
                            }
                            
                            // 如果所有图片处理完 再关闭loading
                            if (file.length === this.cropperCounts) {
                                this.showCropperLoading = false
                                this.showCropper = true
                                this.cropperCounts = 0
                            }
                        })
                        // )
                    })
                } else {
                    // ! 这里暂时不需要
                    // 单张图片上传 处理图片旋转问题
                    rotatePhotoImg(file, 'base64').then(base64 => {
                        // console.log('newBase64Img:', base64)
                        this.base64Imgs.push({
                            imgUrl: base64,
                            index: index.index || 0
                        })
                        // 裁剪的图片
                        this.cropperOption = {
                            img: base64,
                            size: 0.1,
                            outputType: 'jpg'
                        }
                        this.showCropperLoading = false
                        this.showCropper = true
                    })
                }
            },
            // 将base64转换为文件
            dataURLtoFile (dataurl, filename) {
                const arr = dataurl.split(',')
                const mime = arr[0].match(/:(.*?);/)[1]
                const bstr = atob(arr[1]); let n = bstr.length; const 
                    u8arr = new Uint8Array(n)
                while (n--) {
                    u8arr[n] = bstr.charCodeAt(n)
                }
                return new File([u8arr], filename, { type: mime })
            },
            // 新压缩方法
            imgReady (file, index) {
                return new Promise((reslove, reject) => {
                    const reader = new FileReader()
                    const img = new Image()
                    const fileName = file.name || new Date().getTime()
                    // const fileSize = file.size
                    // const fileType = file.type || 'image/jpeg'
                    const fileType = 'image/jpeg'
                    reader.readAsDataURL(file)
                    reader.onload = event => {
                        const canvas = document.createElement('canvas')
                        const context = canvas.getContext('2d')

                        img.src = event.target.result
                        img.onload = () => {
                            // 压缩图片
                            canvas.width = img.width || 1080
                            canvas.height = img.height || 1920
                            context.clearRect(0, 0, img.width, img.height)
                            context.drawImage(img, 0, 0, img.width, img.height)
                            const dataUrl = canvas.toDataURL(fileType, 0.1)

                            const newFile = this.dataURLtoFile(dataUrl, fileName)

                            if (newFile.size > 5000000) {
                                this.loadingCount++
                                if (this.loadingCount === this.base64Imgs.length) {
                                    this.showCropperLoading = false
                                    this.loadingCount = 0
                                }
                                this.$toast('图片过大 请压缩上传')
                                reject()
                                return ''
                            }

                            const param = new FormData()
                            param.append('file', newFile)
                            param.append('client', 'h5')
                            // console.log('参数', param, newFile)
                            uploadImage(param, res => {
                                console.log(res)
                                this.loadingCount++
                                if (this.loadingCount === this.base64Imgs.length) {
                                    this.showCropperLoading = false
                                    this.loadingCount = 0
                                }

                                if (parseFloat(res.msg).toString() !== 'NaN') {
                                    this.$toast.fail('图片格式有误')
                                    reject()
                                    return
                                }
                                if (res.id === '1') {
                                    const imgInfo = {
                                        categoryType: this.imageType,
                                        imageUrl: res.msg,
                                        sortOrder: index.index,
                                        tag: '',
                                        venderId: this.merchantId
                                    }
                                    this.imgFile.push(imgInfo)
                                    this.fileList.push({
                                        url: imgHost + res.msg,
                                        isImage: true
                                    })
                                    reslove()
                                    // console.log(`图片信息上传成功 ${JSON.stringify(imgInfo)}`)
                                } else {
                                    this.$toast('图片上传失败 请稍后再试~')
                                    reject()
                                }
                            }).catch(e => {
                                console.log('错误', e)
                            })
                        }
                    }
                })
            },
            // 新增图片裁剪的方法
            rotateRight () { 
                this.$refs.cropper.rotateRight() 
            }, 
            // 实时预览函数 
            realTime (data) { 
                this.previews = data 
            }, 
            // 确定裁剪
            cropperImg (type) {
                // 打开loading
                this.showCropperLoading = true
                const allBase64Img = this.base64Imgs.map(item => {
                    if (this.count === 0) item.imgUrl = this.dataURLtoFile(item.imgUrl, new Date().getTime())
                    return item
                })
                this.count++
                // 输出 
                if (type === 'blob') { 
                    this.$refs.cropper.getCropBlob(data => { 
                        console.log('裁剪后的图片blob')
                        console.log(data)
                        const newData = {
                            imgUrl: data,
                            index: this.cropperImgIndex || 0
                        }
                        allBase64Img.splice(this.cropperImgIndex, 1, newData)
                        this.base64Imgs = allBase64Img

                        // 裁剪完的图片 替换
                        const reader = new FileReader()
                        reader.readAsDataURL(data)
                        reader.onload = event => {
                            const newBase64 = {
                                img: event.target.result,
                                size: 0.1,
                                outputType: 'jpg'
                            }
                            console.log('this.cropperImgIndex:', this.cropperImgIndex)
                            console.log('this.allCropperImgs:', this.allCropperImgs)

                            this.cropperOption = newBase64
                            this.allCropperImgs.splice(this.cropperImgIndex, 1, newBase64)
                            // 关闭loading
                            this.showCropperLoading = false
                        }
                    }) 
                } else { 
                    // ! 暂时不做处理
                    this.$refs.cropper.getCropData(data => { 
                        console.log('裁剪后的图片base64')
                        console.log(data)
                        this.cropperImgData = data
                        this.uploadCropperImg(data, this.cropperImgIndex)
                    }) 
                }
                this.$toast('裁剪成功')
            },
            // 取消
            cancelEvent () {
                this.resetData()
                this.showCropper = false
            },
            // 确定提交
            confirmEvent () {
                console.log('确定提交')
                console.log(this.base64Imgs)
                // 显示loading
                this.showCropperLoading = true
                this.base64Imgs.forEach((item, i) => {
                    this.uploadCropperImg(item.imgUrl, i)
                })
                this.showCropper = false
            },
            // 同城
            // ! 图片裁剪 上传功能
            uploadCropperImg (file, index) {
                if (typeof (file) == 'string') file = this.dataURLtoFile(file, new Date().getTime())

                // 大于1M 压缩上传
                if (file.size > 1000000) {
                    console.log(`图片大小是${file.size} 大于1M 进行压缩上传`)
                    // 压缩图片 上传服务器
                    return this.imgReady(file, index)
                } else {
                    console.log(`图片大小是${file.size} 正常上传`)
                    const param = new FormData()
                    param.append('file', file)
                    param.append('client', 'h5')

                    return uploadImage(param, res => {
                        this.loadingCount++
                        if (this.loadingCount === this.base64Imgs.length) {
                            this.showCropperLoading = false
                            this.loadingCount = 0
                        }
                        
                        if (parseFloat(res.msg).toString() !== 'NaN') {
                            this.$toast.fail('图片格式有误')
                            Promise.reject()
                            return
                        }
                        if (res.id === '1') {
                            // 返回给父组件的 data
                            const imgInfo = {
                                categoryType: this.imageType,
                                imageUrl: res.msg,
                                sortOrder: index.index,
                                tag: '',
                                venderId: this.merchantId
                            }
                            this.imgFile.push(imgInfo)
                            console.log(`图片信息上传成功 ${JSON.stringify(imgInfo)}`)
                            // 上传图片组件 展示的  data
                            this.fileList.push({
                                url: imgHost + res.msg,
                                isImage: true
                            })
                            // console.log('this.fileList')
                            // console.log(this.fileList)
                            this.$toast.clear()
                            this.$toast.success('上传成功')
                        } else {
                            this.$toast.clear()
                            this.$toast.fail('上传失败,图片格式有误')
                            Promise.reject()
                        }
                    })
                }
            },
            // slide 切换事件
            handleChangeSlide () {
                clearTimeout(this.timer)
                // 先清空再赋值
                this.cropperOption = {}
                // 切换 slide 的 index 事件
                console.log('Click slide!', this.$refs.swiperThumbs.$swiper.activeIndex)
                this.cropperImgIndex = this.$refs.swiperThumbs.$swiper.activeIndex
                this.timer = setTimeout(() => {
                    this.cropperOption = this.allCropperImgs[this.$refs.swiperThumbs.$swiper.activeIndex]
                }, 10)
            },
            // 重置数据
            resetData () {
                // 重置数据
                this.cropperOption = {}
                this.base64Imgs = []
                this.allCropperImgs = []
                this.count = 0
                this.cropperCounts = 0
                this.cropperImgIndex = 0
            }
        }
    }
</script>

<style lang="scss" scoped>
$lh: 0.2rem;

/deep/ .van-dropdown-item__option--active {
    color: #f0250f;
}

/deep/ .van-dropdown-menu__title--active {
    color: #000000 !important;
}

/deep/ .van-dropdown-menu__item {
    box-sizing: content-box;
    margin: 0 24px;
    border-bottom: 1px solid #eaeaea;
}

/deep/ .van-dropdown-item__content {
    box-shadow: 0px 8px 15px 0px rgba(193, 193, 193, 1);
    border-radius: 0.04rem;
}

/deep/ .van-dropdown-item__content {
    display: flex;
    flex-direction: column;
}
/deep/ .van-dropdown-item__option {
    width: auto;
    flex: 1;
    box-sizing: content-box;
    margin: 0 24px;
    border-bottom: 1px solid #eaeaea;
}

.title_style {
    font-size: 0.14rem;
    color: #000000;
}

// 新增
.header-box {
    margin-top: 0.14rem;
    margin-bottom: 0.15rem;

    .header-title {
        font-size: 0.15rem;
        font-weight: 400;
        color: rgba(0, 0, 0, 1);
        line-height: 0.15rem;
        text-align: center;
    }

    .header-text {
        margin-top: 0.04rem;
        font-size: 0.11rem;
        font-weight: 400;
        color: rgba(240, 37, 15, 1);
        line-height: 0.17rem;
        text-align: center;
        white-space: pre-line;
    }
}

.border {
    margin-top: 0.2rem;
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

/deep/ .van-image__img,
/deep/ .van-uploader__file {
    width: 1.65rem;
    height: 0.92rem;
}

.bto {
    border-bottom: 0.01rem solid rgba(0, 0, 0, 0);
}

.bt1 {
    border-bottom: 0.01rem solid #ededed;
}

.album_container {
    min-height: 0rem;
    font-size: 0.12rem;

    .bg1 {
        background: white;
    }

    .bg0 {
        background: rgba(0, 0, 0, 0);
        margin-bottom: 0.12rem;
    }

    .top_title {
        font-size: 0.15rem;
        color: #000;
        min-height: $lh;
        padding-top: 0.16rem;
        padding-left: 0.12rem;

        .top_left {
            width: auto;
            line-height: $lh;
            text-align: left;
            float: left;
        }

        .top_right {
            width: auto;
            max-width: 40%;
            line-height: $lh;
            touch-action: none;
            text-align: right;
            float: left;

            .van_icon {
                margin-bottom: 0.01rem;
            }
        }

        .top-text {
            font-size: 0.11rem;
            font-weight: 400;
            color: #848484;
        }
    }

    /deep/.van-icon-warning-o:before {
        content: "";
    }

    /deep/.van-icon-warning-o {
        width: 0.33rem;
        height: 0.29rem;
        background-image: url("../../assets/img/icon_error.png");
        background-size: 0.33rem 0.29rem;
    }

    /deep/.van-uploader__preview-delete:before {
        content: "";
    }

    /deep/ .van-icon-photograph::before {
        content: "";
    }

    /deep/.van-uploader__preview-delete {
        width: 0.16rem;
        height: 0.16rem;
        position: absolute;
        top: 0.08rem;
        right: 0.08rem;
        background: rgba(0, 0, 0, 0) url("../../assets/img/icon_del2x.png");
        background-size: 0.16rem 0.16rem;
    }

    /deep/ .van-uploader__upload {
        border-radius: 0.04rem;
    }

    .ablum {
        min-height: 1.11rem;
        padding: 0.15rem 0;
        background-color: white;

        /deep/ .van-icon-plus:before {
            content: "";
        }

        /deep/ .van-icon-photograph::before {
            content: "";
        }

        /deep/ .van-uploader__upload-icon {
            content: "";
            width: 0.16rem;
            height: 0.16rem;
            background-image: url("../../assets/img/auth/cameraPlus.png");
            background-size: 0.16rem 0.16rem;
        }

        /deep/ .van-uploader__wrapper {
            justify-content: space-between;
            flex-wrap: wrap;
            width: 100vw;
        }

        /deep/ .van-icon-clear:before {
            color: rgba(0, 0, 0, 0.3);
            font-size: 0.16rem;
            position: absolute;
            top: 0.16rem;
            right: 0.16rem;
        }

        /deep/.van-uploader__upload-text {
            color: #c9c9c9;
            margin-top: 0.06rem;
        }

        /deep/ .van-uploader__preview_upload,
        /deep/ .van-uploader__input {
            width: 1.65rem;
            height: 0.92rem;
        }

        /deep/ .van-uploader__preview,
        /deep/ .van-uploader__upload {
            width: 1.65rem;
            height: 0.92rem;
            // margin: 0.11rem 0rem 0rem 0.11rem;
            margin: 0 0.1rem 0.11rem 0.1rem;
            border: 1px solid #f4f4f4;
            background: #f4f4f4;
        }

        /deep/ .van-uploader__preview-image {
            width: 1.65rem;
            height: 0.92rem;
        }
    }

    .ablum2 {
        width: 100%;
        min-height: 1.11rem;
        background-color: white;
        overflow: hidden;

        /deep/.van-uploader__upload-text {
            color: #c9c9c9;
            margin-top: 0.06rem;
        }

        /deep/ .van-icon-plus:before {
            content: "";
        }

        /deep/ .van-uploader__upload-icon {
            content: "";
            width: 0.16rem;
            height: 0.16rem;
            background-image: url("../../assets/img/auth/cameraPlus.png");
            background-size: 0.16rem 0.16rem;
        }

        .album_top {
            width: 100%;
            // height: 0.5rem;
            height: auto;
            padding-top: 0.05rem;
            background-color: white;
            border-bottom: 0.01rem solid #ededed;

            /deep/ .van-hairline--top-bottom::after,
            /deep/.van-hairline-unset--top-bottom::after {
                border-width: 0rem;
            }

            /deep/ .van-dropdown-menu {
                height: 0.4rem;
            }

            /deep/.van-dropdown-item__content {
                width: 3.43rem;
                margin-left: 0.16rem;
            }

            /deep/.van-cell__title {
                text-align: center;
            }

            /deep/.van-cell__value {
                display: none;
            }

            /deep/ .van-dropdown-menu__title::after {
                content: "";
                background-image: url("../../assets/img/arrowDown.png");
                background-size: 0.1rem 0.05rem;
                border: 0px;
                width: 0.1rem;
                height: 0.05rem;
                position: absolute;
                top: 70%;
                right: -0.1rem;
                transform: rotate(0deg);
            }

            /deep/ .van-dropdown-menu__title--down::after {
                content: "";
                background-image: url("../../assets/img/arrowDown.png");
                background-size: 0.1rem 0.05rem;
                border: 0px;
                width: 0.1rem;
                height: 0.05rem;
                position: absolute;
                top: 50%;
                right: -0.1rem;
                transform: rotate(180deg);
            }
        }

        .album_bottom {
            width: 100%;
            // min-height: 1.15rem;
            background-color: white;
            // padding: 0rem 0.16rem 0.16rem 0.16rem;
            padding: 0.15rem 0;

            /deep/ .van-uploader__wrapper {
                justify-content: space-between;
                flex-wrap: wrap;
                width: 100vw;
            }

            /deep/ .van-icon-clear:before {
                color: rgba(0, 0, 0, 0.3);
                font-size: 0.16rem;
                position: absolute;
                top: 0.16rem;
                right: 0.16rem;
            }

            /deep/ .van-uploader__preview_upload {
                width: 1.65rem;
                height: 0.92rem;
            }

            /deep/ .van-uploader__input {
                width: 1.65rem;
                height: 0.92rem;
            }

            /deep/ .van-uploader__preview,
            /deep/ .van-uploader__upload {
                width: 1.65rem;
                height: 0.92rem;
                margin: 0 0.1rem 0.11rem 0.1rem;
                border: 1px solid #f4f4f4;
                background: #f4f4f4;
            }

            /deep/ .van-uploader__preview-image {
                width: 1.65rem;
                height: 0.92rem;
            }
        }
    }

    // 新增图片裁剪
    .cropper-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1000;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;

        /deep/ .van-loading__text {
            color: #FFFFFF;
        }
    }
    .cropper-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 999;
        background-color: rgba(0, 0, 0, 0.6);
        .vue-cropper-box {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 999;
        }

        .vue-cropper {
            background-image: none;
            // background-color: rgba(0, 0, 0, 0.6);
        }

        .img-swipe-box {
            position: absolute;
            bottom: 0.5rem;
            width: 100%;
            height: 0.7rem;
            // background-color: #FFFFFF;
            z-index: 9999;

            .swiper {
                .swiper-slide {
                    background-size: cover;
                    background-position: center;
                }

                 &.gallery-thumbs {
                    height: 100%;
                    box-sizing: border-box;
                    padding: 0.12rem 0;
                }
                &.gallery-thumbs .swiper-slide {
                    width: 20%;
                    height: 100%;
                    opacity: 0.4;
                }
                &.gallery-thumbs .swiper-slide-active {
                    box-sizing: border-box;
                    opacity: 1;
                    border: 0.02rem solid #F0250F;
                }
            }
        }

        .cropper-btn {
            position: absolute;
            width: 100%;
            height: 0.5rem;
            bottom: 0;
            display: flex;
            justify-content: space-around;
            font-size: 0.15rem;
            color: #FFFFFF;
            z-index: 9999;
            button {
                flex: 1;
                background-color: rgba(0, 0, 0, 0);
                border: none;
            }

            .button-color {
                color: #F0250F;
            }
        }
    }
}
</style>
