<template>
    <div class="forbid_content" v-if="fetchFinish">
        <div class="warning_icon">
            <img src="@/merchant-bd/assets/img/person.png">
        </div>
        <div class="tips">
            <p>{{currentErp}} 您好：</p>
            <span>
                    您的职务信息还未录入，请联系与您对接的运营同事，录入职务信息后再来查看。
            </span>
        </div>
    </div>
</template>

<script>
    import JME from '@/merchant-bd/utils/jdme.js'
    import '../../utils/JDMESDK.js'
    import { getUrlString } from '@/merchant-bd/utils/tools'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    import { ENUMLIST } from '../enum'

    export default {
        name: 'forbid',
        data () {
            return {
                currentErp: 'houqingxiang1', // 当前登录用户的erp
                positionId: ENUMLIST.PROFESSIONAL,
                fetchFinish: false
            }
        },
        mounted () {
            // Toast.setDefaultOptions({ duration: 2000 })
            // Toast('测试')
            console.log(JME.getCookie('url'))
            this.currentErp = getUrlString('sid') || JME.getUserNameForCookie() //
            console.log(this.currentErp)
            this.queryBDUserInfoByERP()
            // 根据当前的接口状态 跳转到不同的页面
        },
        methods: {
            queryBDUserInfoByERP () {
                console.log('queryUserInfoByERP')
                this.fetchFinish = false
                fetch.get({
                    url: apiUrl.queryBDUserInfoByERP,
                    data: {
                        erp: this.currentErp
                    }
                }, res => {
                    console.log(res)
                    this.fetchFinish = true
                    if (res.result && res.result.code === '0000') {
                        if (res.data.positionId) {
                            // this.goToPage(res.data.positionId || ENUMLIST.PROFESSIONAL)
                            this.goToPage(res.data.positionId)
                        }
                    }
                }, res => {
                    console.log(res)
                    this.fetchFinish = true
                })
            },
            goToPage (id) {
                switch (id) {
                    case ENUMLIST.DISTRICT_SUPERVISOR:
                        this.$router.replace(`/report-district/${this.currentErp}`)
                        break
                    case ENUMLIST.PROVINCIAL_SUPERVISOR:
                        this.$router.replace(`/report-province/${this.currentErp}`)
                        break
                    default:
                        this.$router.replace(`/report-personal/${this.currentErp}`)
                }
            }
        }

    }
</script>

<style  lang="scss" scoped>

    .forbid_content{
        padding-right: .12rem;
        padding-left: .12rem;
        font-size: .16rem;
        color: #2E2D2D;
        text-align: center;

        .warning_icon{
            margin: 1.5rem auto .2rem auto;
            img{
                width: 1.5rem;
                height: 1.5rem;
            }
        }

        .tips{
            width: 90%;
            height: 1rem;
            margin: auto;

            p {
                text-align: center;
                margin-bottom: .2rem;
            }
        }
    }
</style>
