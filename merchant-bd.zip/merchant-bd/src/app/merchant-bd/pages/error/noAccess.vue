<template>
    <div class="no-access-content">
        <div class="error-box">
            <div class="warning_icon">
                <img src="@/merchant-bd/assets/img/auth/login_error.png">
            </div>
            <div class="tips">
                <span>{{title}}</span>
            </div>
            <div class="login-failed-btn" @click="loginFailed">
                注销登录
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'forbid',
        data () {
            return {
                fetchFinish: false,
                title: '该账户未创建或创建错误'
            }
        },
        mounted () {
            this.title = this.$route.query.title
        },
        methods: {
            // 退出登录
            loginFailed () {
                console.log('注销登录')
                localStorage.clear()
                const localUrl = encodeURIComponent(`${window.location.protocol}//${window.location.host}${window.location.pathname}#/business/performance/company`)
                window.location.href = `//plogin.m.jd.com/cgi-bin/ml/mlogout?appid=566&wxautologin=false&returnurl=${localUrl}`
            }
        }
    }
</script>

<style lang="scss" scoped>
    .no-access-content{
        position: absolute;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;

        .error-box {
            display: flex;
            flex-direction: column;
            align-items: center;

            .warning_icon {
                width: 1.53rem;
                height: 1.53rem;
                margin-bottom: 0.23rem;
                img {
                    width: 1.53rem;
                    height: 1.53rem;
                }
            }

            .tips {
                width: 90%;
                height: auto;
                margin: auto;
                font-size: .15rem;
                font-weight: 500;
                color: #2E2D2D;
                text-align: center;

                p {
                    text-align: center;
                    margin-bottom: .2rem;
                }
            }

            .login-failed-btn {
                margin-top: 0.28rem;
                width: 1.2rem;
                height: 0.4rem;
                border-radius: 0.2rem;
                border:1px solid #F0250F;
                font-size: 0.15rem;
                font-weight: 400;
                color: #F0250F;
                display: flex;
                align-items: center;
                justify-content: center;
            }
        }
    }
</style>
