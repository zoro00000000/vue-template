<template>
    <div class="white-list-container">
        <van-form @submit="commit">
            <van-cell-group class="white-group-box">
                <div class="help-box">
                    <van-icon @click="showWarningEvent" name="question-o" />
                </div>

                <div v-if="shopName">
                    <text-cell :leftTitle="'商家店铺名称'" />

                    <div class="title-field-box-1">
                        <van-field
                            :disabled="true"
                            v-model="shopName"
                            readonly
                            label-class="label-style"
                        />
                    </div>
                </div>

                <text-cell :leftTitle="'我的京东用户名'" :rightTitle="pin" />

                <div class="title-warning">* 京东APP-我的-设置中查看用户名</div>
                <div class="title-field-box">
                    <van-field 
                        v-model="jdPin" 
                        placeholder="您的京东用户名" 
                        :rules="[{ required: true, message: '请输入您的京东用户名' }]"
                    />
                </div>

                <text-cell :leftTitle="'选择学校所在地址'" />

                <div class="title-field-box">
                    <van-field
                        v-model="address"
                        placeholder="学校所在地"
                        right-icon="arrow-down"
                        readonly
                        label-class="label-style"
                        :rules="[{ required: true, message: '请选择学校所在地' }]"
                        @click="chooseAddress()"
                    />
                </div>

                <text-cell :leftTitle="'选择预览学校'" />

                <div class="title-field-box">
                    <van-field
                        v-model="school"
                        placeholder="您要预览的学校"
                        right-icon="arrow-down"
                        readonly
                        label-class="label-style"
                        :rules="[{ required: true, message: '请选择您要预览的学校' }]"
                        @click="chooseSchool()"
                    />
                </div>
            </van-cell-group>

            <div class="white-button-box">
                <!-- <div class="white-btn" @click="commit">确定修改</div> -->
                <van-button round block type="info" native-type="submit">
                    确定修改
                </van-button>
            </div>
        </van-form>

        <!--    四级地址选择弹窗    -->
        <dist-picker
            v-if="distPickerShowFlag"
            @close="distPickerClose"
            @selected="distPickerSelect"
            :province="merchantAddress.province"
            :city="merchantAddress.city"
            :country="merchantAddress.country"
            :town="merchantAddress.town"
            :provinceId="merchantAddress.provinceId"
            :cityId="merchantAddress.cityId"
            :countryId="merchantAddress.countryId"
            :townId="merchantAddress.townId"
            :showTier="2"
        ></dist-picker>

        <!--    通用选择弹窗    -->
        <van-popup
            v-model="showPopup"
            position="bottom"
            :style="{ height: '30%' }"
        >
            <van-picker
                show-toolbar
                :title="popupTitleQualification"
                :columns="itemsQualification"
                :default-index="defaultIndexQualification"
                :visible-item-count="visibleItemCountQualification"
                :item-height="itemHeightQualification"
                :swipe-duration="100"
                @change="pickChange"
                @cancel="showPopup = false"
                @confirm="onConfirm"
            >
            </van-picker>
        </van-popup>

        <!-- 同城新增 关联学校提示弹窗 -->
        <alert-overlay 
            :show="showWarning"
            :alertType="3"
            :headerTitle="'注意'"
            :contentText="questionText"
            :showSolt="false"
            :confirmEvent="confirmClick"
        >
        </alert-overlay>
    </div>
</template>

<script>
    // import { BaiduMap, BmLocalSearch } from 'vue-baidu-map'
    // import coordtransform from 'coordtransform'
    // 请求接口 api
    import api from '@/merchant-bd/api/main'
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    // import { apiUrl, fetch } from '@/server/getData'
    // textCell 组件
    import textCell from '@/merchant-bd//components/textCell'
    // 引入地址组件
    import distPicker from '@/merchant-bd/components/distPicker/distPicker'
    // 通用弹窗组件
    import 'swiper/css/swiper.css'

    export default {
        name: 'whiteList',
        components: {
            textCell,
            distPicker,
            // BaiduMap,
            // BmLocalSearch,
            alertOverlay
        },
        data () {
            return {
                jdPin: '',
                school: '',
                pin: '',
                distPickerShowFlag: false,
                merchantAddress: {
                    city: '',
                    cityId: '',
                    country: '',
                    countryId: '',
                    province: '',
                    provinceId: '',
                    town: '',
                    townId: 0
                },
                showPopup: false,
                itemsQualification: [],
                schoolList: [],
                merchantLat: '',
                merchantLng: '',
                popupTitleQualification: '请选择学校',
                defaultIndexQualification: 0,
                visibleItemCountQualification: 4,
                itemHeightQualification: 36,
                showWarning: false,
                shopName: this.$route.query.shopName || '',
                questionText: this.$route.query.type !== 1 ? '1、请准确复制自己的京东用户名（京东PIN）2、登陆梨涡App时用该京东用户名（京东PIN）的实名手机号接受验证码。' : '1、请引导商家准确复制京东用户名（京东PIN）2、引导商家登陆梨涡App时用该京东用户名（京东PIN）的实名手机号接受验证码。'
            }
        },
        created () {
            this.init()
        },
        computed: {
            address () {
                return (
                    (this.merchantAddress.province
                        ? this.merchantAddress.province
                        : '') 
                    + (this.merchantAddress.city
                        ? `/${this.merchantAddress.city}`
                        : '') 
                    + (this.merchantAddress.country
                        ? `/${this.merchantAddress.country}`
                        : '') 
                    + (this.merchantAddress.town
                        ? `/${this.merchantAddress.town}`
                        : '')
                )
            }
        },
        watch: {},
        methods: {
            // 初始化数据
            init () {
                const data = {
                    userCode: this.$route.query.userCode,
                    type: this.$route.query.type.toString()
                }
                // 有staffId 走代理接口 无 走BD接口
                const requestURL = this.$route.query.staffId ? 'queryAgentSchoolWhiteList' : 'queryBDSchoolWhiteList'
                api.white[requestURL](data, res => {
                    console.log('res:', res)
                    if (res.data.pin) this.pin = `已绑定${res.data.pin}`
                    this.jdPin = res.data.pin
                    this.school = res.data.schoolName
                })
            },
            // 地图初始化
            initMap ({ BMap, map }) {
                console.log('BMap, map----->', BMap, map)
                this.BMap = BMap
                this.map = map
            },
            // 选择地址
            chooseAddress () {
                // 选择学校所在地址
                console.log('选择学校所在地址')
                this.distPickerShowFlag = true
            },
            // 选择学校
            chooseSchool () {
                // 选择学校
                console.log('选择学校')
                if (this.itemsQualification.length > 0) {
                    // this.flag = item
                    this.popupTitleQualification = '请选择学校'
                    this.showPopup = true
                } else {
                    this.$dialog.alert({
                        message: '当前地址无学校，请重新选择'
                    })
                    return ''
                }
            },
            // 地址选择
            distPickerSelect (address) {
                console.log(address)
                this.school = ''
                this.itemsQualification = []
                this.distPickerClose()
                this.merchantAddress = {
                    city: address.city ? address.city : '',
                    cityId: address.cityId ? address.cityId : '',
                    country: address.country ? address.country : '',
                    countryId: address.countryId ? address.countryId : '',
                    province: address.province ? address.province : '',
                    provinceId: address.provinceId ? address.provinceId : '',
                    town: address.town ? address.town : '',
                    townId: address.townId ? address.townId : 0
                }
                const data = {
                    province: address.province ? address.province : '',
                    provinceId: address.provinceId ? address.provinceId : '',
                    city: address.city ? address.city : '',
                    cityId: address.cityId ? address.cityId : ''
                }
                api.white.queryBDSchoolInfoListByLevAddr(data, res => {
                    console.log('res:', res)
                    this.schoolList = res.data.list
                    this.schoolList.forEach(value => this.itemsQualification.push(value.schoolName))
                    // this.showPopup = true
                })
            },
            // 关闭地址列表
            distPickerClose () {
                this.distPickerShowFlag = false
            },
            // 学校选择页面
            pickChange () {
                console.log('pickChange')
            },
            // 学校选择确定
            onConfirm (val) {
                console.log('确定事件', val)
                this.school = val
                this.showPopup = false
                return val
            },
            // 确定提交
            commit () {
                console.log('确定提交')

                const schoolItem = this.schoolList.filter(value => value.schoolName === this.school)
                const data = {
                    pin: this.jdPin,
                    schoolId: schoolItem[0].schoolId,
                    schoolName: schoolItem[0].schoolName,
                    userCode: this.$route.query.userCode,
                    type: this.$route.query.type.toString()
                }

                // 根据不同情况请求 不同接口
                const requestURL = this.$route.query.staffId ? 'addAgentCampusWhiteList' : 'addBDCampusWhiteList'
                api.white[requestURL](data, res => {
                    console.log('res:', res)
                    // 提交成功后 跳转到上一页面
                    this.$router.go(-1)
                })
            },
            // 展示弹窗事件
            showWarningEvent () {
                console.log()
                this.showWarning = true
            },
            // 弹窗确定事件
            confirmClick () {
                this.showWarning = false
            }
        }
    }
</script>

<style lang="scss" scoped>
.white-list-container {
    width: 100%;
    height: 100%;
    background-color: #F5F8FC;

    .white-group-box {
        width: 100%;
        height: auto;
        min-height: 3.1rem;
        background-color: #FFFFFF;
        // padding: 0 0.24rem;
        // box-sizing: border-box;

        .help-box {
            height: 0.36rem;
            font-size: 0.16rem;
            color: #848484;
            padding: 0 0.17rem;
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .title-warning {
            font-size: 0.13rem;
            line-height: 0.13rem;
            font-weight: 400;
            color: #F0250F;
            padding: 0 0.24rem 0.16rem 0.24rem;
        }

        .title-field-box, .title-field-box-1 {
            width: 100%;
            padding: 0 0.24rem;
            box-sizing: border-box;

            /deep/ .van-cell {
                padding: 0.07rem 0.07rem;
                background: rgba(246,246,246,1);
                border: 1px solid rgba(230,230,230,1);
                // line-height: 0.22px;
            }

            /deep/ .van-field__control {
                font-size: 0.15rem;
                line-height: 0.24rem;
                // height: 0.16rem;
                font-weight: 300;
                color: #848484;
            }
        }
        
        .title-field-box:last-child {
            padding-bottom: 0.28rem;
        }
    }

    .white-button-box {
        width: 100%;
        height: auto;
        padding: 0.28rem 0.12rem;
        box-sizing: border-box;

        .white-btn {
            width: 100%;
            height: 0.46rem;
            background: linear-gradient(270deg,rgba(222,49,33,1) 0%,rgba(236,86,42,1) 100%);
            border-radius: 0.28rem;
            font-size: 0.16rem;
            color: #FFFFFF;
            font-weight: 400;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /deep/ .van-button__text {
            font-size: 0.16rem;
        }
    }
}
</style>
