<template>
    <div class="white-entry-container">
        <table-cell
            :titles="titles"
            :isJump="true"
            :isBold="false"
            :isGayBGColor="false"
            @click="jumpRouter"
        />

        <div class="title-warning">
            *您可以对管理的商户设置白名单，这样商户就可以在梨涡APP预览选定学校周边商家
        </div>

        <div v-if="showStatus" class="exit-button" @click="exitLogin">退出登录</div>
    </div>
</template>

<script>
    // 引入 table-cell 组件
    import tableCell from '@/merchant-bd/components/tableCell'

    export default {
        name: 'whiteEntry',
        components: {
            tableCell
        },
        data () {
            return {
                titles: {
                    title1: '白名单设置'
                },
                showStatus: true
            }
        },
        created () {
            if (this.$route.query.type === '2') {
                this.showStatus = false
            }
        },
        methods: {
            jumpRouter () {
                // 路由跳转
                console.log('路由跳转')
                this.$router.push({
                    name: '/white',
                    query: {
                        staffId: this.$route.query.staffId,
                        userCode: this.$route.query.staffId || this.$route.query.userCode,
                        type: this.$route.query.type ? this.$route.query.type.toString() : '3',
                        shopName: this.$route.query.shopName
                    }
                })
            },
            // 退出登录
            exitLogin () {
                // 退出登录
                console.log('退出登录')
                localStorage.clear()
                const localUrl = encodeURIComponent(window.location.href)
                window.location.href = `//plogin.m.jd.com/cgi-bin/ml/mlogout?appid=566&wxautologin=false&returnurl=${localUrl}/${1}`
            }
        }
    }
</script>

<style lang="scss" scoped>
.white-entry-container {
    width: 100%;
    height: 100%;
    background-color: #F5F8FC;

    .title-warning {
        font-size: 0.13rem;
        line-height: 0.2rem;
        font-weight: 400;
        color: #F0250F;
        padding: 0.08rem 0.12rem;
    }

    .exit-button {
        margin-top: 0.2rem;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 0.5rem;
        background-color: #FFFFFF;
        font-size: 0.15rem;
        line-height: 0.15rem;
        font-weight: 400;
        color: #2E2D2D;
    }
}
</style>
