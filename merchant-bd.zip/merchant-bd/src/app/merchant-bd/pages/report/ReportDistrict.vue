<template>
    <report dutyType="1"></report>
</template>

<script>
    import report from './report'

    export default {
        name: 'ReportDistrict',
        components: {
            report
        }
    }
</script>

<style scoped>

</style>
