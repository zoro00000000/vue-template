<template>
    <div class="report-main">
<!--        导航进入个人页面-->
        <cell-iteam @click="goPersonal"
                    :icon="reportInfo.userImg | imageLoadFilter"
                    :name="reportInfo.userName"
                    :duty="getDuty(reportInfo)"
                    :sum="dutyType != ENUM.PROFESSIONAL ? reportInfo.maintainCircleNum : ''"
                    :hasNext="true">
        </cell-iteam>
        <div class="selected">
                <van-dropdown-menu>
                    <van-dropdown-item v-model="personnelSelectValue" :options="personnel"></van-dropdown-item>
                    <van-dropdown-item v-model="yearSelectValue" :options="years"></van-dropdown-item>
                    <van-dropdown-item v-model="monthSelectValue" :options="monthsList"></van-dropdown-item>
                </van-dropdown-menu>
            <div style="clear: both"></div>
        </div>
        <div class="panel_report">
            <div class="panel_report_left">
                <div class="panel_report_left_left">
                    {{signedCount}}
                </div>
                <div class="panel_report_title">
                    签约数
                </div>
            </div>
            <div class="split"></div>
            <div class="panel_report_right">
                <div class="panel_report_right_left">
                    {{visitCount}}
                </div>
                <div class="panel_report_title">
                    拜访数
                </div>
            </div>
            <div style="clear: both"></div>
        </div>
        <div class="echart" ref="echarts1"></div>
        <div style="margin-bottom: .15rem"></div>
        <div class="panel_report">
            <div class="panel_report_left">
                <div class="panel_report_left_left">
                    {{rechangeCount | toFixed2}}
                </div>
                <div class="panel_report_title">
                    充值金额（元）
                </div>
            </div>
            <div class="split"></div>
            <div class="panel_report_right">
                <div class="panel_report_right_left">
                    {{transactionCount | toFixed2}}
                </div>
                <div class="panel_report_title">
                    交易金额（元）
                </div>
            </div>
            <div style="clear: both"></div>
        </div>
        <div class="echart" ref="echarts2"></div>
        <div class="container" v-if="dutyType == ENUM.PROFESSIONAL">
            <div class="show_left">
                 <data-pane :number="stateInfo[0].number"
                            :desc="stateInfo[0].desc"
                            class="fixed"
                            :class="selectedPanel=== -1? 'active' : ''"
                            @go="getDataInfos(stateInfo[0].order)">
                 </data-pane>
            </div>
            <div class="show_right">
                <div class="controller">
                    <data-pane v-for="state in stateInfo.slice(1)"
                               :key="state.order"
                               :number="state.number"
                               :desc="state.desc"
                               @go="getDataInfos(state.order)"
                               :class="selectedPanel === state.order ? 'active':''"
                               class="panel" >
                    </data-pane>
                </div>
            </div>
        </div>
        <pullDownRefresh @scroll="handleScroll" class="pull-container" :style="{minHeight: dutyType == ENUM.PROFESSIONAL ? '10vh' : ''}">
            <!--        大区-->
            <div v-if="dutyType == ENUM.DISTRICT_SUPERVISOR">
                <cell-iteam
                        v-for="(item, index) in numberReport"
                        :key="index"
                        :icon="item.userImg | imageLoadFilter"
                        :name="item.userName"
                        :sum="item.numberCount"
                        :duty="item.deptName"
                        @click="handleClick(item.positionId, item.userERP)"
                >
                </cell-iteam>

            </div>
            <!-- 省主管类型-->
            <div v-else-if="dutyType == ENUM.PROVINCIAL_SUPERVISOR">
                <cell-iteam
                        v-for="(item, index) in numberReport"
                        :key="index"
                        :icon="item.userImg | imageLoadFilter"
                        :name="item.userName"
                        :sum="item.numberCount"
                        :duty="item.deptName"
                        @click="handleClick(item.positionId, item.userERP)">
                </cell-iteam>

            </div>
            <!-- 个人类型样式-->
            <div v-else>
                <cell-iteam
                        v-for="(item, index) in personalMerchantList"
                        :key="index"
                        :alias="true"
                        :icon="item.circleImg | imageLoadFilter"
                        :name="item.circleName | textLengthFilter(6)"
                        :duty="item.address"
                        :comment="item.pollingCount"
                        :date="item.time | dateFilter('YYYY.MM.DD')"
                        :status="getStatusByOrder(item.status)"
                        @click="handleClick(4, item.circleId, item.status)"
                        @phoneClick="phoneClickHandle(item.phone)"

                >
                </cell-iteam>
            </div>
        </pullDownRefresh>
<!--        只有查看的是自己时 才显示新增商家-->
        <button v-if="currentErp == erp" class="btn" @click="$router.push('/merchantEntry')">+ &nbsp; 新增商家</button>
    </div>
</template>

<script>
    import dayjs from 'dayjs'
    import JME from '@/merchant-bd/utils/jdme.js'
    import { getUrlString, amountFormat, dateFormat } from '@/merchant-bd/utils/tools'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    import { ENUMLIST, MONTHLIST } from '../enum'
    import cellIteam from '../layout/iteam'
    import dataPane from '../layout/DataPanel'
    import pullDownRefresh from '../../components/scroll/pullDownRefresh'

    const echarts = require('echarts/lib/echarts')
    require('echarts/lib/component/tooltip')
    require('echarts/lib/chart/line')

    const LOADDATATRIGGERBYSELECT = true // 由选择人员列表

    const echartOption = {
        // 坐标指示器
        tooltip: {
            trigger: 'axis'
        },
        // x轴数据
        xAxis: {
            data: [],
            axisLine: {
                show: false
            },
            axisTick: {
                show: false
            },
            axisLabel: {
                formatter (value, index) {
                    return dateFormat(value, index)
                }
            }
        },
        // y轴数据
        yAxis: {
            boundaryGap: false,
            splitLine: {
                show: false
            },
            axisLine: {
                show: false
            },
            axisTick: {
                show: false
            },
            axisLabel: {
                formatter (value, index) {
                    return amountFormat(value, index)
                }
            }
        },
        series: [
            {
                name: '签约数',
                type: 'line',
                data: [1, 2, 3, 4],
                color: '#1495EB'
            },
            {
                name: '拜访数',
                type: 'line',
                data: [5, 20, 100, 100],
                color: '#F23D29'
            }]
    }

    export default {
        name: 'report',
        components: {
            cellIteam,
            dataPane,
            pullDownRefresh
        },
        props: {
            dutyType: {
                default () {
                    return ENUMLIST.PROFESSIONAL
                }
            }
        },
        data () {
            return {
                currentErp: '', // 当前登录用户的erp
                erp: '', // 所查看者的erp
                personnelSelectValue: 0,
                personnel: [{ text: '全部人员', value: 0 }],
                yearSelectValue: 2020,
                years: [{ text: '2019年', value: 2019 }, { text: '2020年', value: 2020 }, { text: '2021年', value: 2021 }],
                monthSelectValue: dayjs().month() + 1,
                monthsList: MONTHLIST,
                ENUM: ENUMLIST,
                defaultImg: require('@/merchant-bd/assets/img/person.png'),
                // 初始状态->0
                // 待扫码->1
                // 已自助开店->2
                // 待实名->3
                // 实名审核中->21
                // 实名未通过->22
                // 待上传资质->23
                // 资质审核中->31
                // 资质未通过->32
                // 待签约->33
                // 待上线->41
                // 待首充->50
                // 已首充->61
                // 已冻结->70
                stateInfo: [
                    {
                        number: 0,
                        desc: '总览',
                        order: -1,
                        field: 'all'
                    },
                    {
                        number: 0,
                        desc: '初始状态',
                        order: 0,
                        field: 'initializationCount'
                    },
                    {
                        number: 0,
                        desc: '待扫码',
                        order: 1,
                        field: 'pendingCodeCount'
                    },
                    // {
                    //     number: 0,
                    //     desc: '已自助开店',
                    //     order: 2,
                    //     field: 'selfCount'
                    // },
                    {
                        number: 0,
                        desc: '待实名',
                        order: 3,
                        field: 'pendingRealNameCount'
                    },
                    {
                        number: 0,
                        desc: '实名审核中',
                        order: 21,
                        field: 'realNameIngCount'
                    },
                    {
                        number: 0,
                        desc: '实名未通过',
                        order: 22,
                        field: 'realNameFailedCount'
                    },
                    {
                        number: 0,
                        desc: '待上传资质',
                        order: 23,
                        field: 'qualificationUploadCount'
                    },
                    {
                        number: 0,
                        desc: '资质审核中',
                        order: 31,
                        field: 'pendingAudited'
                    },
                    {
                        number: 0,
                        desc: '资质未通过',
                        order: 32,
                        field: 'disqualificationCount'
                    },
                    {
                        number: 0,
                        desc: '待签约',
                        order: 33,
                        field: 'pendingSignedCount'
                    },
                    {
                        number: 0,
                        desc: '待上线',
                        order: 41,
                        field: 'pendingOnlineCount'
                    },
                    {
                        number: 0,
                        desc: '待首充',
                        order: 50,
                        field: 'pendingFirstChargeCount'
                    },
                    {
                        number: 0,
                        desc: '已首充',
                        order: 61,
                        field: 'firstChargeCount'
                    },
                    {
                        number: 0,
                        desc: '已冻结',
                        order: 70,
                        field: 'freezeCount'
                    }
                ],
                selectedPanel: -1,
                mouth: 1,
                userInfo: {},
                reportInfo: {}, // 整体战报数据对象
                numberReport: [], // 大区主管 省主管下属的列表
                personalMerchantList: [], // 个人维护的商家列表
                personalSummarReport: {}, // 个人折线数据
                signedCount: 0,
                visitCount: 0,
                transactionCount: 0, // 交易金额
                rechangeCount: 0, // 充值金额
                // 大区主管 省主管下属列表， 个人维护的商家列表是需要分页的
                pageSize: 10,
                pageNumber: 1,
                hasMore: true,
                isFetching: false

            }
        },
        // 开发时做控制开关使用
        created () {
            // 1. 调接口查看是否是BD人员
            const { erp } = this.$route.params
            this.currentErp = getUrlString('sid') || JME.getUserNameForCookie()//
            this.erp = erp // 被查询者的erp
            // this.queryBDUserInfoByERP()
            this.queryBDUserNumberInfoByERP() // 查询下属信息
        },
        mounted () {
            this.myChart1 = echarts.init(this.$refs.echarts1)
            this.myChart2 = echarts.init(this.$refs.echarts2)
            this.loadData(this.erp)
        },
        watch: {
            personnelSelectValue (v) {
                // console.log('personnelSelectValue:', v)
                this.personalMerchantList = []
                this.selectedPanel = -1
                this.hasMore = true
                this.pageNumber = 1
                this.loadData(v || this.erp, LOADDATATRIGGERBYSELECT)
            },
            monthSelectValue () {
                // console.log('personnelSelectValue:', v)
                this.personalMerchantList = []
                this.selectedPanel = -1
                this.hasMore = true
                this.pageNumber = 1
                this.loadData(this.personnelSelectValue || this.erp, LOADDATATRIGGERBYSELECT)
            },
            yearSelectValue () {
                this.personalMerchantList = []
                this.selectedPanel = -1
                this.hasMore = true
                this.pageNumber = 1
                this.loadData(this.personnelSelectValue || this.erp, LOADDATATRIGGERBYSELECT)
            },
            selectedPanel (v) {
                // console.log('selectedPanel:', v)
                this.queryBDNumberReportInfoByERP(v, this.personnelSelectValue || this.erp) // 获取个人维护的商家列表
            }
        },
        computed: {
            days () {
                const daysArray = []
                const mouthDays = 31
                for (let i = 0; i <= mouthDays; i++) {
                    daysArray.push(i + 1)
                }
                return daysArray
            },
            count () {
                let sum = 0
                this.stateInfo.forEach(iteam => {
                    sum += iteam.number
                })
                return sum
            }
        },
        methods: {
            // 在滚动加载时会调用该函数，目的是为了更新 大区负责人 省负责人的下属列表 以及 个人名下维护的商家列表
            // 最终确认，由于领导的下属数目有限，会在100 以内，所以这里下属列表是全量吐出的，只有个人维护的商家列表需要分页加载
            scrollLoadData () {
                // if (this.dutyType == ENUMLIST.DISTRICT_SUPERVISOR) {
                //     this.queryBDManagerReportInfoByERP(this.personnelSelectValue || this.erp)
                // } else if (this.dutyType == ENUMLIST.PROVINCIAL_SUPERVISOR) {
                //     this.queryBDProvinceManagerReportInfoByERP(this.personnelSelectValue || this.erp)
                // } else {
                //
                // }
                if (this.dutyType == ENUMLIST.PROFESSIONAL) {
                    this.queryBDNumberReportInfoByERP(this.selectedPanel, this.personnelSelectValue || this.erp)
                }
            },

            // 该接口会在首次进入页面的时候调用该接口
            // 选择了人员 或者 选择时间后需要重新刷新该页面
            // mode
            loadData (erp, mode) {
                if (mode !== LOADDATATRIGGERBYSELECT && this.dutyType == ENUMLIST.DISTRICT_SUPERVISOR) {
                    this.queryBDManagerReportInfoByERP(erp).then(() => {
                        let {
                            signCounts = [], visitCount = [], rechangeCount = [], transactionCount = []
                        } = this.reportInfo
                        const { dates = [] } = this.reportInfo
                        if (!signCounts.length) {
                            signCounts = new Array(dates.length).fill(0)
                        }
                        if (!visitCount.length) {
                            visitCount = new Array(dates.length).fill(0)
                        }
                        if (!rechangeCount.length) {
                            rechangeCount = new Array(dates.length).fill(0)
                        }
                        if (!transactionCount.length) {
                            transactionCount = new Array(dates.length).fill(0)
                        }
                        const configOption = {
                            ...echartOption,
                            xAxis: { ...echartOption.xAxis, data: dates },
                            series: [{
                                name: '签约数',
                                type: 'line',
                                data: signCounts,
                                color: '#1495EB'
                            }, {
                                name: '拜访数',
                                type: 'line',
                                data: visitCount,
                                color: '#F23D29'
                            }]
                        }

                        const configOption2 = {
                            ...echartOption,
                            xAxis: { ...echartOption.xAxis, data: dates },
                            series: [{
                                name: '充值金额',
                                type: 'line',
                                data: rechangeCount,
                                color: '#1495EB'
                            }, {
                                name: '交易金额',
                                type: 'line',
                                data: transactionCount,
                                color: '#F23D29'
                            }]
                        }
                        this.signedCount = signCounts.reduce((prev, cur) => prev + cur, 0)
                        this.visitCount = visitCount.reduce((prev, cur) => prev + cur, 0)
                        this.rechangeCount = rechangeCount.reduce((prev, cur) => prev + cur, 0)
                        this.transactionCount = transactionCount.reduce((prev, cur) => prev + cur, 0)
                        this.myChart1.setOption(configOption)
                        this.myChart2.setOption(configOption2)
                    })
                } else if (mode !== LOADDATATRIGGERBYSELECT && this.dutyType == ENUMLIST.PROVINCIAL_SUPERVISOR) {
                    this.queryBDProvinceManagerReportInfoByERP(erp).then(() => {
                        let {
                            signCounts = [], visitCount = [], rechangeCount = [], transactionCount = []
                        } = this.reportInfo
                        const { dates = [] } = this.reportInfo
                        if (!signCounts.length) {
                            signCounts = new Array(dates.length).fill(0)
                        }
                        if (!visitCount.length) {
                            visitCount = new Array(dates.length).fill(0)
                        }
                        if (!rechangeCount.length) {
                            rechangeCount = new Array(dates.length).fill(0)
                        }
                        if (!transactionCount.length) {
                            transactionCount = new Array(dates.length).fill(0)
                        }
                        const configOption = {
                            ...echartOption,
                            xAxis: { ...echartOption.xAxis, data: dates },
                            series: [{
                                name: '签约数',
                                type: 'line',
                                data: signCounts,
                                color: '#1495EB'
                            }, {
                                name: '拜访数',
                                type: 'line',
                                data: visitCount,
                                color: '#F23D29'
                            }]
                        }
                        const configOption2 = {
                            ...echartOption,
                            xAxis: { ...echartOption.xAxis, data: dates },
                            series: [{
                                name: '充值金额',
                                type: 'line',
                                data: rechangeCount,
                                color: '#1495EB'
                            }, {
                                name: '交易金额',
                                type: 'line',
                                data: transactionCount,
                                color: '#F23D29'
                            }]
                        }
                        this.signedCount = signCounts.reduce((prev, cur) => prev + cur, 0)
                        this.visitCount = visitCount.reduce((prev, cur) => prev + cur, 0)
                        this.rechangeCount = rechangeCount.reduce((prev, cur) => prev + cur, 0)
                        this.transactionCount = transactionCount.reduce((prev, cur) => prev + cur, 0)
                        this.myChart1.setOption(configOption)
                        this.myChart2.setOption(configOption2)
                    })
                } else {
                    this.queryPersonalSummarReport(erp).then(() => {
                        let {
                            signCounts = [], visitCount = [], rechangeCount = [], transactionCount = []
                        } = this.personalSummarReport
                        const { dates = [] } = this.personalSummarReport
                        if (!signCounts.length) {
                            signCounts = new Array(dates.length).fill(0)
                        }
                        if (!visitCount.length) {
                            visitCount = new Array(dates.length).fill(0)
                        }
                        if (!rechangeCount.length) {
                            rechangeCount = new Array(dates.length).fill(0)
                        }
                        if (!transactionCount.length) {
                            transactionCount = new Array(dates.length).fill(0)
                        }
                        const configOption = {
                            ...echartOption,
                            xAxis: { ...echartOption.xAxis, data: dates },
                            series: [{
                                name: '签约数',
                                type: 'line',
                                data: signCounts,
                                color: '#1495EB'
                            }, {
                                name: '拜访数',
                                type: 'line',
                                data: visitCount,
                                color: '#F23D29'
                            }]
                        }
                        const configOption2 = {
                            ...echartOption,
                            xAxis: { ...echartOption.xAxis, data: dates },
                            series: [{
                                name: '充值金额',
                                type: 'line',
                                data: rechangeCount,
                                color: '#1495EB'
                            }, {
                                name: '交易金额',
                                type: 'line',
                                data: transactionCount,
                                color: '#F23D29'
                            }]
                        }
                        this.signedCount = signCounts.reduce((prev, cur) => prev + cur, 0)
                        this.visitCount = visitCount.reduce((prev, cur) => prev + cur, 0)
                        this.rechangeCount = rechangeCount.reduce((prev, cur) => prev + cur, 0)
                        this.transactionCount = transactionCount.reduce((prev, cur) => prev + cur, 0)
                        this.myChart1.setOption(configOption)
                        this.myChart2.setOption(configOption2)
                    })
                    // mode == true 表示是选择人员后触发的数据更新
                    // if (mode != LOADDATATRIGGERBYSELECT) {
                    //     this.queryPersonalReport() // 获取个人基本信息
                    // }
                    if (this.dutyType == ENUMLIST.PROFESSIONAL) {
                        this.queryPersonalReport() // 获取个人基本信息
                        this.queryBDNumberReportInfoByERP(this.selectedPanel, this.personnelSelectValue || this.erp) // 获取个人维护的商家列表
                    }
                }
            },
            queryBDUserInfoByERP () {
                // console.log('queryBDUserInfoByERP')
                this.fetchFinish = false
                fetch.get({
                    url: apiUrl.queryBDUserInfoByERP,
                    data: {
                        erp: this.erp
                    }
                }, res => {
                    // console.log(res)
                    if (res.result && res.result.code === '0000') {
                        this.userInfo = res.data
                    }
                })
            },
            // 获取下属信息
            queryBDUserNumberInfoByERP () {
                fetch.get({
                    url: apiUrl.queryBDUserNumberInfoByERP,
                    data: {
                        erp: this.erp
                    }
                }, res => {
                    if (res.result && res.result.code === '0000') {
                        // this.userInfo = res.data
                        if (this.dutyType != ENUMLIST.PROFESSIONAL) {
                            const p = res.data ? res.data.map(item => ({
                                text: item.userName,
                                value: item.userERP
                            })) : []
                            p.unshift({
                                text: '全部人员',
                                value: 0
                            })
                            this.personnel = p
                        } else {
                            this.personnel = [{
                                text: '全部人员',
                                value: 0
                            }]
                        }
                    }
                })
            },
            // 大区主管
            // 该接口返回的信息包括 大区主管的个人信息 折线图信息 以及 下属信息[下属信息不再需要分页加载，可以全量返回]
            queryBDManagerReportInfoByERP (erp) {
                const t = this.getDate(this.yearSelectValue, this.monthSelectValue)
                return fetch.get({
                    url: apiUrl.queryBDManagerReportInfoByERP,
                    data: {
                        erp,
                        from: t[0],
                        to: t[1] + 86400000
                    }
                }, res => {
                    if (res.result && res.result.code === '0000') {
                        const { numberReport } = res.data
                        this.reportInfo = res.data
                        this.numberReport = numberReport
                    }
                }, res => {
                    console.log(res)
                })
            },
            // 省主管
            queryBDProvinceManagerReportInfoByERP (erp) {
                const t = this.getDate(this.yearSelectValue, this.monthSelectValue)
                return fetch.get({
                    url: apiUrl.queryBDProvinceManagerReportInfoByERP,
                    data: {
                        erp,
                        from: t[0],
                        to: t[1] + 86400000
                    }
                }, res => {
                    if (res.result && res.result.code === '0000') {
                        const { numberReport } = res.data
                        this.reportInfo = res.data
                        this.numberReport = numberReport
                    }
                }, res => {
                    console.log(res)
                })
            },
            // 个人 维护的商家列表
            queryBDNumberReportInfoByERP (status, erp) {
                const t = this.getDate(this.yearSelectValue, this.monthSelectValue)
                this.isFetching = true
                const p = {
                    erp: erp || this.erp,
                    from: t[0],
                    to: t[1] + 86400000,
                    // status: status == -1 ? '' : status,
                    size: this.pageSize,
                    currentPage: this.pageNumber
                }
                if (status != -1) {
                    p.status = status
                }
                return fetch.get({
                    url: apiUrl.queryBDNumberReportInfoByERP,
                    data: p
                }, res => {
                    if (res.result && res.result.code === '0000') {
                        this.isFetching = false
                        this.pageNumber++
                        if (!res.data) {
                            this.hasMore = false
                        } else if (res.data.length < this.pageSize) {
                            this.hasMore = false
                        }
                        if (res.data) {
                            this.personalMerchantList = this.personalMerchantList.concat(res.data)
                        }
                    }
                }, () => {
                    this.isFetching = false
                })
            },
            // 个人战报信息汇总 折线图
            queryPersonalSummarReport (erp) {
                // console.log('queryPersonalSummarReport')
                const t = this.getDate(this.yearSelectValue, this.monthSelectValue)
                let type = 1 // 表示不包含下属
                if (this.dutyType == ENUMLIST.PROFESSIONAL) {
                    // 个人页，只展示个人信息
                    type = 1
                } else if (this.personnelSelectValue) {
                    type = 1
                } else {
                    type = 2 // 大区战报中的全部选项
                }
                return fetch.get({
                    url: apiUrl.queryPersonalSummarReport,
                    data: {
                        erp,
                        from: t[0],
                        to: t[1] + 86400000,
                        type // 是否包含下属
                    }
                    // erp: 'liyanan70',
                    // from: 1575360832488,
                    // to: 1577952832488
                }, res => {
                    // console.log(res)
                    if (res.result && res.result.code === '0000') {
                        this.personalSummarReport = res.data
                    }
                }, res => {
                    console.log(res)
                })
            },
            // 个人基础信息
            queryPersonalReport () {
                const t = this.getDate(this.yearSelectValue, this.monthSelectValue)
                return fetch.get({
                    url: apiUrl.queryPersonalReport,
                    data: {
                        erp: this.erp,
                        from: t[0],
                        to: t[1] + 86400000
                    }
                }, res => {
                    if (res.result && res.result.code === '0000') {
                        this.reportInfo = res.data
                        // res.data.pendingRealNameCount = 123
                        this.stateInfo = this.stateInfo.map(item => {
                            // console.log('res.data[item.field]', item.field, res.data[item.field])
                            let n = 0
                            if (res.data[item.field]) {
                                n = res.data[item.field]
                            }
                            return { ...item, number: n }
                        })
                        const total = this.stateInfo.reduce((total1, cur) => total1 + cur.number, 0)
                        // console.log('total:',total)
                        this.$set(this.stateInfo, 0, { ...this.stateInfo[0], number: total })
                        // console.log(this.stateInfo)
                    }
                }, res => {
                    console.log(res)
                })
            },
            getDuty (reportInfo) {
                if (this.dutyType != this.ENUM.PROFESSIONAL) {
                    if (reportInfo.deptName) {
                        return `${reportInfo.deptName} （下属${reportInfo.numberCount}人）`
                    } else {
                        return ''
                    }
                } else if (reportInfo.deptName) {
                    return `${reportInfo.deptName}`
                } else {
                    return ''
                }
            },
            getDataInfos (order) {
                // console.log('getDataInfos')
                this.personalMerchantList = []
                this.hasMore = true
                this.pageNumber = 1
                this.selectedPanel = order
            },
            handleClick (duty, id, status) {
                // 根据点击条目的erp 和 身份 跳转到不同页面
                // if (duty == ENUMLIST.DISTRICT_SUPERVISOR) {
                //     this.$router.push(`/report-province/${erp}`)
                // } else
                if (duty == ENUMLIST.PROVINCIAL_SUPERVISOR) {
                    this.$router.push(`/report-province/${id}`)
                } else if (duty == ENUMLIST.PROFESSIONAL) {
                    // 跳转到详情页
                    this.$router.push(`/report-personal/${id}`)
                } else {
                    this.$router.push(`/merchantDetails/${id}/${status}`)
                }
            },
            phoneClickHandle (number) {
                window.location.href = `tel:${number}`
            },
            handleScroll () {
                if (this.hasMore && !this.isFetching) {
                    this.scrollLoadData()
                }
            },
            // 前往个人页面 在该页面 不具备导航进入其他页面的功能
            goPersonal () {
                // console.log('dutyType--',this.dutyType)
                if (this.dutyType != ENUMLIST.PROFESSIONAL) {
                    this.$router.push(`/report-personal/${this.erp}`)
                } else {
                    this.$router.push({
                        name: '/white-entry',
                        query: {
                            userCode: this.erp,
                            type: '2'
                        }
                    })
                }
            },
            getDate (year, month) {
                // const year = parseInt(dayjs().format('YYYY'), 10)
                const daysPerMonth = dayjs(`2020-${month}`).endOf('month').get('date')
                const start = dayjs(`${year}-${month}-1`).unix() * 1000
                const end = dayjs(`${year}-${month}-${daysPerMonth}`).unix() * 1000
                // const start = dayjs('2020-01-05').unix() * 1000
                // const end = dayjs('2020-01-07').unix() * 1000
                // console.log(start, end, month)
                // console.log('daysPerMonth:',daysPerMonth)
                return [start, end]
                // return
            },
            getStatusByOrder (order) {
                for (let i = 0; i < this.stateInfo.length; i++) {
                    if (order == 0) {
                        return '初始状态'
                    }
                    if (this.stateInfo[i].order == order) {
                        return this.stateInfo[i].desc
                    }
                }
                return ''
            }

        }
    }
</script>

<style lang="scss" scoped>

    ::-webkit-scrollbar {
        width: 0 !important;
        height: 0;
    }
    .report-main {
        padding-bottom: .8rem;
        /deep/ .van-dropdown-menu {
            background-color: rgba(0,0,0,0);
        }

        .selected_left::after,.selected_right:after{
            content: "";
        }
        .btn{
            width: 100%;
            height: .6rem;
            position: fixed;
            z-index: 1000;
            left: 0;
            bottom: 0;
            font-size: .18rem;
            border: 0px;
            display: block;
            background: linear-gradient(270deg,rgb(222,49,33) 0%,rgb(236,86,42) 100%);
            color: white;
        }

        .btn:active {
            opacity: .8;
        }

        .echart {
            width: 100%;
            height: 2.4rem;
            background-color: white;
        }

        .container{
            width: 100%;
            height: .84rem;
            /*background: #fff;*/
            /*position: sticky;*/
            /*top: 0;*/
            /*z-index: 100;*/
            margin-top: 0.15rem;
            display: flex;

            .show_left {
                width: 33%;
                height: .84rem;
                display: inline-block;
                vertical-align:top;

                .fixed {
                    margin-top: .12rem;
                    margin-left: .12rem;
                }
            }
            // todo 上下滑动待处理
            .show_right{
                width: 67%;
                height: .84rem;
                padding: .12rem 0rem .12rem 0rem;
                white-space: nowrap;
                overflow-x: scroll;
                overflow-y: hidden;
                -webkit-overflow-scrolling: touch;
                -ms-overflow-style: -ms-autohiding-scrollbar;
                overflow-scrolling: touch;
                display: inline-block;
                vertical-align: top;

                .controller {
                    width: 100%;
                    .panel{
                        display: inline-block;
                        vertical-align: top;
                        margin-right: .12rem;
                    }
                }

            }
        }
        .panel_report{
            width: 100%;
            height: .6rem;
            font-size: .15rem;
            position: relative;
            padding-top: .2rem;
            background-color: white;
            border-bottom: 1px solid #EEF1F4;

            .split{
                position: absolute;
                left: 50%;
                top: .2rem;
                float: left;
                width: 0.01rem;
                height: .4rem;
                border-left: 0.01rem solid #EEF1F4;
            }

            .panel_report_left{
                width: 50%;
                line-height: .2rem;
                text-align: center;
                float: left;
            }

            .panel_report_right{
                width: 50%;
                line-height: .2rem;
                text-align: center;
                float: left;
            }
        }

        .panel_report_title {
            color: #BBBBBB;
        }

        .active {
            border: 1px solid #F0250F;
            color: #F0250F;

            /deep/.text-bottom{
                color: red;
            }
        }

        .pull-container{
            margin-top: 0.15rem;
        }
    }
</style>
