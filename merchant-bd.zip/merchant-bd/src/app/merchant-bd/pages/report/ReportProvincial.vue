<template>
    <report dutyType="2"></report>
</template>

<script>
    import report from './report'

    export default {
        name: 'ReportProvincial',
        components: {
            report
        }
    }
</script>

<style scoped>

</style>
