<template>
    <report dutyType="3"></report>
</template>

<script>
    import report from './report'

    export default {
        name: 'ReportPfofessional',
        components: {
            report
        }
    }
</script>

<style scoped>

</style>
