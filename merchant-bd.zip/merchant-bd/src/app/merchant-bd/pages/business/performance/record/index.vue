<template>
    <div class="record-container">
        <record-and-performance :dutyType="dutyType"></record-and-performance>
    </div>
</template>

<script>
    import recordAndPerformance from '../components/recordAndPerformance'
    import { ENUMLIST } from '../../../enum'

    export default {
        name: 'allEmployeePerFormance',
        components: {
            recordAndPerformance
        },
        props: {},
        data () {
            return {
                dutyType: ENUMLIST.TYPE_PERFORMANCE
            }
        },
        created () {},
        mounted () {},
        methods: {}
    }
</script>

<style lang="scss" scoped>

</style>
