<template>
    <div class="record-performance-container">
        <!-- 佣金数据 TODO: 可以封装成组件 -->
        <date-picker :dateSelectVal="dateSelectVal" @dateUpdate="dateUpdate">
        </date-picker>

        <div class="table-title-box">
            <table-cell
                :titles="dutyType === ENU.TYPE_RECORD ? employeeTitles : recordTitle"
                :isJump="false"
                :isBold="true"
                :isGayBGColor="false"
            />

            <table-cell
                v-if="dutyType === ENU.TYPE_RECORD"
                :titles="renovate(employeeSum)"
                :isJump="false"
                :isBold="false"
                :isGayBGColor="true"
            />
        </div>
        
        <div id="scrollBox" 
            v-if="tableList.length > 0"
            class="scroll-box" 
            :class="dutyType === ENU.TYPE_RECORD ? 'scroll-height-1' : 'scroll-height-2'"
        >
            <pull-down-refresh
                id="pullDownBox"
                :threshold="120"
                wrapper="comments-scroll"
                @scroll="fetchMore"
            >
                <!-- <comment-item  v-for="(item, index) in userEvaluateList" :key="index" :data="item"></comment-item> -->
                <table-cell
                    v-for="(item, index) in tableList"
                    :key="index"
                    :titles="item"
                    :isJump="true"
                    @click="jumpEvent(item.staffId || item.merchantId, item.status || 1)"
                    :titleKeys="listKeys2"
                    :isBold="false"
                    :isGayBGColor="false"
                />
            </pull-down-refresh>
        </div>

        <empty-placeholder v-else :class="dutyType === ENU.TYPE_RECORD ? 'scroll-height-1' : 'scroll-height-2'" />
    </div>
</template>

<script>
    import dayjs from 'dayjs'
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    // 引入 table-cell 组件
    import tableCell from '@/merchant-bd/components/tableCell'
    // 引入 日期选择 组件
    import datePicker from '@/merchant-bd/components/datePicker'
    // 数据为空的时候 组件
    import emptyPlaceholder from '@/merchant-bd/components/emptyPlaceholder'
    // api
    import api from '@/merchant-bd/api/main'
    // 默认数据
    import { ENUMLIST, MONTHLIST } from '../../../../enum'

    export default {
        name: 'allEmployeePerFormance',
        components: {
            pullDownRefresh,
            tableCell,
            datePicker,
            emptyPlaceholder
        },
        props: {
            // 角色： 员工业绩1 交易记录2
            dutyType: {
                default () {
                    console.log('ENUMLIST', ENUMLIST.TYPE_RECORD)
                    return ENUMLIST.TYPE_RECORD
                }
            }
        },
        data () {
            return {
                ENU: ENUMLIST,
                yearSelectValue: 2020,
                yearSelectValue2: 2020,
                years: [
                    { text: '2020年', value: 2020 },
                    { text: '2021年', value: 2021 },
                    { text: '2022年', value: 2022 }
                ],
                monthSelectValue: dayjs().month() + 1,
                monthSelectValue2: dayjs().month() + 1,
                monthsList: MONTHLIST,
                employeeTitles: {
                    name: '员工姓名',
                    number: '拓店个数',
                    amount: '商户交易'
                },
                employeeSum: {
                    name: '合计（0人）',
                    number: '0',
                    amount: '0'
                },
                tableList: [],
                listKeys2: this.dutyType === ENUMLIST.TYPE_RECORD ? [
                    'staffName',
                    'addCount',
                    'tradeAmount'
                ] : [
                    'merchantName',
                    'tradeAmount',
                    'version'
                ],
                onload: true,
                recordTitle: {
                    name: '店铺名称',
                    number: '交易金额',
                    amount: '政策版本号'
                },
                dateSelectVal: `${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`,
                currentPage: 1,
                autoFetch: true
            }
        },
        mounted () {
            // 请求入参
            const data = {
                batch: this.deleteChart(this.dateSelectVal, '-'),
                organId: this.$route.query.organId || JSON.stringify(localStorage.getItem('organId')),
                currentPage: this.currentPage,
                pageSize: 15
            }
            if (this.dutyType === ENUMLIST.TYPE_RECORD) this.requestGetBDOrganSummary(data)
            this.fetchMore()
        },
        methods: {
            fetchMore () {
                console.log('fetch more')
                // 请求入参
                const data = {
                    batch: this.deleteChart(this.dateSelectVal, '-'),
                    organId: this.$route.query.organId || JSON.stringify(localStorage.getItem('organId')),
                    staffId: this.$route.query.staffId || JSON.stringify(localStorage.getItem('staffId')),
                    currentPage: this.currentPage,
                    pageSize: 15
                }

                if (this.currentPage > 1 && this.autoFetch) {
                    console.log('auto fetch')
                    const windowH = window.screen.height
                    const pullDownBoxH = document.getElementById('pullDownBox').offsetHeight
                    console.log('windowH:', windowH)
                    console.log('pullDownBoxH:', pullDownBoxH)

                    if (pullDownBoxH && (windowH >= (pullDownBoxH + 150))) {
                        if (this.onload) {
                            this.onload = false
                            if (this.dutyType === ENUMLIST.TYPE_RECORD) {
                                this.requestGetBDStaffAchievement(data)
                            } else {
                                this.requestQueryBDMerchantOrderRecord(data)
                            }
                        }
                    } else {
                        this.autoFetch = false
                        return
                    }
                }

                if (this.onload) {
                    this.onload = false
                    if (this.dutyType === ENUMLIST.TYPE_RECORD) {
                        this.requestGetBDStaffAchievement(data)
                    } else {
                        this.requestQueryBDMerchantOrderRecord(data)
                    }
                }
            },
            // 【商家】 获取 员工业绩总和
            requestGetBDOrganSummary (data) {
                const _this = this
                // 获取 员工业绩 总计
                api.performance.getBDOrganSummary(data, res => {
                    console.log(res)
                    _this.employeeSum = res.data
                })
            },
            // 【商家】 获取 员工业绩列表
            requestGetBDStaffAchievement (data) {
                const _this = this
                // 获取 员工业绩 信息
                api.performance.getBDStaffAchievement(data, res => {
                    _this.onload = true
                    _this.tableList = _this.tableList.concat(res.data)

                    if (res.data.length < data.pageSize) {
                        // 如果没数据了，则暂停刷新
                        _this.onload = false
                    } else {
                        _this.currentPage++
                    }

                    if (_this.autoFetch) {
                        setTimeout(() => {
                            _this.fetchMore()
                        }, 1000) 
                    }
                })
            },
            // 【个人】 获取 商户交易记录
            requestQueryBDMerchantOrderRecord (data) {
                const _this = this
                // 获取 个人 商户交易记录
                api.performance.queryBDMerchantOrderRecord(data, res => {
                    console.log(res)
                    _this.onload = true
                    _this.listKeys2 = [
                        'merchantName',
                        'tradeAmount',
                        'version'
                    ]
                    _this.tableList = _this.tableList.concat(res.data)
                    if (res.data.length < data.pageSize) {
                        // 如果没数据了，则暂停刷新
                        _this.onload = false
                    } else {
                        _this.currentPage++
                    }

                    if (_this.autoFetch) {
                        setTimeout(() => {
                            _this.fetchMore()
                        }, 100) 
                    }
                })
            },
            // 获取日期选择组件2 
            dateUpdate (val) {
                console.log(`已选时间: ${val}`)
                this.dateSelectVal = val
                this.currentPage = 1
                this.tableList = []
                const data = {
                    batch: this.deleteChart(this.dateSelectVal, '-'),
                    organId: this.$route.query.organId || JSON.parse(localStorage.getItem('organId')),
                    staffId: this.$route.query.staffId || JSON.parse(localStorage.getItem('staffId')),
                    currentPage: this.currentPage,
                    pageSize: 15
                }
                if (this.dutyType === ENUMLIST.TYPE_RECORD) {
                    this.requestGetBDOrganSummary(data)
                    this.requestGetBDStaffAchievement(data)
                } else {
                    // this.requestQueryBDAchievementTrack(data)
                    this.requestQueryBDMerchantOrderRecord(data)
                }
            },
            // 跳转路由
            jumpEvent (id, status) {
                if (this.dutyType === ENUMLIST.TYPE_RECORD) {
                    this.$router.push({
                        name: '/business/performance/personal',
                        query: {
                            staffId: id
                        }
                    })
                } else {
                    // this.$router.push({
                    //     name: '/business/performance/company',
                    //     query: {
                    //         organId: id
                    //     }
                    // })
                    this.$router.push({
                        path: `/merchantDetails/${id}/${status}`,
                        query: {
                            staffId: this.$route.query.staffId,
                            merchantId: id,
                            status
                        }
                    })
                }
            },
            // 正则删除字符方法
            deleteChart (val, str) {
                const reg = new RegExp(str)
                const newBatch = val.replace(reg, '')
                return Number(newBatch)
            },
            // 文案显示修复
            renovate (titles) {
                // console.log(titles)
                const newObj = {}
                newObj.staffCount = `合计（${titles.staffCount || '0'}人）`
                newObj.addCount = titles.addCount
                newObj.tradeSummaryAmount = titles.tradeSummaryAmount
                return newObj
            }
        }
    }
</script>

<style lang="scss" scoped>
.record-performance-container {
    // position: absolute;
    width: 100%;
    // height: 100vh;
    // display: flex;
    // flex-direction: column;

    /deep/ .van-dropdown-menu {
		background-color: #F5F8FC;
	}

    .select-box {
        position: fixed;
        top: 0;
        display: flex;
        flex-direction: row;
        width: 100%;
        z-index: 99;
        background-color: #F5F8FC;

        .second-title {
            height: 0.5rem;
            // width: 30%;
            display: flex;
            align-items: center;
            padding: 0 0.13rem;
            font-size: 0.14rem;
            color: #2E2D2D;

        .icon-gold {
            margin-right: 0.07rem;
        }
        }
        .select-date {
            flex: 1;
        }
    }
    
    .table-title-box {
        position: fixed;
        top: 0.5rem;
        width: 100%;
        z-index: 9;
    }

    .scroll-box {
        // padding-top: 1rem;
    }

    .scroll-height-1 {
        padding-top: 1.5rem;
    }

    .scroll-height-2 {
        padding-top: 1rem;
    }
}
</style>
