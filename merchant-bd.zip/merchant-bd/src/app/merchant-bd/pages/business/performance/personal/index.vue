<template>
    <performance :dutyType="2"></performance>
</template>

<script>
    import performance from '../performance'

    export default {
        name: 'company',
        components: {
            performance
        }
    }
</script>

<style lang="scss" scoped>

</style>
