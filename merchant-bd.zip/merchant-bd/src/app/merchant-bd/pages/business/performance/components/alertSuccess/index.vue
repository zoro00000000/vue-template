<template>
    <div class="alert-success-container">
        <div class="success-inner-box">
            <div class="success-img"></div>

            <div class="success-title">
                {{successTitle}}
            </div>

            <slot></slot>

            <div class="success-button" @click="complete">
                {{successBtnTitle}}
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'alertSuccess',
        props: {
            successTitle: {
                type: String,
                default () {
                    return '成功'
                }
            },
            successBtnTitle: {
                type: String,
                default () {
                    return '完成'
                }
            },
            complete: {
                type: Function,
                default () {
                    return function () {}
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
.alert-success-container {
    position: fixed;
    top: 0;
    overflow: hidden;
    width: 100%;
    height: 100vh;
    background-color: #F5F8FC;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 999;

    .success-inner-box {
        width: 100%;
        height: auto;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0 0.3rem;
        box-sizing: border-box;

        .success-img {
            width: 0.8rem;
            height: 0.8rem;
            background: url('../../../../../assets/img/success_img.png') center no-repeat;
            background-size: 100% 100%;
        }

        .success-title {
            font-size: 0.15rem;
            font-weight: 500;
            color: #2E2D2D;
            text-align: center;
            margin-top: 0.28rem;
            // margin-bottom: 0.24rem;
        }
        
        .success-button {
            width: 1.2rem;
            height: 0.4rem;
            border-radius: 0.2rem;
            border: 0.01rem solid #F0250F;
            font-size: 0.15rem;
            font-weight: 400;
            color: #F0250F;
            text-align: center;
            line-height: 0.4rem;
            margin-top: 0.28rem;
        }
    }
}
</style>
