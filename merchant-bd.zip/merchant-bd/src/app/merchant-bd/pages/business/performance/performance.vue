<template>
    <div class="business-performance-container">
        <div class="header-box">
            <!-- duty 标题下方的描述  sum 右侧内容  hasNext 是否展示右侧箭头并开启点击反馈 -->
            <cell-iteam
                @click="headerJumpFun"
                :icon="info.userImg"
                :name="info.userName"
                :duty="getDuty(bussinessInfo)"
                :sum="dutyType !== ENUM.ROLE_EMPLOYEE ? myShoper(info.shopsNum) : ''"
                :hasNext="true"
                clstag="jr|keycount|dl_qyyj|wdsj" 
            >
            </cell-iteam>
        </div>

        <!-- 佣金数据 -->
        <date-picker :clstag="dutyType === ENUM.ROLE_BUSINESS ? 'jr|keycount|dl_qyyj|yjsjsj' : 'jr|keycount|dl_gryj_yjsj|sj'" 
            :dateSelectVal="dateSelectVal" 
            @dateUpdate="dateUpdate1"
        >
            <div class="title-box">
                <div>
                    <van-icon class="icon-gold" name="gold-coin-o" />
                </div>
                <div>
                    {{dutyType === ENUM.ROLE_BUSINESS ? '佣金数据' : '业绩数据' }}
                </div>
            </div>
        </date-picker>

        <div class="echart-tab-box">
            <div class="tab-left-box"
                :class="{ 'tab-active': tabActiveStatus }"
                @click="tabChange(1)"
                :clstag="dutyType === ENUM.ROLE_BUSINESS ? 'jr|keycount|dl_qyyj|tdyj' : 'jr|keycount|dl_gryj|tds'"
            >
                <div class="amount-exploit"
                    :class="{ 'amount-active': tabActiveStatus }"
                >{{amountExploit}}</div>
                <div class="amount-text"
                    :class="{ 'amount-text-active': tabActiveStatus }"
                >{{dutyType === ENUM.ROLE_BUSINESS ? '拓店佣金（元）' : '拓店数'}}</div>
            </div>

            <div class="tab-split"></div>

            <div class="tab-right-box"
                :class="{ 'tab-active': !tabActiveStatus }"
                @click="tabChange(2)"
                :clstag="dutyType === ENUM.ROLE_BUSINESS ? 'jr|keycount|dl_qyyj|shjyyj' : 'jr|keycount|dl_gryj|ssjy'"
            >
                <div class="amount-deal"
                    :class="{ 'amount-active': !tabActiveStatus }"
                >{{amountDeal}}</div>
                <div class="amount-text"
                    :class="{ 'amount-text-active': !tabActiveStatus }"
                >{{dutyType === ENUM.ROLE_BUSINESS ? '商户交易佣金（元）' : '商户交易（元）'}}</div>
            </div>
        </div>

        <div class="echart-box">
            <!-- echart 1 柱状图 -->
            <div v-show="echartsShow" class="echart-1" ref="echarts1"></div>

            <empty-palceholder :loadingStatus="loadingEcharts" v-show="echartsShow === false" />
        </div>

        <!-- 员工业绩 -->
        <date-picker clstag="jr|keycount|dl_qyyj|ygyjsj" 
            :dateSelectVal="dateSelectVal2" 
            @dateUpdate="dateUpdate2"
        >
            <div class="title-box">
                <div>
                    <van-icon class="icon-gold" :name="dutyType === ENUM.ROLE_BUSINESS ? 'user-circle-o' : 'aim'" />
                </div>
                <div>
                    {{ dutyType === ENUM.ROLE_BUSINESS ? '员工业绩' : '业绩追踪' }}
                </div>
            </div>
        </date-picker>

        <!-- 个人 业绩追踪 -->
        <div v-if="dutyType === ENUM.ROLE_EMPLOYEE"  clstag="jr|keycount|dl_gryj_yjzz|sj" class="employee-box">
            <div v-if="personalMerchantList.length > 0">
                <cell-iteam
                    v-for="(item, index) in personalMerchantList"
                    :key="index"
                    :alias="true"
                    :icon="item.imageUrl"
                    :name="item.merchantName"
                    :duty="item.address"
                    :comment="item.polling"
                    :date="dateTool(item.createTime)"
                    :status="showStatus(item.addStatus)"
                    @click="handleClick(item.merchantId, item.status)"
                    @phoneClick="phoneClickHandle(item.phone)"
                >
                </cell-iteam>

                <div class="jump-button"
                    v-if="personalMerchantList.length >= (dutyType === ENUM.ROLE_BUSINESS ? 5 : 3)"
                    @click="getAllPerformance"
                >
                    全部拓店追踪<van-icon name="arrow" />
                </div>
            </div>

            <empty-palceholder :loadingStatus="loadingPerformance" v-else />
        </div>

        <!-- 员工业绩 -->
        <div class="employee-box">
            <table-cell
                :titles="employeeTitles"
                :isJump="false"
                :isBold="true"
                :isGayBGColor="false"
            />

            <table-cell
                v-if="dutyType === ENUM.ROLE_BUSINESS"
                :titles="employeeSum"
                :titleKeys="listKeys"
                :isJump="false"
                :isBold="false"
                :isGayBGColor="true"
            />
            
            <div v-if="tableList.length > 0">
                <table-cell
                    v-for="(item, index) in tableList"
                    :key="index"
                    :titles="item"
                    :isJump="true"
                    @click="jumpEmployeeInfo(item.staffId || item.merchantId, item.status || 1)"
                    :titleKeys="listKeys2"
                    :isBold="false"
                    :isGayBGColor="false"
                />
                <van-button 
                    v-if="tableList.length >= (dutyType === ENUM.ROLE_BUSINESS ? 5 : 3)"
                    clstag="jr|keycount|dl_qyyj|zl"
                    @click="viewAllEvent"
                    class="button-see-all"
                >
                    {{dutyType === ENUM.ROLE_BUSINESS ? '查看全部' : '全部交易追踪'}}<van-icon class="button-arrow" name="arrow" />
                </van-button>
            </div>

            <empty-palceholder :loadingStatus="loadingPerformance" v-else />
        </div>

        <div v-if="dutyType === ENUM.ROLE_BUSINESS" class="status-box">
            <div class="title-box">
                <div>
                    <van-icon class="icon-gold" name="gold-coin-o" />
                </div>
                <div>
                    商户状态
                </div>
            </div>
        </div>

        <date-picker v-else :dateSelectVal="dateSelectVal3" @dateUpdate="dateUpdate3">
            <div class="title-box">
                <div>
                    <van-icon class="icon-gold" name="gold-coin-o" />
                </div>
                <div>
                    商户状态
                </div>
            </div>
        </date-picker>

        <!-- 商户 人员列表 -->
        <div class="business-personal-box" v-if="dutyType === ENUM.ROLE_BUSINESS">
            <pullDownRefresh
                v-if="businessPersonalList.length > 0"
                @scroll="handleScroll(1)" 
                class="pull-container" 
                :style="{minHeight: '10vh'}"
            >
                <cell-iteam
                    v-for="(item, index) in businessPersonalList"
                    :key="index"
                    @click="jumpPersonalPage(item.staffId)"
                    :icon="item.imgUrl"
                    :name="item.name"
                    :duty="item.phone"
                    :sum="item.merchantCount"
                    :hasNext="dutyType !== ENUM.ROLE_EMPLOYEE"
                >
                </cell-iteam>
            </pullDownRefresh>

            <empty-palceholder :loadingStatus="loadingBusiness" v-else />
        </div>

        <!-- 个人 滚动 选项 暂时只在 个人代理的时候展示 -->
        <div class="scroll-tab-box" v-if="dutyType == ENUM.ROLE_EMPLOYEE">
            <div class="show_left">
                <data-pane :number="stateInfo[0].number"
                    :desc="stateInfo[0].desc"
                    class="fixed"
                    :class="selectedPanel=== -1? 'active' : ''"
                    :clstag="stateInfo[0].clstag"
                    @go="getScrollTavInfoStatus ? getScrollTabInfos(stateInfo[0].order) : ''"
                >
                </data-pane>
            </div>
            <div class="show_right">
                <div class="controller">
                    <data-pane v-for="state in stateInfo.slice(1)"
                        :key="state.order"
                        :number="state.number"
                        :desc="state.desc"
                        @go="getScrollTavInfoStatus ? getScrollTabInfos(state.order) : ''"
                        :class="selectedPanel === state.order ? 'active':''"
                        :clstag="state.clstag"
                        class="panel" >
                    </data-pane>
                </div>
            </div>
            <div style="clear: both"></div>
        </div>

        <!-- 个人 商户list -->
        <div v-if="dutyType === ENUM.ROLE_EMPLOYEE">
            <pullDownRefresh
                v-if="personalMerchantList2.length > 0"
                @scroll="handleScroll(2)" 
                class="pull-container" 
                :style="{minHeight: '10vh'}"
            >
                <cell-iteam
                    v-for="(item, index) in personalMerchantList2"
                    :key="index"
                    :alias="true"
                    :icon="item.circleImg"
                    :name="item.circleName"
                    :duty="item.address"
                    :comment="item.pollingCount"
                    :date="dateTool(item.time)"
                    :status="businessStatus(item.status)"
                    @click="handleClick(item.circleId, item.status)"
                    @phoneClick="phoneClickHandle(item.phone)"
                >
                </cell-iteam>
            </pullDownRefresh>
        </div>

        <!-- 遮罩蒙层 -->
        <alert-overlay 
            :show="freezeStatus"
            :alertType="1"
            :headerTitle="'合同到期通知'"
            :contentText="'合同已到期，已无法正常使用系统，请联系相关工作人员处理'"
            :confirmEvent="confirmClick"
            :cancelEvent="cancelClick"
        />
        
        <!-- 账户已冻结 -->
        <alert-overlay 
            :show="freezeIdStatus"
            :alertType="1"
            :headerTitle="'账户冻结通知'"
            :contentText="'企业账户已被冻结，已无法正常使用系统，请联系相关工作人员处理'"
            :confirmEvent="confirmClick"
            :cancelEvent="cancelClick"
        />

        <!-- 底部tabbar -->
        <div class="tabbar-box">
            <tabbar-btn
                v-if="dutyType === ENUM.ROLE_EMPLOYEE && cookiesStaffId !== staffId ? false : true"
                :leftTitle="'企业业绩'"
                :rightTitle="'我的企业'"
                :clickValue="dutyType.toString()"
                @btnClickValue="btnClickValue"
                :custom="dutyType === 2 ? true : false"
            >
                <div class="add-button" :custom="dutyType === 2 ? true : false">
                    <div class="add-icon">
                        <van-icon name="plus" style="{margin-right: '0.03rem'}"/>
                    </div>
                    <div class="add-text">
                        新增商家
                    </div>
                </div>
            </tabbar-btn>
        </div>
	</div>
</template>

<script>
    // 引入 table-cell 组件
    import tableCell from '@/merchant-bd/components/tableCell'
    // 引入 tabbar-btn 组件
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'
    // 引入 蒙层 组件
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    // 引入 日期选择 组件
    import datePicker from '@/merchant-bd/components/datePicker'
    // 数据为空的时候 组件
    import emptyPalceholder from '@/merchant-bd/components/emptyPlaceholder'
    // 引入接口
    import api from '@/merchant-bd/api/main'
    // 时间插件
    import dayjs from 'dayjs'
    // 引入cellitem 组件
    import { imgHost } from '@/merchant-bd/utils/constV'
    import { phoneHide } from '@/merchant-bd/utils/phoneHide'
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    import cellIteam from '../../layout/iteam'
    import dataPane from '../../layout/DataPanel'
    // 默认数据
    import { ENUMLIST } from '../../enum'
    // 引入 ECharts 主模块
    const echarts = require('echarts/lib/echarts')
    // 引入柱状图
    require('echarts/lib/chart/bar')
    // 引入提示框和标题组件
    require('echarts/lib/component/tooltip')
    require('echarts/lib/component/title')

    export default {
        name: 'businessPerformance',
        components: {
            cellIteam,
            dataPane,
            tableCell,
            tabbarBtn,
            alertOverlay,
            datePicker,
            emptyPalceholder,
            pullDownRefresh
        },
        props: {
            // 角色： 商家1 员工2
            dutyType: {
                default () {
                    console.log('ENUMLIST', ENUMLIST.ROLE_BUSINESS)
                    return ENUMLIST.ROLE_BUSINESS
                }
            }
        },
        data () {
            return {
                // 个人信息
                merchantId: 1234567,
                organId: '',
                staffId: '',
                cookiesStaffId: JSON.parse(localStorage.getItem('staffId')) || '',
                parentId: '0',
                userName: '',
                freezeStatus: false,
                freezeIdStatus: false,
                info: {
                    userImg: '',
                    userName: '',
                    shopsNum: 0
                },
                // 职位信息
                bussinessInfo: {
                    deptName: '',
                    numberCount: 7
                },
                // 新增 demo 数据
                ENUM: ENUMLIST,
                // 切换状态 true false
                tabActiveStatus: true,
                amountExploit: 0,
                amountDeal: 0,
                employeeTitles: {
                    name: this.dutyType === ENUMLIST.ROLE_BUSINESS ? '员工姓名' : '店铺名称',
                    number: this.dutyType === ENUMLIST.ROLE_BUSINESS ? '拓店个数' : '交易金额',
                    amount: this.dutyType === ENUMLIST.ROLE_BUSINESS ? '商户交易' : '政策版本号'
                },
                employeeSum: {
                    staffCount: '合计（0人）',
                    addCount: '0',
                    tradeSummaryAmount: '0'
                },
                tableList: this.dutyType === ENUMLIST.ROLE_BUSINESS ? [] : [],
                listKeys: [
                    'staffCount',
                    'addCount',
                    'tradeSummaryAmount'
                ],
                listKeys2: this.dutyType === ENUMLIST.ROLE_BUSINESS ? [
                    'staffName',
                    'addCount',
                    'tradeAmount'
                ] : [
                    'merchantName',
                    'tradeAmount',
                    'version'
                ],
                stateInfo: [
                    {
                        number: 0,
                        desc: '总览',
                        order: -1,
                        field: 'maintainCircleNum',
                        clstag: 'jr|keycount|dl_gryj|zl'
                    },
                    {
                        number: 0,
                        desc: '初始状态',
                        order: 0,
                        field: 'initializationCount',
                        clstag: 'jr|keycount|dl_gryj|cszt'
                    },
                    {
                        number: 0,
                        desc: '待扫码',
                        order: 1,
                        field: 'pendingCodeCount',
                        clstag: 'jr|keycount|dl_gryj|dsaom'
                    },
                    // {
                    //     number: 0,
                    //     desc: '已自助开店',
                    //     order: 2,
                    //     field: 'selfCount'
                    // },
                    {
                        number: 0,
                        desc: '待实名',
                        order: 3,
                        field: 'pendingRealNameCount',
                        clstag: 'jr|keycount|dl_gryj|dshim'
                    },
                    {
                        number: 0,
                        desc: '实名审核中',
                        order: 21,
                        field: 'realNameIngCount',
                        clstag: 'jr|keycount|dl_gryj|smshz'
                    },
                    {
                        number: 0,
                        desc: '实名未通过',
                        order: 22,
                        field: 'realNameFailedCount',
                        clstag: 'jr|keycount|dl_gryj|smwtg'
                    },
                    {
                        number: 0,
                        desc: '待上传资质',
                        order: 23,
                        field: 'qualificationUploadCount',
                        clstag: 'jr|keycount|dl_gryj|dsczz'
                    },
                    {
                        number: 0,
                        desc: '资质审核中',
                        order: 31,
                        field: 'pendingAudited',
                        clstag: 'jr|keycount|dl_gryj|zzshz'
                    },
                    {
                        number: 0,
                        desc: '资质未通过',
                        order: 32,
                        field: 'disqualificationCount',
                        clstag: 'jr|keycount|dl_gryj|zzwtg'
                    },
                    {
                        number: 0,
                        desc: '待签约',
                        order: 33,
                        field: 'pendingSignedCount',
                        clstag: 'jr|keycount|dl_gryj|dqy'
                    },
                    {
                        number: 0,
                        desc: '待上线',
                        order: 41,
                        field: 'pendingOnlineCount',
                        clstag: 'jr|keycount|dl_gryj|dsx'
                    },
                    {
                        number: 0,
                        desc: '待首充',
                        order: 50,
                        field: 'pendingFirstChargeCount',
                        clstag: 'jr|keycount|dl_gryj|dsc'
                    },
                    {
                        number: 0,
                        desc: '已首充',
                        order: 61,
                        field: 'firstChargeCount',
                        clstag: 'jr|keycount|dl_gryj|ysc'
                    },
                    {
                        number: 0,
                        desc: '已冻结',
                        order: 70,
                        field: 'freezeCount',
                        clstag: 'jr|keycount|dl_gryj|ydj'
                    }
                ],
                selectedPanel: -1,
                businessPersonalList: [],
                leftUrl: '/business/my',
                rightUrl: '/business/my',
                personalMerchantList: [],
                personalMerchantList2: [],
                myChart1: {},
                echartOptions1: {},
                echartOptions2: {},
                // 日期选择组件
                dateSelectVal: `${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`,
                dateSelectVal2: `${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`,
                dateSelectVal3: `${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`,
                to: this.toTimestamp(`${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`, 0),
                from: this.toTimestamp(`${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`, 1),
                currentPage: 1,
                onload: true,
                echartsShow: true,
                // TODO: 临时处理方式
                getScrollTavInfoStatus: true,
                loadingEcharts: false,
                loadingPerformance: false,
                loadingBusiness: false
            }
        },
        mounted () {
            // 请求基本参数
            this.beforeInit()
            // 绘制图表
            this.myChart1 = echarts.init(this.$refs.echarts1)
            // 绘制图表1
            const echarOptions = this.echartOptions1
            this.myChart1.setOption(echarOptions)
        },
        methods: {
            beforeInit () {
                const _this = this

                api.performance.queryBDStaffInfoByPin({}, res => {
                    if (res.data.length <= 0) return

                    _this.userName = res.data[0].name
                    if (!localStorage.getItem('organId')) {
                        _this.organId = res.data[0].organId || ''
                    } else {
                        _this.organId = JSON.parse(localStorage.getItem('organId'))
                    }
                    
                    if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                        // 进入的是 企业 角色的时候
                        if (res.data[0].parentId !== '0') {
                            // 第一次判断 账号是个 非企业账号 需要跳转个人页面
                            _this.jumpPersonalPage(res.data[0].staffId, res.data[0].parentId, true)
                            return 
                        }

                        // 获取个人的 企业名字
                        const newData = {
                            batch: this.deleteChart(_this.dateSelectVal, '-'),
                            pageSize: 5,
                            status: _this.selectedPanel || 0,
                            currentPage: 1
                        }

                        // 获取 代理商家、代理员工基本信息
                        api.performance.getBDOrganBaseSummary(newData, res3 => {
                            // 新增判断账户是否在合同期内
                            if (res3.data.mature) {
                                _this.freezeStatus = true
                            }

                            const name = `${res3.data.principal}，您好`
                            _this.info = {
                                userImg: imgHost + res3.data.logUrl,
                                userName: name,
                                shopsNum: res3.data.merchantCount
                            }
                            _this.bussinessInfo = {
                                deptName: res3.data.organName,
                                numberCount: res3.data.merchantCount
                            }
                        })

                        _this.staffId = JSON.parse(localStorage.getItem('staffId')) || res.data[0].staffId
                    } else if (this.dutyType === ENUMLIST.ROLE_EMPLOYEE) {
                        // 进入的是 个人 角色的时候  parentId 等于 0:企业, 非0个人
                        _this.staffId = _this.$route.query.staffId
                        const newData = {
                            staffId: _this.$route.query.staffId
                        }
                        this.requstQueryBDStaffInfoByStaffId(newData)
                    }

                    // 企业 freeze: 0未冻结 1已冻结
                    // 个人 organFreeze: 0未冻结 1已冻结
                    // 合同到期 mature： false未到期 true到期
                    if (res.data[0].freeze || res.data[0].organFreeze) {
                        // 状态冻结
                        _this.$router.push({
                            name: '/permission/error',
                            path: '/permission/error',
                            query: {
                                title: '企业账户、个人账户已被冻结，已无法正常使用系统，请联系相关工作人员处理'
                            }
                        })
                    } else if (res.data[0].mature) {
                        // 合同到期
                        _this.$router.push({
                            name: '/permission/error',
                            path: '/permission/error',
                            query: {
                                title: '合同已到期，已无法正常使用系统，请联系相关工作人员处理'
                            }
                        })
                    } else {
                        // 初始化
                        _this.init()
                    }
                })
            },
            init () {
                const _this = this
                const data = {
                    batch: this.deleteChart(this.dateSelectVal, '-'),
                    pageSize: 5,
                    status: _this.selectedPanel || 0,
                    currentPage: 1
                }

                // 获取 商家代理 佣金数据
                // and
                // 获取 个人代理 佣金数据
                if (_this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    // ? 商家代理
                    _this.requestGetBDCommissionRecord(data)
                    // 获取 员工业绩 总计、信息
                    _this.requestGetBDOrganSummary(data)
                    // 获取 商户状态 list 等数据
                    _this.requestGetBDOrganPersonSummary(data)
                } else {
                    const newData = {
                        staffId: _this.staffId,
                        pageSize: 5,
                        currentPage: 1,
                        size: 5
                    }
                    const data2 = Object.assign(newData, { 
                        batch: this.deleteChart(this.dateSelectVal, '-'),
                        status: _this.selectedPanel || 0 
                    })
                    // ? 个人代理
                    // 获取总信息
                    _this.requestGetBDPersonCommissionRecord(data2)
                    // 获取 个人 业绩追踪
                    _this.requestQueryBDAchievementTrack(data2)
                    // 获取 个人 商户交易记录
                    _this.requestQueryBDMerchantOrderRecord(data2)

                    const dataErp = Object.assign(newData, {
                        erp: _this.staffId,
                        batch: this.deleteChart(this.dateSelectVal2, '-'),
                        from: this.from,
                        to: this.to
                    })

                    if (_this.selectedPanel === -1) delete dataErp.status
                    // 获取商户状态
                    _this.requestGetBDAgentStaffMerReport(dataErp)
                    // 获取 个人 商户 list
                    _this.requestQueryBDNumberReportInfoByERP(dataErp)
                }
            },
            // 获取个人信息（header）
            requstQueryBDStaffInfoByStaffId (newData) {
                const _this = this
                // 获取个人的 企业名字
                api.performance.queryBDStaffInfoByStaffId(newData, res => {
                    if (res.data.freeze) {
                        // console.log('账户冻结')
                        _this.freezeIdStatus = true
                    }
                    // 个人 其他页面跳转过来的无需再次跳转
                    const roleName = `${res.data.name}(${phoneHide(res.data.phone, 4)})`
                    // 接口返回请求成功
                    _this.info = {
                        userImg: imgHost + res.data.imgUrl,
                        userName: roleName,
                        shopsNum: res.data.merchantCount
                    }
                    _this.bussinessInfo = {
                        deptName: res.data.organName,
                        numberCount: res.data.merchantCount
                    }
                })
            },
            // 【企业】 获取 拓店佣金 / 商户交易佣金 数据接口
            requestGetBDCommissionRecord (data) {
                const _this = this
                data.staffId = _this.staffId
                _this.loadingEcharts = true

                api.performance.getBDCommissionRecord(data, res => {
                    // 获取拓店佣金金额
                    _this.amountExploit = res.data.merAddCommission
                    // 获取商户交易佣金
                    _this.amountDeal = res.data.merTradeCommission
                    // echartOptions1
                    _this.echartOptions1 = {
                        color: ['#1495EB', '#F0250F', '#F86E21'],
                        tooltip: {
                            trigger: 'axis',
                            axisPointer: {
                                // 坐标轴指示器，坐标轴触发有效
                                type: 'shadow'
                                // 默认为直线，可选为：'line' | 'shadow'
                            }
                        },
                        grid: {
                            show: false,
                            left: '3%',
                            right: '4%',
                            bottom: '7%',
                            top: '7%',
                            containLabel: true
                        },
                        xAxis: [
                            {
                                splitLine: { show: false },
                                type: 'category',
                                data: ['A级城市', 'B级城市', 'C级城市'],
                                axisTick: { show: false },
                                axisLine: { show: false }
                            }
                        ],
                        yAxis: [
                            {
                                axisTick: { show: false },
                                splitLine: { show: false },
                                axisLine: { show: false },
                                type: 'value'
                            }
                        ],
                        series: [
                            {
                                name: this.dutyType === ENUMLIST.ROLE_BUSINESS ? '金额' : '数量',
                                type: 'bar',
                                barWidth: '20%',
                                itemStyle: {
                                    color (params) {
                                        const colorList = ['#1495EB', '#F0250F', '#F86E21']
                                        return colorList[params.dataIndex]
                                    }
                                },
                                data: []
                            }
                        ]
                    }

                    if (!parseFloat(res.data.merAddCountForA) && !parseFloat(res.data.merAddCountForB) && !parseFloat(res.data.merAddCountForC)) {
                        _this.echartsShow = false
                    } else {
                        _this.echartsShow = true
                        _this.echartOptions1.series[0].data = [
                            parseFloat(res.data.merAddCountForA) || 0, 
                            parseFloat(res.data.merAddCountForB) || 0, 
                            parseFloat(res.data.merAddCountForC) || 0
                        ]
                    }
                    
                    _this.echartOptions2 = {
                        tooltip: {
                            trigger: 'axis'
                        },
                        legend: {},
                        toolbox: {
                            feature: {
                                saveAsImage: {}
                            }
                        },
                        grid: {
                            left: '3%',
                            right: '4%',
                            bottom: '7%',
                            top: '7%',
                            containLabel: true
                        },
                        xAxis: [
                            {
                                splitLine: { show: false },
                                type: 'category',
                                boundaryGap: false,
                                data: res.data.dates,
                                axisTick: { show: false },
                                axisLine: { show: false }
                            }
                        ],
                        yAxis: [
                            {
                                axisTick: { show: false },
                                splitLine: { show: false },
                                axisLine: { show: false },
                                type: 'value'
                            }
                        ],
                        series: [
                            {
                                name: '商户交易佣金',
                                type: 'line',
                                stack: '总量',
                                itemStyle: {
                                    color: '#F0250F'
                                },
                                areaStyle: {
                                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                        offset: 0,
                                        color: '#F0250F'
                                    }, {
                                        offset: 0.5,
                                        color: '#FFFFFF'
                                    }])
                                },
                                data: res.data.trades
                            }
                        ]
                    }

                    if (_this.tabActiveStatus) {
                        _this.myChart1.setOption(_this.echartOptions1, true)
                    } else {
                        // 判断是否有数据
                        if (res.data.trades.length > 0) {
                            _this.echartsShow = true
                        } else {
                            _this.echartsShow = false
                        }
                        _this.myChart1.setOption(_this.echartOptions2, true)
                    }

                    setTimeout(() => {
                        _this.loadingEcharts = false
                    }, 2000)
                }).catch(e => {
                    console.log('error:', e)
                    _this.echartsShow = false
                })
            },
            // 【企业】 获取 员工业绩总计
            requestGetBDOrganSummary (data) {
                const _this = this
                _this.loadingPerformance = true
                // 获取 员工业绩 总计 （合计，拓店总数，商户总交易）
                api.performance.getBDOrganSummary(data, res => {
                    _this.employeeSum = {}
                    _this.employeeSum.staffCount = `合计（${res.data.staffCount || 0}人）`
                    _this.employeeSum.addCount = res.data.addCount || 0
                    _this.employeeSum.tradeSummaryAmount = res.data.tradeSummaryAmount || 0
                })
                // 获取 员工业绩 信息
                api.performance.getBDStaffAchievement(data, res => {
                    _this.tableList = res.data

                    setTimeout(() => {
                        _this.loadingPerformance = false
                    }, 2000)
                })
            },
            // 【企业】 获取 商户状态
            requestGetBDOrganPersonSummary (data) {
                const _this = this
                _this.loadingBusiness = true
                api.performance.getBDOrganPersonSummary(data, res => {
                    _this.onload = true

                    const newArray = res.data.map(item => {
                        item.imgUrl = imgHost + item.imgUrl
                        item.phone = phoneHide(item.phone)
                        return item
                    })

                    // 合并数组
                    _this.businessPersonalList = _this.businessPersonalList.concat(newArray)

                    if (res.data.length < data.pageSize) {
                        // 如果没数据了，则暂停刷新
                        _this.onload = false
                    } else {
                        _this.currentPage++
                    }

                    setTimeout(() => {
                        _this.loadingBusiness = false
                    }, 2000)
                })
            },
            // 【个人】 获取 echarts 数据
            requestGetBDPersonCommissionRecord (data) {
                const _this = this
                _this.loadingEcharts = true
                api.performance.getBDPersonCommissionRecord(data, res => {
                    // 获取拓店佣金金额
                    _this.amountExploit = res.data.merAddCount
                    // 获取商户交易佣金
                    _this.amountDeal = res.data.merTradeAmount
                    // echartOptions1
                    _this.echartOptions1 = {
                        color: ['#1495EB', '#F0250F', '#F86E21'],
                        tooltip: {
                            trigger: 'axis',
                            axisPointer: {
                                // 坐标轴指示器，坐标轴触发有效
                                type: 'shadow'
                            }
                        },
                        grid: {
                            show: false,
                            left: '3%',
                            right: '4%',
                            bottom: '7%',
                            top: '7%',
                            containLabel: true
                        },
                        xAxis: [
                            {
                                splitLine: { show: false },
                                type: 'category',
                                data: ['A级城市', 'B级城市', 'C级城市'],
                                axisTick: { show: false },
                                axisLine: { show: false }
                            }
                        ],
                        yAxis: [
                            {
                                axisTick: { show: false },
                                splitLine: { show: false },
                                axisLine: { show: false },
                                type: 'value'
                            }
                        ],
                        series: [
                            {
                                name: this.dutyType === ENUMLIST.ROLE_BUSINESS ? '金额' : '数量',
                                type: 'bar',
                                barWidth: '20%',
                                itemStyle: {
                                    color (params) {
                                        const colorList = ['#1495EB', '#F0250F', '#F86E21']
                                        return colorList[params.dataIndex]
                                    }
                                },
                                data: []
                            }
                        ]
                    }

                    if (!parseFloat(res.data.merAddCountForA) && !parseFloat(res.data.merAddCountForB) && !parseFloat(res.data.merAddCountForC)) {
                        _this.echartsShow = false
                    } else {
                        _this.echartsShow = true
                        _this.echartOptions1.series[0].data = [parseFloat(res.data.merAddCountForA) || 0, parseFloat(res.data.merAddCountForB) || 0, parseFloat(res.data.merAddCountForC) || 0]
                    }

                    _this.echartOptions2 = {
                        tooltip: {
                            trigger: 'axis'
                        },
                        legend: {},
                        toolbox: {
                            feature: {
                                saveAsImage: {}
                            }
                        },
                        grid: {
                            left: '3%',
                            right: '4%',
                            bottom: '7%',
                            top: '7%',
                            containLabel: true
                        },
                        xAxis: [
                            {
                                splitLine: { show: false },
                                type: 'category',
                                boundaryGap: false,
                                data: res.data.dates,
                                axisTick: { show: false },
                                axisLine: { show: false }
                            }
                        ],
                        yAxis: [
                            {
                                axisTick: { show: false },
                                splitLine: { show: false },
                                axisLine: { show: false },
                                type: 'value'
                            }
                        ],
                        series: [
                            {
                                name: '商户交易',
                                type: 'line',
                                stack: '总量',
                                areaStyle: {},
                                data: res.data.trades
                            }
                        ]
                    }

                    if (_this.tabActiveStatus) {
                        _this.myChart1.setOption(_this.echartOptions1, true)
                    } else {
                        if (res.data.trades.length > 0) {
                            _this.echartsShow = true
                        } else {
                            _this.echartsShow = false
                        }
                        _this.myChart1.setOption(_this.echartOptions2, true)
                    }

                    setTimeout(() => {
                        _this.loadingEcharts = false
                    }, 2000)
                })
            },
            // 【个人】 获取 业绩追踪
            requestQueryBDAchievementTrack (data) {
                const newObj = { ...data }
                newObj.pageSize = 3
                newObj.size = 3
                const _this = this
                _this.loadingPerformance = true

                api.performance.queryBDAchievementTrackList(newObj, res => {
                    _this.personalMerchantList = res.data.map(item => {
                        item.imageUrl = imgHost + item.imageUrl
                        return item
                    })
                    setTimeout(() => {
                        _this.loadingPerformance = false
                    }, 2000)
                })
            },
            // 【个人】 获取 商户交易记录
            requestQueryBDMerchantOrderRecord (data) {
                const _this = this

                api.performance.queryBDMerchantOrderRecord(data, res => {
                    _this.listKeys2 = [
                        'merchantName',
                        'tradeAmount',
                        'version'
                    ]
                    _this.tableList = res.data
                })
            },
            // 【个人】 获取 商户状态数据
            requestGetBDAgentStaffMerReport (dataErp) {
                const _this = this

                api.performance.getBDAgentStaffMerReport(dataErp, res => {
                    _this.stateInfo = _this.stateInfo.map(item => {
                        if (res.data[item.field] !== undefined) item.number = res.data[item.field]
                        return item
                    })
                })
            },
            // 【个人】 获取 商户list
            requestQueryBDNumberReportInfoByERP (data) {
                const _this = this

                api.performance.queryBDNumberReportInfoByERP(data, res => {
                    _this.onload = true
                    if (res.data) {
                        const newArray = res.data.map(item => {
                            item.circleImg = imgHost + item.circleImg
                            return item
                        })
                        
                        _this.personalMerchantList2 = _this.personalMerchantList2.concat(newArray)

                        if (res.data.length < data.pageSize) {
                            // 如果没数据了，则暂停刷新
                            _this.onload = false
                        } else {
                            _this.currentPage++
                        }
                    }
                })
            },
            // 跳转个人主页
            jumpPersonalPage (staffId, parentId, noHome) {
                const _this = this

                this.$router.push({
                    name: '/business/performance/personal',
                    query: {
                        staffId: staffId || JSON.parse(localStorage.getItem('staffId')),
                        organId: _this.organId,
                        parentId: parentId || this.parentId,
                        noHome
                    }
                })
            },
            // 头像跳转方法
            headerJumpFun () {
                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    this.jumpPersonalPage()
                } else {
                    // 跳转到白名单页面
                    this.$router.push({
                        name: '/white-bd-entry',
                        query: {
                            staffId: this.staffId,
                            parentId: this.parentId
                        }
                    })
                }
            },
            // 跳转到员工信息页面                   
            jumpEmployeeInfo (key, status) {
                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    this.$router.push({
                        name: '/business/performance/personal',
                        query: {
                            staffId: key,
                            parentId: this.parentId
                        }
                    })
                } else {
                    this.$router.push({
                        path: `/merchantDetails/${key}/${status}`,
                        query: {
                            staffId: this.$route.query.staffId,
                            merchantId: key,
                            status
                        }
                    })
                }
            },
            // 查看全部
            viewAllEvent () {
                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    // 员工业绩
                    this.$router.push({
                        path: '/business/performance/employee',
                        query: {
                            organId: this.organId,
                            staffId: this.$route.query.staffId || this.staffId
                        }
                    })
                } else {
                    // 交易记录
                    this.$router.push({
                        path: '/business/performance/record',
                        query: {
                            organId: this.organId,
                            staffId: this.$route.query.staffId || this.staffId
                        }
                    })
                }
            },
            // 获取下属信息
            getDuty (info) {
                if (info.deptName) {
                    return `${info.deptName}`
                } else {
                    return ''
                }
            },
            // 我的商户数
            myShoper (string) {
                return `我的商家${string}`
            },
            // tab change 事件
            tabChange (val) {
                if (val === 1) {
                    this.tabActiveStatus = true
                } else {
                    this.tabActiveStatus = false
                }

                // 绘制图表1
                const { echartOptions1, echartOptions2 } = this

                if (this.tabActiveStatus) {
                    if (echartOptions1.series[0].data.length > 0) {
                        this.echartsShow = true
                    } else {
                        this.echartsShow = false
                    }
                    this.myChart1.setOption(echartOptions1, true)
                } else {
                    if (echartOptions2.series[0].data.length > 0) {
                        this.echartsShow = true
                    } else {
                        this.echartsShow = false
                    }
                    this.myChart1.setOption(echartOptions2, true)
                }
            },
            // scroll tab click 事件
            getScrollTabInfos (order) {
                this.personalMerchantList2 = []
                this.currentPage = 1
                this.selectedPanel = order
                const data = {
                    staffId: this.staffId,
                    batch: this.deleteChart(this.dateSelectVal3, '-'),
                    pageSize: 5,
                    status: this.selectedPanel || 0,
                    currentPage: 1,
                    size: 5,
                    from: this.from,
                    to: this.to,
                    erp: this.staffId
                }
                if (order === -1) delete data.status

                this.requestQueryBDNumberReportInfoByERP(data)
            },
            // 底部 tab 按钮切换事件
            btnClickValue (value) {
                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    // 商家时
                    if (value === '1') {
                        // left
                        this.$router.push({
                            path: '/business/performance/company'
                        })
                    } else if (value === '2') {
                        // right
                        this.$router.push({
                            path: '/company/myCompany',
                            query: {
                                staffId: this.$route.query.staffId || this.staffId
                            }
                        })
                    }
                } else {
                    // 个人时
                    this.$router.push({
                        name: '/merchantEntry',
                        query: {
                            staffId: this.staffId,
                            merchantId: this.merchantId,
                            userName: this.info.userName
                            
                        }
                    })
                }
            },
            // 点击跳转
            handleClick (id, status) {
                this.$router.push({
                    path: `/merchantDetails/${id}/${status}`,
                    query: {
                        staffId: this.$route.query.staffId,
                        merchantId: id,
                        status
                    }
                })
            },
            // 拨打电话
            phoneClickHandle (number) {
                window.location.href = `tel:${number}`
            },
            // 获取全部 拓店追踪
            getAllPerformance () {
                this.$router.push({
                    name: '/business/performance/exploit',
                    query: {
                        staffId: this.staffId
                    }
                })
            },
            // 遮罩层 确定事件
            confirmClick () {
                console.log('confirm click')
            },
            cancelClick () {
                console.log('cancel click')
            },
            // 获取日期选择组件 传递过来的数据
            dateUpdate1 (val) {
                this.dateSelectVal = val
                this.from = this.toTimestamp(val, 1)
                this.to = this.toTimestamp(val, 0)
                const data = {
                    organId: this.organId,
                    batch: this.deleteChart(val, '-'),
                    pageSize: 5,
                    currentPage: 1
                }
                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    // 企业业绩
                    this.requestGetBDCommissionRecord(data)
                } else {
                    data.staffId = this.staffId
                    // 个人业绩
                    this.requestGetBDPersonCommissionRecord(data)
                }
            },
            // 获取日期选择组件2 
            dateUpdate2 (val) {
                this.dateSelectVal2 = val
                this.from = this.toTimestamp(val, 1)
                this.to = this.toTimestamp(val, 0)
                
                const data = {
                    organId: this.organId,
                    batch: this.deleteChart(val, '-'),
                    pageSize: 5,
                    currentPage: 1
                }
                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    this.requestGetBDOrganSummary(data)
                } else {
                    data.staffId = this.staffId
                    this.requestQueryBDAchievementTrack(data)
                    this.requestQueryBDMerchantOrderRecord(data)
                }
            },
            dateUpdate3 (val) {
                this.personalMerchantList2 = []
                this.dateSelectVal3 = val
                this.from = this.toTimestamp(val, 1)
                this.to = this.toTimestamp(val, 0)

                const dataErp = {
                    staffId: this.staffId,
                    batch: this.deleteChart(this.dateSelectVal3, '-'),
                    pageSize: 5,
                    status: this.selectedPanel || '',
                    currentPage: 1,
                    size: 5,
                    from: this.from,
                    to: this.to,
                    erp: this.staffId
                }

                if (this.selectedPanel === -1) delete dataErp.status 

                if (this.dutyType === ENUMLIST.ROLE_BUSINESS) {
                    // 获取 企业 商户 list
                    this.requestGetBDOrganPersonSummary(dataErp)
                } else {
                    this.requestGetBDAgentStaffMerReport(dataErp)
                    // 获取 个人 商户 list
                    this.requestQueryBDNumberReportInfoByERP(dataErp)
                }
            },
            // 正则删除字符方法
            deleteChart (val, str) {
                const reg = new RegExp(str)
                const newBatch = val.replace(reg, '')
                return Number(newBatch)
            },
            // 根据年、月获取每个月的第一天时间戳 和 最后一天时间戳
            toTimestamp (date, type) {
                if (!type) {
                    // to
                    // 次月的第一天
                    const str = `${date}-${1}`
                    const newArray = str.split('-')
                    const year = newArray[0]
                    const month = Number(newArray[1])
                    const day = Number(newArray[2])
                    return new Date(year, month.toString(), day).valueOf()
                } else {
                    // from
                    // 每个月的第一天
                    const str = `${date}-${type}`
                    const newArray = str.split('-')
                    const year = newArray[0]
                    const month = Number(newArray[1]) - 1
                    const day = Number(newArray[2])
                    return new Date(year, month.toString(), day).valueOf()
                }
            },
            // 【个人】 显示是否拓店完成
            showStatus (status) {
                if (status) {
                    return '拓店完成'
                } else {
                    return '拓店未完成'
                }
            },
            //  【个人】 显示商户状态
            businessStatus (status) {
                switch (status) {
                    case 0:
                        return '初始状态'
                    case 1:
                        return '待扫码'
                    case 2:
                        return '已自助开店'
                    case 3:
                        return '待实名'
                    case 21:
                        return '实名审核中'
                    case 22:
                        return '实名未通过'
                    case 23:
                        return '待上传资质'
                    case 31:
                        return '资质审核中'
                    case 32:
                        return '资质未通过'
                    case 33:
                        return '待签约'
                    case 41:
                        return '待上线'
                    case 50:
                        return '待首充'
                    case 61:
                        return '已首充'
                    case 70:
                        return '已冻结'
                    default:
                        return '初始状态'
                }
            },
            // 时间转化格式
            dateTool (time) {
                return dayjs(time).format('YYYY.MM.DD')
            },
            // 商户状态滚动加载
            handleScroll (key) {
                const dataErp = {
                    staffId: this.staffId,
                    batch: this.deleteChart(this.dateSelectVal3, '-'),
                    pageSize: 5,
                    status: this.selectedPanel || '',
                    currentPage: this.currentPage || 1,
                    size: 5,
                    from: this.from,
                    to: this.to,
                    erp: this.staffId
                }

                if (dataErp.status === -1) delete dataErp.status

                if (this.onload) {
                    this.onload = false
                    if (key === 1) {
                        // 商户业绩
                        this.requestGetBDOrganPersonSummary(dataErp)
                    } else if (key === 2) {
                        // 个人业绩
                        this.requestQueryBDNumberReportInfoByERP(dataErp)
                    }
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
// @import "./style.scss";
::-webkit-scrollbar {
	width: 0 !important;
	height: 0;
}
.business-performance-container {
    // padding-bottom: 0.8rem;

    /deep/ .van-dropdown-menu {
        background-color: rgba(0, 0, 0, 0);
    }

    .header-box {
    }

    .echart-tab-box {
        display: flex;
        justify-content: row;
        align-items: center;
        width: 100%;
        height: auto;
        background-color: #FFFFFF;

        .tab-left-box {
            width: 50%;
            height: 0.8rem;
            border-bottom: 0.03rem solid #EEF1F4;

            .amount-exploit {
                margin-top: 0.19rem;
                font-size: 0.16rem;
                line-height: 0.16rem;
                color: #E0E0E0;
                text-align: center;
            }

            .amount-active {
                color: #2E2D2D;
                font-weight: 500;
            }

            .amount-text-active {
                color: #BBBBBB;
            }
        }

        .tab-split {
            width: 0.01rem;
            height: 0.4rem;
            background-color: #EEF1F4;
        }

        .tab-right-box {
            width: 50%;
            height: 0.8rem;
            border-bottom: 0.03rem solid #EEF1F4;

            .amount-deal {
                margin-top: 0.19rem;
                font-size: 0.16rem;
                line-height: 0.16rem;
                color: #E0E0E0;
                text-align: center;
            }

            .amount-active {
                color: #2E2D2D;
                font-weight: 500;
            }
		}

        .amount-text {
            margin-top: 0.11rem;
            font-size: 0.13rem;
            line-height: 0.13rem;
            color: #E0E0E0;
            text-align: center;
        }

        .tab-active {
            border-bottom: 0.03rem solid #F0250F;
        }
    }

    .echart-box {
        width: 100%;
        height: 2.4rem;
        // background-color: aquamarine;

        .echart-1 {
            width: 100%;
            height: 2.4rem;
            background-color: #FFFFFF;
        }
    }

    .employee-box {
        width: 100%;

        .button-see-all {
            display: block;
            width: 100%;
            height: 0.5rem;
            border: none;

            .button-arrow {
                font-size: 0.12rem;
                margin-left: 0.1rem;
            }
        }

        .jump-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 0.5rem;
            background-color: #FFFFFF;
            font-size: 0.15rem;
            font-weight: 400;
            color: #2E2D2D;
            margin-bottom: 0.11rem;
        }
    }

    .scroll-tab-box {
        width: 100%;
        height: .84rem;
        background: #FFFFFF;
        display: flex;
        /*position: sticky;*/
        /*top: 0;*/
        /*z-index: 100;*/
        // margin-top: 0.15rem;

        .show_left {
            width: 33%;
            height: .84rem;
            display: inline-block;
            vertical-align:top;

            .fixed {
                margin-top: .12rem;
                margin-left: .12rem;
                border: 0.01rem solid rgba(238,241,244,1);
            }

            .active {
                border: 1px solid #F0250F;
                color: #F0250F;

                /deep/.text-bottom{
                    color: red;
                }
            }
        }

        // todo 上下滑动待处理
        .show_right{
            width: 67%;
            height: .84rem;
            padding: .12rem 0rem .12rem 0rem;
            white-space: nowrap;
            overflow-x: scroll;
            overflow-y: hidden;
            -webkit-overflow-scrolling: touch;
            -ms-overflow-style: -ms-autohiding-scrollbar;
            overflow-scrolling: touch;
            display: inline-block;
            vertical-align: top;

            .controller {
                width: 100%;

                .panel {
                    display: inline-block;
                    vertical-align: top;
                    margin-right: .12rem;
                    border: 0.01rem solid rgba(238,241,244,1);
                }

                .active {
                    border: 1px solid #F0250F;
                    color: #F0250F;

                    /deep/.text-bottom{
                        color: red;
                    }
                }
            }
        }
    }

    .business-personal-box {
        width: 100%;
    }

	.box-margin-bottom {
		margin-bottom: 0.15rem;
	}

    .tabbar-box {
        .add-button {
            width: 100%;
            font-size: 0.18rem;
            font-weight: 400;
            line-height: 0.18rem;
            color: #FFFFFF;
            // opacity: 0.3;
            // text-align: ;
            // margin-top: 0.2rem;
            display: flex;
            justify-content: center;
            align-items: center;

            .add-icon {
                height: 0.24rem;
                margin-right: 0.03rem;
                // line-height: 0.24rem;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .add-text {
                height: 0.24rem;
                line-height: 0.24rem;
            }
        }
    }

    .loginout-text {
        font-size: 0.15rem;
        font-weight: 500;
        color: #2E2D2D;
        text-align: center;
    }

    .status-box {
        height: 0.5rem;
        display: flex;
        align-items: center;
        padding: 0 0.13rem;
        font-size: 0.14rem;
        color: #2E2D2D;

        .icon-gold {
            margin-right: 0.07rem;
        }
    }

    .title-box {
        display: flex;
        font-size: 0.14rem;
        line-height: 0.14rem;
    }
}
</style>
