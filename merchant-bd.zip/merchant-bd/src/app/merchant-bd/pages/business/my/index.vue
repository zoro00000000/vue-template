<template>
    <div class="container">
        <div class="tabbar-box">
            <div class="tabbar-left">
                企业业绩
            </div>
            <div class="tabar-split"></div>
            <div class="tabbar-right">
                我的企业
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>

<style lang="scss" scoped>
.container {
    width: 100%;
    height: 100%;

    .tabbar-box {
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 0.8rem;
        background: linear-gradient(270deg,rgba(222,49,33,1) 0%,rgba(236,86,42,1) 100%);

        .tabbar-left {
            width: 50%;
            height: 100%;
            background-color: bisque;
        }

        .tabar-split {
            width: 0.01rem;
            height: 0.4rem;
            background-color: #EEF1F4;
        }

        .tabbar-right {
            width: 50%;
            height: 100%;
            background-color: aqua;
        }
    }
}
</style>
