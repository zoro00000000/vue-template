<template>
    <div class="sucesss-container">
        <alert-success :successTitle="'demo测试'">
            <div class="success-content">
                您已将海淀黄庄肯德基店维护员工由 <br>
                <span class="content-span">刘萌萌（0908）</span>
                成功变更为
                <span class="content-span">张宇（1234）</span>
            </div>
        </alert-success>
    </div>
</template>

<script>
    import alertSuccess from '../performance/components/alertSuccess'

    export default {
        name: 'success',
        components: {
            alertSuccess
        }
    }
</script>

<style lang="scss" scoped>
.sucesss-container {
    width: 100%;
    height: 100vh;

    .success-content {
        width: 100%;
        height: auto;
        font-size: 0.15rem;
        line-height: 0.23rem;
        font-weight: 400;
        color: #848484;
        text-align: center;
        margin-top: 0.24rem;

        .content-span {
            color: #2E2D2D;
        }
    }
}
</style>
