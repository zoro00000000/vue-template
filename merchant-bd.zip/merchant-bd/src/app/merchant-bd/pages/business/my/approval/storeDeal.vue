<template>
    <div class="store-deal-container">
        <div v-if="false" class="header-box">
            <div class="amount">{{amount}}</div>
            <div class="title">待核佣金（元）</div>
        </div>

        <div v-if="listData.length > 0">
            <div class="table-list-title-box">
                <table-cell
                    :titles="titles"
                    :isJump="false"
                    :isBold="true"
                    :hideArrow="true"
                    :lastIsRight="true"
                ></table-cell>
            </div>

            <div class="table-list-content-box">
                <pull-down-refresh
                    id="pullDownBox"
                    :threshold="120"
                    wrapper="comments-scroll"
                    @scroll="fetchMore"
                >
                    <table-cell
                        v-for="(item, index) in listData"
                        :key="index"
                        :titles="item"
                        :titleKeys="listKeys"
                        :isJump="false"
                        :isBold="true"
                        :hideArrow="true"
                        :lastIsRight="true"
                    ></table-cell>
                </pull-down-refresh>
            </div>
        </div>

         <empty v-else :showTitle="'暂无商户交易佣金数据'" />
    </div>
</template>

<script>
    import dayjs from 'dayjs'
    // 引入 table cell 组件
    import tableCell from '@/merchant-bd/components/tableCell'
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    // 引入 api
    import api from '@/merchant-bd/api/main'
    // 数据为空的时候 组件
    import empty from '@/merchant-bd/components/empty'

    export default {
        name: 'storeDeal',
        components: {
            tableCell,
            pullDownRefresh,
            empty
        },
        data () {
            return {
                titles: {
                    number: '订单编号',
                    amount: '交易金额',
                    time: '时间'
                },
                listKeys: [
                    'tradeOrderId',
                    'payAmount',
                    'createTime'
                ],
                amount: this.$route.query.amount || '0',
                listData: [],
                onload: true,
                currentPage: 1,
                to: this.toTimestamp(`${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`, 0),
                from: this.toTimestamp(`${new Date().getFullYear()}-${new Date().getMonth() + 1 < 10 ? `0${new Date().getMonth() + 1}` : new Date().getMonth() + 1}`, 1),
                autoFetch: true
            }
        },
        mounted () {
            this.fetchMore()
        },
        methods: {
            fetchMore () {
                console.log(1)
                const data = {
                    merchantId: this.$route.query.merchantId || '1',
                    pageNo: this.currentPage.toString() || '1',
                    pageSize: '10',
                    batch: this.$route.query.batch || 202003,
                    startTime: '',
                    endTime: ''
                }
                const str = (this.$route.query.batch || 202003).toString()
                const newDate = `${str.slice(0, 4)}-${str.slice(4, 6)}`
                data.startTime = this.toTimestamp(newDate, 1)
                data.endTime = this.toTimestamp(newDate, 0)

                if (this.currentPage > 1 && this.autoFetch) {
                    const windowH = window.screen.height
                    const pullDownBoxH = document.getElementById('pullDownBox').offsetHeight

                    if (pullDownBoxH && (windowH >= (pullDownBoxH + 150))) {
                        if (this.onload) {
                            this.onload = false
                            this.requestQueryBDMerchantRevenueFlowList(data)
                        }
                    } else {
                        this.autoFetch = false
                        return
                    }
                }

                if (this.onload) {
                    this.onload = false
                    this.requestQueryBDMerchantRevenueFlowList(data)
                }
            },
            // 请求页面数据
            requestQueryBDMerchantRevenueFlowList (data) {
                const _this = this
                api.commission.queryBDMerchantRevenueFlowList(data, res => {
                    console.log('res:', res)
                    _this.onload = true

                    const newArry = res.data.list.map(item => {
                        item.createTime = dayjs(item.tradeTime).format('YYYY-MM-DD')
                        // newArry.push(item)
                        return item
                    })
                    _this.listData = _this.listData.concat(newArry)

                    // 判断是否需要加载
                    if (res.data.list.length < Number(data.pageSize)) {
                        // 如果没数据了，则暂停刷新
                        _this.onload = false
                    } else {
                        _this.currentPage++
                    }

                    if (_this.autoFetch) {
                        setTimeout(() => {
                            _this.fetchMore()
                        }, 1000) 
                    }
                })
            },
            // 根据年、月获取每个月的第一天时间戳 和 最后一天时间戳
            toTimestamp (date, type) {
                if (!type) {
                    const str = `${date}-${1}`
                    const newArray = str.split('-')
                    const year = newArray[0]
                    const month = Number(newArray[1])
                    const day = Number(newArray[2])
                    console.log('year, month, day:', year, month, day)
                    console.log(new Date(year, month.toString(), day).valueOf())
                    return new Date(year, month.toString(), day).valueOf()
                } else {
                    // from
                    // 每个月的第一天
                    const str = `${date}-${type}`
                    const newArray = str.split('-')
                    const year = newArray[0]
                    const month = Number(newArray[1]) - 1
                    const day = Number(newArray[2])
                    console.log('year, month, day:', year, month, day)
                    console.log(new Date(year, month.toString(), day).valueOf())
                    return new Date(year, month.toString(), day).valueOf()
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
.store-deal-container {
    width: 100%;
    height: auto;
    background-color: #F5F8FC;

    .header-box {
        width: 100%;
        height: 0.9rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;

        .amount {
            font-size: 0.18rem;
            font-weight: 500;
            color: #2E2D2D;
        }

        .title {
            font-size: 0.15rem;
            font-weight: 400;
            color: #BBBBBB;
            margin-top: 0.08rem;
        }
    }

    .table-list-title-box {
        width: 100%;
        height: 0.5rem;
    }

    .table-list-content-box {
        width: 100%;
        height: auto;
    }
}
</style>
