<template>
    <div class="city-data-container">
        <pull-down-refresh
            v-if="listData.length > 0"
            id="pullDownBox"
            :threshold="120"
            wrapper="comments-scroll"
            @scroll="fetchMore"
        >
            <card-cell
                v-for="(item, index) in listData"
                :key="index"
                :headerTitle="item.headerTitle"
                :headerText="item.headerText"
                :contentList="item.contentList"
            ></card-cell>
        </pull-down-refresh>

        <empty v-else :showTitle="'暂无待核佣金数据'" />
    </div>
</template>

<script>
    import dayjs from 'dayjs'
    // 引入 cardCell 组件
    import cardCell from '@/merchant-bd/components/cardCell'
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    // 数据为空的时候 组件
    import empty from '@/merchant-bd/components/empty'
    // 引入 api
    import api from '@/merchant-bd/api/main'

    export default {
        name: 'cityData',
        components: {
            cardCell,
            pullDownRefresh,
            empty
        },
        data () {
            return {
                listData: [],
                onload: true,
                currentPage: 1,
                autoFetch: true
            }
        },
        mounted () {
            this.fetchMore()
        },
        methods: {
            fetchMore () {
                const data = {
                    organId: JSON.parse(localStorage.getItem('organId')),
                    cityId: this.$route.query.cityId || 1,
                    currentPage: this.currentPage,
                    size: 10
                }

                if (this.currentPage > 1 && this.autoFetch) {
                    const windowH = window.screen.height
                    const pullDownBoxH = document.getElementById('pullDownBox').offsetHeight

                    if (pullDownBoxH && (windowH >= (pullDownBoxH + 150))) {
                        if (this.onload) {
                            this.onload = false
                            this.requestQueryAddInfoByCityId(data)
                        }
                    } else {
                        this.autoFetch = false
                        return
                    }
                }

                if (this.onload) {
                    this.onload = false
                    this.requestQueryAddInfoByCityId(data)
                }
            },
            // 获取城市数据
            requestQueryAddInfoByCityId (data) {
                const _this = this
                api.commission.queryAddInfoByCityId(data, res => {
                    console.log('res:', res)
                    _this.onload = true
                    const newArray = res.data.map(item => {
                        const newItem = {
                            headerTitle: item.merName,
                            headerText: '',
                            contentList: [
                                {
                                    title: '订单编号',
                                    text: item.merId
                                },
                                {
                                    title: '员工',
                                    text: item.staffName
                                },
                                {
                                    title: '时间',
                                    text: _this.dateTool(item.merStandardTime) || '2020-02-02'
                                }
                            ]
                        }
                        // newArray.push(newItem)
                        return newItem
                    })
                    _this.listData = _this.listData.concat(newArray)

                    // 判断是否需要加载
                    if (res.data.length < data.size) {
                        // 如果没数据了，则暂停刷新
                        _this.onload = false
                    } else {
                        _this.currentPage++
                    }

                    if (_this.autoFetch) {
                        setTimeout(() => {
                            _this.fetchMore()
                        }, 1000) 
                    }
                })
            },
            // 时间转化格式
            dateTool (time) {
                // console.log('time:', time)
                return dayjs(time).format('YYYY-MM-DD')
            }
        }
    }
</script>

<style lang="scss" scoped>
.city-data-container {
    width: 100%;
    height: auto;
    background-color: #F5F8FC;
}
</style>
