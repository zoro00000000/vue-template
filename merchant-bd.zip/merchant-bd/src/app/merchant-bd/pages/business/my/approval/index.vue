<template>
    <div class="approval-container">
        <div class="header-box">
            <div class="amount">{{totalSum}}</div>
            <div class="title">{{isWait == 2 ? "待发佣金（元）":"待核佣金（元）"}}</div>
        </div>

        <div class="header-tabbar-box">
            <div clstag="jr|keycount|dl_wdqy_yjhf_dhyj|tdyj" class="tab-bar-box" @click="tabbarClick(1)" :class="tabKey === 1 ? 'actived' : ''">
                <div class="bar-amount" :class="tabKey === 1 ? 'actived-amount' : ''">{{businessSum}}</div>
                <div class="bar-title" :class="tabKey === 1 ? 'actived-title' : ''">拓店佣金</div>
            </div>
            <div class="split"></div>
            <div clstag="jr|keycount|dl_wdqy_yjhf_dhyj_ygsx|shjyyj"  class="tab-bar-box" @click="tabbarClick(2)" :class="tabKey === 2 ? 'actived' : ''">
                <div class="bar-amount" :class="tabKey === 2 ? 'actived-amount' : ''">{{dealSum}}</div>
                <div class="bar-title" :class="tabKey === 2 ? 'actived-title' : ''">商户交易佣金</div>
            </div>
            <div class="split"></div>
            <div clstag="jr|keycount|dl_wdqy_yjhf_dhyj|ccyj" class="tab-bar-box" @click="tabbarClick(3)" :class="tabKey === 3 ? 'actived' : ''">
                <div class="bar-amount" :class="tabKey === 3 ? 'actived-amount' : ''">{{mistakeSum}}</div>
                <div class="bar-title" :class="tabKey === 3 ? 'actived-title' : ''">差错佣金</div>
            </div>
        </div>
        
        <div v-if="tabKey === 1">
            <div v-if="listA.length > 0 || listB.length > 0 || listC.length > 0">
                <!-- A级城市 -->
                <div>
                    <table-cell
                        v-for="(item, index) in listA"
                        :key="index"
                        :titleKeys="listAKeys"
                        :titles="item"
                        :isJump="index === 0 ? false : true"
                        :isGayBGColor="index === 0 ? true : false"
                        :lastIsRight="index === 0 ? true : false"
                        :hideArrow="index === 0 ? true : false"
                        @click="jumpRouter(1, item)"
                    />
                </div>

                <!-- B级城市 -->
                <div>
                    <table-cell
                        v-for="(item, index) in listB"
                        :titleKeys="listAKeys"
                        :key="index"
                        :titles="item"
                        :isJump="index === 0 ? false : true"
                        :isGayBGColor="index === 0 ? true : false"
                        :lastIsRight="index === 0 ? true : false"
                        :hideArrow="index === 0 ? true : false"
                        @click="jumpRouter(1, item)"
                    />
                </div>

                <!-- C级城市 -->
                <div>
                    <table-cell
                        v-for="(item, index) in listC"
                        :titleKeys="listAKeys"
                        :key="index"
                        :titles="item"
                        :isJump="index === 0 ? false : true"
                        :isGayBGColor="index === 0 ? true : false"
                        :lastIsRight="index === 0 ? true : false"
                        :hideArrow="index === 0 ? true : false"
                        @click="jumpRouter(1, item)"
                    />
                </div>
            </div>

            <empty-placeholder v-if="listA.length === 0 && listB.length === 0 && listC.length === 0" :showTitle="'暂无拓店佣金数据'" />
        </div>
        
        <div v-else-if="tabKey === 2">
            <pull-down-refresh
                v-if="listData.length > 0"
                id="pullDownBox"
                :threshold="120"
                wrapper="comments-scroll"
                @scroll="fetchMore"
            >
                <card-cell
                    v-for="(item, index) in listData"
                    :key="index"
                    :headerTitle="item.headerTitle"
                    :headerText="item.headerText"
                    :contentList="item.contentList"
                    :isJump="true"
                    @click="jumpRouter(2, item.merId)"
                ></card-cell>
            </pull-down-refresh>

            <empty-placeholder v-else :showTitle="'暂无商户交易佣金数据'" />
        </div>

        <div v-else-if="tabKey === 3">
            <pull-down-refresh
                v-if="listData2.length > 0"
                id="pullDownBox"
                :threshold="120"
                wrapper="comments-scroll"
                @scroll="fetchMore"
            >
                <card-cell
                    v-for="(item, index) in listData2"
                    :key="index"
                    :headerTitle="item.headerTitle"
                    :headerText="item.headerText"
                    :contentList="item.contentList"
                ></card-cell>
            </pull-down-refresh>

            <empty-placeholder v-else :showTitle="'暂无差错佣金数据'" />
        </div>

        <div class="tabbar-button-box" v-if="isWait == 2">
            <tabbar-btn clstag="jr|keycount|dl_wdqy_yjhf_dhyj|ccyjtb" :custom="true" @btnClickValue="bottomBtnClick">
                <div class="button-box">
                    <div class="button-title">差错佣金提报</div>
                    <div class="button-text">如有错误请在当月提交，之后将无法提交</div>
                </div>
            </tabbar-btn>
        </div>

        <!-- 输入框弹窗组件 -->
        <alert-overlay
            :show="showOverlay"
            :alertType="2"
            :confirmEvent="confirm"
            :cancelEvent="cancel"
            :tagStringConfirm="'jr|keycount|dl_wdqy_yjhf_czjl_tc|qr'"
            :tagStringCancel="'jr|keycount|dl_wdqy_yjhf_czjl_tc|qs'"
        >
            <div class="headerTitle">
                请输入{{batch}}月差错佣金
            </div>
            <div class="money-input">
                <span>¥</span>
                <van-field clstag="jr|keycount|dl_wdqy_yjhf_czjl|qsr" v-model="inputVal"></van-field>
            </div>
        </alert-overlay>

        <!-- 成功弹窗组件 -->
        <alert-success 
            v-if="successStatus"
            :successTitle="'提交成功!'"
            :complete="successComplete"
        ></alert-success>
    </div>
</template>

<script>
    import dayjs from 'dayjs'
    // 引入 cardCell 组件
    import tableCell from '@/merchant-bd/components/tableCell'
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    // 引入 cardCell 组件
    import cardCell from '@/merchant-bd/components/cardCell'
    // 引入 tabbarBtn 组件
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'
    // 引入 alertOverlay 组件
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    // 数据为空的时候 组件
    // 引入 success 弹窗组件1
    import { Toast } from 'vant'
    // 引入api
    import api from '@/merchant-bd/api/main'
    import emptyPlaceholder from '@/merchant-bd/components/emptyPlaceholder'
    import * as manage from '@/merchant-bd/api/manage'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    import alertSuccess from '../../performance/components/alertSuccess'

    export default {
        name: 'approval',
        components: {
            tableCell,
            pullDownRefresh,
            cardCell,
            tabbarBtn,
            alertSuccess,
            alertOverlay,
            emptyPlaceholder
        },
        data () {
            const { isWait } = this.$route.query
            const { batch } = this.$route.query
            return {
                paramsObj: {
                    currentPage: 1,
                    pageSize: 10,
                    batch: Number(batch) || 202003,
                    bizType: 1 // 1拓店；2GMV交易；3差异
                },
                batch: Number(batch) || 202003,
                resData: {},
                listKeys: [
                    'cityName',
                    'addAmount'
                ],
                listAKeys: [
                    'cityName',
                    'addAmount'
                ],
                isWait,
                tabKey: 1,
                tableTitles: {
                    name: 'A级城市拓店佣金（0）',
                    number: '佣金 0'
                },
                totalSum: '0',
                businessSum: '0',
                dealSum: '0',
                mistakeSum: '0',
                listA: [],
                listB: [],
                listC: [],
                listData: [],
                listData2: [],
                onload: true,
                successStatus: false,
                showOverlay: false,
                inputVal: '',
                currentPage: 1,
                fetch: false,
                hasMore: true,
                autoFetch: true
            }
        },
        mounted () {
            // if (this.tabbarKey === 2) this.fetchMore()
            this.waitConfirm()
            // this.isWait = 2
        },
        watch: {
            tabbarKey: () => {
                if (this.tabbarKey === 2) this.fetchMore()
            }
        },
        methods: {
            // 顶部 tab 切换
            tabbarClick (key) {
                console.log(key)
                this.tabKey = key
                // 重置数据
                this.listData = []
                this.listData2 = []

                const data = {
                    organId: JSON.parse(localStorage.getItem('organId')),
                    cityId: this.$route.query.cityId || 1,
                    // currentPage: this.currentPage || 1,
                    currentPage: 1,
                    bizType: 1,
                    size: 10,
                    batch: Number(this.$route.query.batch) || 202003
                }
                if (key === 1) {
                    data.bizType = 1
                    this.waitConfirm
                } else if (key === 2) {
                    data.bizType = 2
                } else if (key === 3) {
                    data.bizType = 3
                }
                this.requestWaitConfirm(data)
            },
            // 滚动加载数据
            fetchMore () {
                const data = {
                    organId: JSON.parse(localStorage.getItem('organId')),
                    cityId: this.$route.query.cityId || 1,
                    currentPage: this.currentPage || 1,
                    bizType: this.tabKey || 1,
                    size: 10,
                    batch: this.batch
                }
                console.log(1)

                if (this.currentPage > 1 && this.autoFetch) {
                    const windowH = window.screen.height
                    const pullDownBoxH = document.getElementById('pullDownBox').offsetHeight
                    console.log('windowH:', windowH)
                    console.log('pullDownBoxH:', pullDownBoxH)

                    if (pullDownBoxH && (windowH >= (pullDownBoxH + 150))) {
                        if (this.onload) {
                            this.onload = false
                            switch (this.tabKey) {
                                case 2:
                                    data.bizType = 2
                                    this.requestWaitConfirm(data)
                                    break
                                case 3:
                                    data.bizType = 3
                                    this.requestWaitConfirm(data)
                                    break
                                default:
                                    break
                            }
                        }
                    } else {
                        this.autoFetch = false
                        return
                    }
                }

                if (this.onload) {
                    this.onload = false
                    switch (this.tabKey) {
                        case 2:
                            data.bizType = 2
                            this.requestWaitConfirm(data)
                            break
                        case 3:
                            data.bizType = 3
                            this.requestWaitConfirm(data)
                            break
                        default:
                            break
                    }
                }
            },
            // 底部按钮事件
            bottomBtnClick () {
                console.log('底部按钮点击')
                this.showOverlay = true
            },
            // success alert 完成事件
            successComplete () {
                this.inputVal = ''
                this.successStatus = false
            },
            // 拓店佣金 接口
            waitConfirm () {
                this.fetch = true
                const _this = this
                manage.waitConfirm(this.paramsObj, d => {
                    if (this.paramsObj.bizType == 2) {
                        if (d.merGmvInfos.length < this.paramsObj.pageSize) {
                            this.hasMore = false
                        } else {
                            this.hasMore = true
                        }
                    }
                    this.fetch = false
                    _this.totalSum = d.data.totalMoney
                    _this.businessSum = d.data.addUpMoney
                    _this.dealSum = d.data.gmvMoney
                    _this.mistakeSum = d.data.diffMoney

                    console.log('佣金返回', d.data.cityAddInfos[0])
                    this.resData = d.data
                    const newArray = d.data.cityAddInfos[0].map((item, index) => {
                        if (index === 0) {
                            item.cityName = `${item.cityName}拓店佣金(${item.addCount})`
                            item.addAmount = `佣金${item.addAmount}`
                        } else {
                            item.cityName = `${item.cityName}(${item.addCount})`
                            item.addAmount = `佣金${item.addAmount}`
                        }
                        return item
                    })
                    _this.listA = newArray

                    const newArrayB = d.data.cityAddInfos[1].map((item, index) => {
                        if (index === 0) {
                            item.cityName = `${item.cityName}拓店佣金(${item.addCount})`
                            item.addAmount = `佣金${item.addAmount}`
                        } else {
                            item.cityName = `${item.cityName}(${item.addCount})`
                            item.addAmount = `佣金${item.addAmount}`
                        }
                        return item
                    })
                    _this.listB = newArrayB

                    const newArrayC = d.data.cityAddInfos[2].map((item, index) => {
                        if (index === 0) {
                            item.cityName = `${item.cityName}拓店佣金(${item.addCount})`
                            item.addAmount = `佣金${item.addAmount}`
                        } else {
                            item.cityName = `${item.cityName}(${item.addCount})`
                            item.addAmount = `佣金${item.addAmount}`
                        }
                        return item
                    })
                    _this.listC = newArrayC
                })
            },
            // 商户交易佣金
            requestWaitConfirm (data) {
                const _this = this
                api.commission.waitConfirm(data, res => {
                    console.log('res:', res)
                    _this.onload = true
                    let arrLength = 0
                    // 请求商户交易佣金数据
                    if (data.bizType === 2) {
                        arrLength = res.data.merGmvInfos.length
                        const newArray = res.data.merGmvInfos.map(item => {
                            item.headerTitle = item.merName
                            let afterPhone = '****'
                            if (item.phone) afterPhone = item.phone.substring(item.phone.length - 4, item.phone.length)
                            item.headerText = `${item.staffName}(${afterPhone})`
                            item.contentList = [
                                {
                                    title: '政策版本号',
                                    text: item.bizVersion
                                },
                                {
                                    title: '交易单数',
                                    text: item.tradeCount
                                },
                                {
                                    title: '交易金额',
                                    text: item.tradeMoney
                                }
                            ]
                            return item
                        })
                        _this.listData = _this.listData.concat(newArray)
                    } else if (data.bizType === 3) {
                        arrLength = res.data.diffInfos.length
                        const newArray = res.data.diffInfos.map(item => {
                            item.headerTitle = `订单号${item.settleNo}`
                            item.headerText = ''
                            item.contentList = [
                                {
                                    title: '差错月份',
                                    text: item.batch
                                },
                                {
                                    title: '差错佣金',
                                    text: item.money
                                },
                                {
                                    title: '时间',
                                    text: this.dateTool(item.createTime)
                                }
                            ]
                            return item
                        })
                        _this.listData2 = _this.listData2.concat(newArray)
                    }
                    
                    console.log('arrLength:', arrLength)
                    console.log('data.size:', data.size)
                    // 判断是否需要加载
                    if (arrLength < data.size) {
                        // 如果没数据了，则暂停刷新
                        _this.onload = false
                    } else {
                        _this.currentPage++
                    }

                    if (_this.autoFetch) {
                        setTimeout(() => {
                            _this.fetchMore()
                        }, 1000) 
                    }
                })
            },
            confirm () {
                if (!/^[0-9]+(.[0-9]{1,3})?$/.test(this.inputVal)) {
                    Toast.fail('请输入数字')
                    return false
                }
                this.showOverlay = false
                const param = {
                    bizType: 3,
                    money: this.inputVal
                }
                fetch.post(
                    {
                        url: apiUrl.addDiffSettleFlow,
                        data: {
                            ...param
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            this.successStatus = true
                        } else {
                            Toast.fail(res.result.info)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            cancel () {
                this.showOverlay = false
            },
            // 时间转化格式
            dateTool (time) {
                // console.log('time:', time)
                return dayjs(time).format('YYYY-MM-DD')
            },
            // 拓店佣金路由跳转
            jumpRouter (index, item) {
                console.log('jumpRouter11:', index, item)
                if (index === 1) {
                    this.$router.push({
                        name: '/business/my/city-data',
                        query: {
                            merchantId: item.cityId,
                            batch: this.batch,
                            cityId: item.cityId
                        }
                    })
                } else if (index === 2) {
                    this.$router.push({
                        name: '/business/my/store-deal',
                        query: {
                            cityId: item.merId,
                            batch: this.batch,
                            amount: item.tradeMoney,
                            merchantId: item
                        }
                    })
                } else if (index === 3) {
                    // this.$router.push({
                    //     name: '/business/my/store-deal',
                    //     params: {
                    //         cityId: item.merId,
                    //         batch: 202003
                    //     }
                    // })
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
.approval-container {
    width: 100%;
    height: auto;
    background-color: #F5F8FC;
    margin-bottom: 0.8rem;

    .header-box {
        width: 100%;
        height: 0.9rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;

        .amount {
            font-size: 0.18rem;
            font-weight: 500;
            color: #2E2D2D;
        }

        .title {
            font-size: 0.15rem;
            font-weight: 400;
            color: #BBBBBB;
            margin-top: 0.08rem;
        }
    }

    .header-tabbar-box {
        width: 100%;
        height: 0.8rem;
        background-color: #FFFFFF;
        display: flex;
        align-items: center;

        .tab-bar-box {
            flex: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border-bottom: 0.03rem solid #FFFFFF;

            .bar-amount {
                font-size: 0.15rem;
                font-weight: 500;
                color: #E0E0E0;
            }

            .bar-title {
                font-size: 0.13rem;
                font-weight: 400;
                color: #E0E0E0;
            }

            .actived-amount {
                color: #2E2D2D;
            }

            .actived-title {
                color: #BBBBBB;
            }
        }

        .actived {
            border-bottom-color: #F0250F;
        }

        .split {
            width: 0.01rem;
            height: 0.3rem;
            background-color: #EEF1F4;
        }
    }

    .tabbar-button-box {
        position: fixed;
        bottom: 0;

        .button-box {
            width: 100%;
            height: 100%;
            text-align: center;

            .button-title {
                font-size: 0.15rem;
                line-height: 0.15rem;
                font-weight: 500;
                margin-top: 0.16rem;
                margin-bottom: 0.07rem;
                color: #FFFFFF;
            }

            .button-text {
                font-size: 0.12rem;
                line-height: 0.12rem;
                color: #FFFFFF;
            }
        }
    }
}
.money-input {
    font-size: 0.15rem;
    position: relative;
    span {
        position: absolute;
        top: 0.08rem;
        left: 0.25rem;
        z-index: 100;
    }
}
.headerTitle {
    font-size: 0.16rem;
    font-weight: 400;
    color: #000000;
    text-align: center;
}
/deep/ .van-cell__value--alone {
    background-color: #f5f8fc;
}
/deep/ .van-field__control {
    width: auto !important;
    margin-left: 0.3rem;
}
</style>
