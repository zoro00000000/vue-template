<template>
    <div class="operation-log-container">
        <div class="header-tabbar-box">
            <div clstag="jr|keycount|dl_wdqy_yjhf_czjl|dhyjqr" class="tab-bar-box" @click="tabbarClick(1)">
                <div
                    :class="tabbarKey === 1 ? 'tab-bar-actived' : ''"
                    class="tab-bat-text"
                >
                    待核佣金确认
                </div>
                <div
                    :class="tabbarKey === 1 ? 'tab-bar-line-actived' : ''"
                    class="tab-bar-line"
                ></div>
            </div>
            <div clstag="jr|keycount|dl_wdqy_yjhf_czjl|sqdk" class="tab-bar-box" @click="tabbarClick(2)">
                <div
                    :class="tabbarKey === 2 ? 'tab-bar-actived' : ''"
                    class="tab-bat-text"
                >
                    申请打款
                </div>
                <div
                    :class="tabbarKey === 2 ? 'tab-bar-line-actived' : ''"
                    class="tab-bar-line"
                ></div>
            </div>
            <div clstag="jr|keycount|dl_wdqy_yjhf_czjl|ceyjtb" class="tab-bar-box" @click="tabbarClick(3)">
                <div
                    :class="tabbarKey === 3 ? 'tab-bar-actived' : ''"
                    class="tab-bat-text"
                >
                    差错佣金提报
                </div>
                <div
                    :class="tabbarKey === 3 ? 'tab-bar-line-actived' : ''"
                    class="tab-bar-line"
                ></div>
            </div>
        </div>

        <div class="card-scroll-box">
            <pull-down-refresh
                id="pullDownBox"
                :threshold="120"
                wrapper="comments-scroll"
                @scroll="fetchMore"
            >
                <div v-if="tabbarKey === 1">
                    <div v-if="listData.length">
                        <card-cell
                        v-for="(item, index) in listData"
                        :key="index"
                        :headerTitle="'订单号 ' + item.bizId"
                        :headerText="item.date"
                        :contentList="item.contentList"
                        ></card-cell>
                    </div>
                    <div class="no-data" v-else>
                        <div class="no-data-icon">
                            <div class="no-data-icon"></div>
                            <div class="no-data-text">
                                暂无数据
                            </div>
                        </div>
                    </div>
                </div>

                <div v-else-if="tabbarKey === 2">
                    <div v-if="listData2.length">
                        <card-cell
                            v-for="(item, index) in listData2"
                            :key="index"
                            :headerTitle="'订单号 ' + item.bizId"
                            :headerText="item.date"
                            :contentList="item.contentList"
                            :headerBottomType="true"
                        >
                            <div class="track-box" @click="trackInput(item)" :class="item.num ? 'track-box-2' : ''">
                            <div v-if="!item.num" class="track-style-1" >
                                请输入邮寄单号
                            </div>

                            <div v-else  class="track-style-2">邮寄单号:{{ item.num }}</div>

                            <div class="icon-style">
                                <van-icon name="arrow" />
                            </div>
                            </div>
                        </card-cell>
                    </div>
                    <div class="no-data" v-else>
                        <div class="no-data-icon">
                            <div class="no-data-icon"></div>
                            <div class="no-data-text">
                                暂无数据
                            </div>
                        </div>
                    </div>
                </div>

                <div v-else-if="tabbarKey === 3">
                    <div v-if="listData3.length">
                        <card-cell
                            v-for="(item, index) in listData3"
                            :key="index"
                            :headerTitle="'订单号 ' + item.bizId"
                            :headerText="item.date"
                            :contentList="item.contentList"
                        ></card-cell>
                    </div>

                    <div class="no-data" v-else>
                        <div class="no-data-icon">
                            <div class="no-data-icon"></div>
                            <div class="no-data-text">
                                暂无数据
                            </div>
                        </div>
                    </div>
                </div>
            </pull-down-refresh>
        </div>

        <div>
            <alert-overlay
                :show="showOverlay"
                :alertType="2"
                :confirmEvent="confirm"
                :cancelEvent="cancel"
            >
                <div class="headerTitle">请输入邮寄单号</div>
                <div>
                    <van-field v-model="inputVal"></van-field>
                </div>
            </alert-overlay>
        </div>
    </div>
</template>

<script>
// 引入 cardCell 组件
    import cardCell from '@/merchant-bd/components/cardCell'
    // 引入 alertOverlay 组件
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    import dayjs from 'dayjs'
    import { Toast } from 'vant'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'

    export default {
        name: 'operationLog',
        components: {
            cardCell,
            pullDownRefresh,
            alertOverlay
        },
        data () {
            return {
                listData: [],
                listData2: [],
                listData3: [],
                tabbarKey: 1,
                onload: true,
                showOverlay: false,
                inputVal: '',
                type: 'A',
                PageSize: 10,
                pageNo: 1,
                pageNoB: 1,
                pageNoC: 1,
                hasMore: false
            }
        },
        mounted () {
            // this.fetchMore()
            this.initData(this.tabbarKey)
        },
        methods: {
            initData (num) {
                const param = {
                    type: this.type,
                    PageSize: this.PageSize,
                    pageNo: this.pageNo
                }
                if (num == 1) {
                    param.type = 'A'
                    param.pageNo = this.pageNo
                } else if (num == 2) {
                    param.type = 'B'
                    param.pageNo = this.pageNoB
                } else if (num == 3) {
                    param.type = 'C'
                    param.pageNo = this.pageNoC
                }

                fetch.post(
                    {
                        url: apiUrl.queryRecordDataList,
                        data: {
                            ...param
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            const listData = res.data
                            
                            if (num == 1) {
                                this.listData = this.listData.concat(this.changeData(listData))
                                this.hasMore = false
                               
                                if (res.data.length < this.PageSize) {
                                    // Toast('到底了')
                                    this.hasMore = true
                                    return false
                                } else {
                                    this.pageNo++
                                }
                            } else if (num == 2) {
                                this.listData2 = this.listData2.concat(this.changeData(listData))
                                this.hasMore = false
                                if (res.data.length < this.PageSize) {
                                    // Toast('到底了')
                                    this.hasMore = true
                                    return false
                                } else {
                                    this.pageNoB++
                                }
                            } else if (num == 3) {
                                this.listData3 = this.listData3.concat(this.changeData(listData, 3))
                                this.hasMore = false
                                if (res.data.length < this.PageSize) {
                                    // Toast('到底了')
                                    this.hasMore = true
                                    return false
                                } else {
                                    this.pageNoC++
                                }
                            }
                        } else {
                            const err = res.result.info.slice(7, res.result.info.length - 1)
                            Toast.fail(err)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            tabbarClick (val) {
                console.log(`val:${val}`)
                
                if (this.tabbarKey == val) return
                this.pageNo = 1
                this.pageNoB = 1
                this.pageNoC = 1
                this.listData.splice(0)
                this.listData2.splice(0)
                this.listData3.splice(0)
                
                this.hasMore = false
                this.tabbarKey = val
                this.initData(val)
            },
            // 滚动加载数据
            fetchMore () {
                console.log('scroll')
                if (!this.hasMore) {
                    this.hasMore = true
        
                    this.scrollLoadData(this.tabbarKey)
                }
            },
            scrollLoadData (n) {
                this.initData(n)
            },
            // 点击调起输入框
            trackInput (item) {
                this.inputVal = ''
                this.showOverlay = true
                this.itemId = item.id
            },
            // 遮罩层确定事件
            confirm () {
                // TODO: 暂时关闭校验
                // if (!/^(0[1-7]|1[0-356]|2[0-7]|3[0-6]|4[0-7]|5[1-7]|6[1-7]|7[0-5]|8[013-6])\d{4}$/.test(this.inputVal)) {
                //     Toast.fail('请输入正确的邮寄单号格式')
                //     return false
                // }
                this.showOverlay = false
                fetch.post(
                    {
                        url: apiUrl.addMailNumReq,
                        data: {
                            id: this.itemId,
                            num: encodeURIComponent(this.inputVal)
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            this.listData2.splice(0)
                            this.pageNoB = 1
                            this.initData(this.tabbarKey)
                        } else {
                            Toast.fail(res.result.info)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            // 遮罩层取消事件
            cancel () {
                this.showOverlay = false
            },
            changeData (arr, type) {
                return arr.map(item => {
                    const cell = item
                    cell.contentList = [
                        {
                            title: '月份',
                            text: item.month || 'YYYY-MM-DD'
                        },
                        {
                            title: '计费金额',
                            text: item.money || 0
                        },
                        {
                            title: '结算金额',
                            text: item.actMoney || 0
                        },
                        {
                            title: '状态',
                            text: item.status || '无'
                        }
                    ]

                    if (type === 3) {
                        cell.contentList.splice(1, 2, { title: '金额', text: item.money || 0 })
                    }
                    cell.date = dayjs(item.date).format('YYYY-MM-DD')
                    return cell
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
.operation-log-container {
    width: 100%;
    height: auto;

    .header-tabbar-box {
        position: fixed;
        top: 0;
        width: 100%;
        height: 0.5rem;
        padding: 0 0.16rem;
        box-sizing: border-box;
        background-color: #f5f8fc;
        display: flex;
        flex-direction: row;
        z-index: 100;
        .tab-bar-box {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;

            .tab-bat-text {
                width: 1;
                margin-top: 0.24rem;
                margin-bottom: 0.07rem;
                font-size: 0.15rem;
                line-height: 0.15rem;
                font-weight: 300;
                color: #000000;
                text-align: center;
            }

            .tab-bar-line {
                width: 0.25rem;
                height: 0.03rem;
                border-radius: 0.2rem;
                // background-color: #F0250F;
            }

            .tab-bar-actived {
                color: #f0250f;
            }

            .tab-bar-line-actived {
                background-color: #f0250f;
            }
        }

        .tab-bar-box:first-child .tab-bat-text {
            width: 1rem;
        }

        .tab-bar-box:last-child .tab-bat-text {
            text-align: right;
            width: 1rem;
        }
    }
    .card-scroll-box {
        padding-top: 0.5rem;
    }
    .track-box {
        height: 0.49rem;
        padding: 0 0.12rem;
        box-sizing: border-box;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #f0250f;

        .track-style-1 {
            font-size: 0.15rem;
            line-height: 0.15rem;
            font-weight: 400;
            color: #f0250f;
        }

        .track-style-2 {
            font-size: 0.15rem;
            line-height: 0.15rem;
            font-weight: 400;
            color: #2e2d2d;
        }

        .icon-style {
            font-size: 0.15rem;
            line-height: 0.15rem;
            font-weight: 400;
            margin-left: 0.1rem;
        }
    }

    .track-box-2 {
        justify-content: space-between;
        color: #2e2d2d;
    }

    .headerTitle {
        font-size: 0.16rem;
        font-weight: 400;
        color: #000000;
        text-align: center;
    }

    /deep/ .van-cell__value--alone {
        background-color: #f5f8fc;
    }
}
.no-data {
    //margin-top:.5rem;
    position: fixed;
    top:50%;
    left: 50%;
    transform: translate(-50%,-50%);
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #f5f8fc;
    .no-data-icon {
        width: 1.45rem;
        height: 1.45rem;
        background-color: #e4e4e4;
        border-radius: 50%;
        background: url('../../../../assets/img/empty.png') no-repeat;
        background-position: center center;
        background-size: 100% 100%;
    }
    .no-data-text {
        color: #2e2d2d;
        font-size: 0.15rem;
        font-weight: 500;
        text-align: center;
        margin-top: 0.28rem;
    }
}
</style>
