<template>
    <div class="questions-container">
        <div v-if="listData.length > 0">
            <collapse-box 
                v-for="(item, index) in listData"
                :key="index"
                :activeNames="index"
                :collapseTitle="item.title"
                :collapseText="item.text"
                :collapseImgs="item.imageUrls"
            />
        </div>

        <empty-palceholder v-else />
    </div>
</template>

<script>
    // 抽拉框组件
    import collapseBox from '@/merchant-bd/components/collapseBox'
    // 数据为空的时候 组件
    import emptyPalceholder from '@/merchant-bd/components/emptyPlaceholder'
    import api from '@/merchant-bd/api/main'

    export default {
        name: 'questions',
        components: {
            collapseBox,
            emptyPalceholder
        },
        data () {
            return {
                listData: []
            }
        },
        mounted () {
            this.init()
        },
        methods: {
            init () {
                const _this = this
                const data = {
                    sortType: 'asc',
                    sortField: 'useful_count',
                    currentPage: 1,
                    pageSize: 15,
                    BizType: 1
                }
                api.company.listComnQuestion(data, res => {
                    console.log('res:', res)
                    _this.listData = res.data
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
.questions-container {
    width: 100%;
    min-height: 100vh;
    background-color: #F5F8FC;
}
</style>
