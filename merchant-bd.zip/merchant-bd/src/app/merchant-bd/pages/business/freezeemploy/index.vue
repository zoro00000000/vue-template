<template>
    <div class="wrap">
        <alert-success v-if="alert" :successTitle="successTitle" :complete="onSuccess"></alert-success>
        <form-data  v-else>
            <div class="wk-title">员工姓名</div>
            <van-field v-model="fromData.name" name="name" placeholder="请输入员工姓名" :clearable=true @input="onChange" />
            <div class="wk-title">PIN</div>
            <van-field v-model="fromData.updatePin" name="pin" placeholder="请输入员工京东PIN" :clearable=true @input="onChange" />
            <div class="wk-title">手机号</div>
            <van-field v-model="fromData.phone" name="phone" placeholder="请输入员工手机号"  :clearable=true @input="onChange" />
            <div class="wk-title">状态</div>
            <div class="status" :class="freeze?'red':''">{{freeze?'冻结':'正常'}}</div>
            <!-- <van-field v-model="fromData.status" name="status" placeholder="请输入员工状态" :clearable=true /> -->
            <div class="wk-title">创建时间</div>
            <div class="status">{{createTime}}</div>
            <div class="btns">
                <van-button clstag="jr|keycount|dl_wdqy_ygzhgl|tj" :disabled="disabledBtn" class="button-submit" :class="ifSubmit?'':'forbid'" round block type="info" native-type="submit" @click="editSubmit">
                    提交
                </van-button>
                <van-button clstag="jr|keycount|dl_wdqy_ygzhgl|djyg" :disabled="disabledBtn" v-if="!freeze" class="button-freeze" round block type="info" native-type="submit" @click="freezeSubmit">
                    冻结账户
                </van-button>
                <van-button :disabled="disabledBtn" v-else  class="button-freeze" round block type="info" native-type="submit" @click="outFreezeSubmit">
                    解冻账户
                </van-button>
            </div>
        </form-data>
        <!-- 遮罩蒙层 -->
        <alert-overlay 
            :show="diglog"
            :alertType="2"
            :headerTitle="''"
            :contentText="contentText"
            :confirmEvent="confirmClick"
            :cancelEvent="cancelClick"
            :showSolt="false"
        />
    </div>
</template>

<script>
    import { Toast } from 'vant'
    import formData from '@/merchant-bd/components/formData'
    import alertSuccess from '@/merchant-bd/pages/business/performance/components/alertSuccess'
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    import * as manage from '@/merchant-bd/api/manage'

    export default {
        data () {
            const { staffId } = this.$route.query
            return {
                fromData: {
                    name: '',
                    updatePin: '',
                    phone: '',
                    freeze: 0,
                    updateStaffId: staffId
                },
                originData: {
                    name: '',
                    pin: '',
                    phone: ''
                },
                freeze: 0,
                createTime: '',
                staffId,
                alert: false,
                diglog: false,
                contentText: '', // 弹框内容
                diglogType: 1, // 弹框1修改,2冻结,3解冻
                successTitle: '变更成功',
                ifSubmit: false,
                disabledBtn: false
            }
        },
        components: {
            formData,
            alertSuccess,
            alertOverlay
        },
        mounted () {
            this.queryBDStaffInfoByStaffId()
        },
        methods: {
            editSubmit () {
                if (!this.ifSubmit) return
                if (!this.dataCheckout()) return
                console.log('提交', this.fromData)
                this.diglog = true
                // this.contentText = `是否创建员工:${this.fromData.name}`
                this.contentText = '是否确认操作？'
                this.diglogType = 1
            },
            freezeSubmit () {
                this.fromData.freeze = 1
                if (!this.dataCheckout()) return
                this.diglog = true
                this.contentText = `冻结账户权限后,${this.fromData.name}将不能正常使用账户，确认该操作么?`
                this.diglogType = 2
            },
            outFreezeSubmit () {
                this.fromData.freeze = 0
                if (!this.dataCheckout()) return
                this.diglog = true
                this.contentText = `账户解冻后，员工${this.fromData.name}将正常使用该账户，是否解冻？`
                this.diglogType = 3
            },
            dataCheckout () {
                const d = this.fromData
                if (!this.phoneValidator(d.phone)) {
                    Toast('手机号不正确')
                    return false
                }
                if (!d.name) {
                    Toast('姓名不为空')
                    return false
                } else if (!d.updatePin) {
                    Toast('pin不为空')
                    return false
                } else {
                    return true
                }
            },
            // 校验函数返回 true 表示校验通过，false 表示不通过
            phoneValidator (val) {
                return /1\d{10}/.test(val)
            },
            onSuccess () {
                this.$router.push({
                    path: '/company/accounts'
                })
                this.alert = false
                console.log('返回员工账户管理')
            },
            confirmClick () {
                if (this.diglogType == 1) {
                    this.updateBDStaffInfo()
                } else {
                    this.updateBDStaffInfoFreeze()
                }
                this.diglog = false
                this.diglogType = 1
            },
            cancelClick () {
                this.diglog = false
                this.diglogType = 1
            },
            queryBDStaffInfoByStaffId () {
                manage.queryBDStaffInfoByStaffId({ staffId: this.staffId, currentPage: 1, pageSize: 1 }, d => {
                    console.log('员工信息', d)
                    this.fromData.name = d.data.name
                    this.fromData.updatePin = d.data.pin
                    this.fromData.phone = d.data.phone
                    this.fromData.freeze = d.data.freeze
                    this.freeze = d.data.freeze
                    this.createTime = d.data.createTime
                    this.originData.name = d.data.name
                    this.originData.pin = d.data.pin
                    this.originData.phone = d.data.phone
                    if (d.data.parentId === '0') this.disabledBtn = true
                })
            },
            updateBDStaffInfo () {
                manage.updateBDStaffInfo(this.fromData, d => {
                    this.successTitle = '变更成功'
                    this.alert = true
                    console.log('跟新员工信息', d)
                })
            },
            datePickerEvent () {
                this.$refs.dataPicker.datePickerEvent()
            },
            dateUpdate (d) {
                this.fromData.createTime = d
                console.log(d)
            },
            updateBDStaffInfoFreeze () {
                manage.updateBDStaffInfoFreeze(this.fromData, d => {
                    if (d.result.code == '0000') {
                        this.successTitle = '提交成功'
                        this.alert = true
                        console.log('操作成功')
                    }
                })
            },
            onChange () {
                if (this.originData.name !== this.fromData.name || this.originData.pin !== this.fromData.updatePin || this.originData.phone !== this.fromData.phone) {
                    this.ifSubmit = true
                } else {
                    this.ifSubmit = false
                }
                console.log(this.fromData.name, this.originData.name)
            }
        }
    }
</script>

<style lang = "scss" scoped>
.wk-title {
    font-size: 0.15rem;
    height: 0.35rem;
    line-height: 0.35rem;
    color: rgba(132, 132, 132, 1);
    background: rgba(244, 244, 244, 1);
    font-weight: normal;
    padding: 0 0.12rem;
}
.van-field {
  padding: 0 0.12rem;
  line-height: 0.5rem;
  font-size: 0.15rem;
}
.status{
    height: .5rem;
    line-height: .5rem;
    background:#fff;
    padding-left: .12rem;
    font-size: .15rem;
}
.red{
    color:#F0250F;
}
.btns{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: .28rem .12rem;
    .button-freeze{
        width: 1.7rem;
        height: .4rem;
        background: #fff;
        border:.01rem solid #F0250F;
        box-sizing: border-box;
        color:#F0250F;
    }
    .button-submit{
        width: 1.7rem;
        height: .4rem;
        background:linear-gradient(270deg,rgba(222,49,33,1) 0%,rgba(236,86,42,1) 100%);       
        color:#FFDCC3;
    }
    .forbid{
        opacity: 0.5;
    }
}

</style>
