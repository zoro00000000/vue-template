<template>
    <div class="commission-container">
        <div class="header-box">
            <div class="list-box">
                <div class="item-info-box">
                    <div class="amount-style">{{ commission.addUpMoney }}</div>
                    <div class="name-style">累计佣金</div>
                </div>
                <div class="split-box"></div>
            </div>
            <div class="list-box">
                <div class="item-info-box">
                    <div class="amount-style">{{ commission.expandMoney }}</div>
                    <div class="name-style">拓店佣金</div>
                </div>
                <div class="split-box"></div>
            </div>
            <div class="list-box">
                <div class="item-info-box">
                    <div class="amount-style">{{ commission.dealMoney }}</div>
                    <div class="name-style">商户交易佣金</div>
                </div>
            </div>
        </div>

        <div class="tabbar-box">
            <div class="tab-left-button" clstag="jr|keycount|dl_wdqy_yjhf|dhyj" @click="tabBtnClick(1)">
                <div
                    class="tab-title-box"
                    :class="activated == 1 ? 'activeted-style' : ''"
                >
                    待核佣金
                    <div class="button-split"></div>
                </div>
            </div>

            <div class="tab-right-button" clstag="jr|keycount|dl_wdqy_yjhf|dfyj" @click="tabBtnClick(2)">
                <div
                    class="tab-title-box"
                    :class="activated == 2 ? 'activeted-style' : ''"
                >
                    待发佣金
                    <div class="button-split"></div>
                </div>
            </div>
        </div>

        <div class="table-cell-box" v-if="tableList.length">
            <table-cell
                v-for="(item, index) in tableList"
                :key="index"
                :titles="item.title"
                :isJump="true"
                :isBold="false"
                :isGayBGColor="false"
                :lastIsRight="true"
                @click="onApprovals(item)"
            />

            <div v-if="activated === 1" class="warning-title">
                *注：小规模纳税人结算金额=待核佣金*（1-3%），3%为小规模纳税人承担税损部分；一般纳税人结算金额=待核佣金。
            </div>
        </div>

        <div class="no-data" v-else>
            <div class="no-data-icon">
                <div class="no-data-icon"></div>
                <div class="no-data-text">
                    暂无数据
                </div>
            </div>
        </div>

        <div class="button-box">
            <button clstag="jr|keycount|dl_wdqy_yjhf|czjl" @click="operatingRecord" class="operating-record-button">
                操作明细
                <van-icon style="display: block;" name="arrow" />
            </button>

            <tabbar-btn :custom="true">
                <div v-if="activated == 1" clstag="jr|keycount|dl_wdqy_yjhf|yjhd" :class="['button-style',isGrey?'grey':'']" @click="confirm" >
                    <div class="button-title-1">佣金核对</div>
                    <div class="button-title-2">每月1-10号核对上月佣金，超过10号系统默认核对</div>
                </div>

                <div v-if="activated == 2" clstag="jr|keycount|dl_wdqy_yjhf|sqdk" :class="['button-style',isGreyB?'grey':'']" @click="confirm">
                    <div class="button-title-1">申请打款</div>
                    <div class="button-title-2">对当前所有待发佣金发起打款申请</div>
                </div>
            </tabbar-btn>
        </div>

        <!-- 遮罩蒙层 -->
        <alert-overlay
            :show="overlayStatus"
            :alertType="2"
            :confirmEvent="confirmClick"
            :cancelEvent="cancelClick"
        >
            <div v-if="activated === 1" class="overlay-text-style">
                {{ allDay }}月结算金额为
                <span class="amount-style">{{ allMoney }}</span>
                请与予核对。若金额存在问题，需在本月提交核对后在“待发佣金”提交“差错佣金提报”，审核通过后将计入下个月待核佣金进行补发
            </div>

            <div v-if="activated === 2" class="overlay-text-style">
                {{ allDay }}月合计待发结算佣金为
                <span class="amount-style">{{ allMoney }}</span>
                ，提交申请打款后，请以该金额开具专票并邮寄至{{commission.address}}，工作人员会对金额与专票进行审核，审核完成后将会打款至您的
                <span class="amount-style">企业对公账户</span>
                ，确认提交申请么？
            </div>
        </alert-overlay>

        <!-- 成功弹窗 -->
        <alert-success
            v-if="alertStatus"
            :successTitle="isActive == 1 ? '已核对' : '提交成功'"
            :complete="completeFun"
            :tagStringConfirm="'jr|keycount|dl_wdqy_yjhf_tc|qd'"
            :tagStringCancel="'jr|keycount|dl_wdqy_yjhf_tc|qx'"
        >
            <div v-if="activated == 2" class="success-content">
                您已成功提交打款请求，可在“
                <span class="text-style">操作记录——申请打款记录</span>
                ”中查看并可录入专票邮寄单号，方便工作人员接手快递
            </div>
        </alert-success>
    </div>
</template>

<script>
    // 引入 tabbar-btn 组件
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'
    // 引入 table-cell 组件
    import tableCell from '@/merchant-bd/components/tableCell'
    // 引入 蒙层 组件
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    // 引入成功浮层
    import { Toast } from 'vant'
    import alertSuccess from '../../performance/components/alertSuccess'
    
    export default {
        name: 'commission',
        components: {
            tabbarBtn,
            tableCell,
            alertOverlay,
            alertSuccess
        },
        data () {
            return {
                infoList: [
                    {
                        amount: '70000.00',
                        name: '累计佣金'
                    },
                    {
                        amount: '70000.00',
                        name: '拓店佣金'
                    },
                    {
                        amount: '70000.00',
                        name: '商户交易佣金'
                    }
                ],
                activated: 1,
                titles: {
                    name: '2020/03/07'
                },
                tableList: [
                    // {
                    //   name: '2020/03/07',
                    //   title: {
                    //     name: '2020/03/07',
                    //     amount: '400.000.00',
                    //   },
                    // },
                ],
                // 遮罩层 状态
                overlayStatus: false,
                alertStatus: false,

                activeIndex: 0,
                organId: JSON.parse(localStorage.getItem('organId')) || '',
                commission: {},
                allMoney: 0,
                allDay: '',
                isActive: true,
                checkIds: '',
                isWait: 1, // 1待核2待发
                isGrey: false,
                isGreyB: false,
                dataLength: false,
                goGrey: false,
                goGreyB: false,
                num: ''
            }
        },
        created () {
            this.initData()
        },
        methods: {
            initData () {
                const param = {
                    organId: this.organId
                }
                fetch.post(
                    {
                        url: apiUrl.querySettleFlowById,
                        data: {
                            ...param
                        }
                    }, res => {
                        if (res.result.code === '0000') {
                            this.commission = res.data
                            // console.log(
                            //     'waitConfirmbyMonthList--->',
                            //     this.commission.waitConfirmbyMonthList,
                            // )
                            // const list = this.commission.waitConfirmbyMonthList
                            if (this.commission.waitConfirmbyMonthList.length == 0 && this.activated == 1) {
                                this.isGrey = true
                            }
                            if (this.commission.waitbyMonthList.length == 0 && this.activated == 2) {
                                this.isGreyB = true
                            } 

                            // this.tableList = this.changeList(list)

                            if (this.activated === 1) {
                                const { waitConfirmbyMonthList } = this.commission
                                this.tableList = this.changeList(waitConfirmbyMonthList)
                                this.isWait = 1
                                this.tableList.length > 0 ? (this.isGrey = false) : (this.isGrey = true)
                            } else {
                                const { waitbyMonthList } = this.commission
                                this.tableList = this.changeList(waitbyMonthList)
                                this.isWait = 2
                                this.tableList.length > 0 ? (this.isGreyB = false) : (this.isGreyB = true)
                            }
                        } else {
                            const err = res.result.info.slice(7, res.result.info.length - 1)
                            Toast.fail(err)
                        }
                    }, err => {
                        console.log(err)
                    }
                )
            },
            // tab change 事件
            tabBtnClick (val) {
                console.log(val)
                // if (this.activated == val) return
                this.activated = val
                this.tableList = []
                this.initData()
                // if (val === 1) {
                //     const { waitConfirmbyMonthList } = this.commission
                //     this.tableList = this.changeList(waitConfirmbyMonthList)
                //     this.isWait = 1
                //     this.tableList.length > 0 ? (this.isGrey = false) : (this.isGrey = true)
                // } else {
                //     const { waitbyMonthList } = this.commission
                //     this.tableList = this.changeList(waitbyMonthList)
                //     this.isWait = 2
                //     this.tableList.length > 0 ? (this.isGreyB = false) : (this.isGreyB = true)
                // }
            },
            changeList (arr) {
                let list = []
                list = arr.map(item => {
                    const cell = {}
                    cell.name = item.batchFormat
                    cell.settleNo = item.settleNo
                    cell.id = item.id
                    cell.batch = item.batch
                    cell.amount = item.allMoney
                    cell.title = {
                        name: item.batchFormat,
                        amount: `结算金额 ${item.allMoney}`
                    }
        
                    return cell
                })
                console.log('list------kkkk--->', list)
                return list
            },
            // 底部按钮 事件
            confirm () {
                // console.log('核对佣金', this.activated)
                if (this.activated == 1) {
                    if (this.isGrey) {
                        return
                    }
                    this.changeData()
                } else {
                    if (this.isGreyB) {
                        return
                    }
                    this.changeData()
                }

                this.overlayStatus = true
                console.log(this.overlayStatus)
            },
            // 遮罩层 确定事件
            confirmClick () {
                this.overlayStatus = false
                if (this.activated == 1) {
                    const param = {
                        ids: this.checkIds
                    }
                    fetch.post(
                        {
                            url: apiUrl.modifyModifySettle,
                            data: {
                                ...param
                            }
                        },
                        res => {
                            if (res.result.code === '0000') {
                                this.alertStatus = true
                            } else {
                                const err = res.result.info.slice(7, res.result.info.length - 1)
                                Toast.fail(err)
                            }
                        },
                        err => {
                            console.log(err)
                        }
                    )
                } else {
                    const param = {
                        ids: this.checkIds
                    }
                    fetch.post(
                        {
                            url: apiUrl.updateModifySettle,
                            data: {
                                ...param
                            }
                        },
                        res => {
                            if (res.result.code === '0000') {
                                this.alertStatus = true
                            } else {
                                const err = res.result.info.slice(7, res.result.info.length - 1)
                                Toast.fail(err)
                            }
                        },
                        err => {
                            console.log(err)
                        }
                    )
                }
            },
            cancelClick () {
                this.overlayStatus = false
            },
            // 操作明细 按钮事件
            operatingRecord () {
                console.log('操作记录按钮事件')
                this.$router.push('/business/my/operation-log')
            },
            // success alert组件内 完成按钮事件
            completeFun () {
                console.log('点击 完成')
                this.alertStatus = false
                this.initData()
            },
            changeData () {
                // let ids = ''
                let idsArr = []
                let days = ''
                let dayArr = []
                let money = 0
                idsArr = this.tableList.map(item => item.settleNo)
                this.checkIds = idsArr.join(';')
                // ids = idsArr.join(';')
                dayArr = this.tableList.map(item => item.name)
                days = dayArr.join('、')

                this.allDay = days
                this.tableList.forEach(item => {
                    money += parseFloat(item.amount)
                })
                this.allMoney = money.toFixed(2)
            },
            onApprovals (d) {
                this.$router.push({
                    path: '/business/my/approval',
                    query: { 
                        isWait: this.isWait,
                        batch: d.batch,
                        merchantId: d.settleNo
                    }
                })
            }
        },
        watch: {
            activated (val) {
                if (val == 1) {
                    this.isActive = true
                } else {
                    this.isActive = false
                }
            }
            
        }
    }
</script>

<style lang="scss" scoped>
.commission-container {
    width: 100%;
    min-height: 100vh;

    .header-box {
        width: 100%;
        height: 1.2rem;
        display: flex;
        flex-direction: row;
        background-color: #ffffff;

        .list-box {
            flex: 1;
            display: flex;
            flex-direction: row;
            align-items: center;

            .item-info-box {
                flex: 1;
                text-align: center;

                .amount-style {
                    font-size: 0.15rem;
                    font-weight: 500;
                    color: #2e2d2d;
                }

                .name-style {
                    font-size: 0.13rem;
                    font-weight: 400;
                    color: #bbbbbb;
                    margin-top: 0.1rem;
                }
            }

            .split-box {
                width: 0.01rem;
                height: 0.3rem;
                background-color: #eef1f4;
            }
        }
    }

    .tabbar-box {
        // position: fixed;
        // top: 0;
        width: 100%;
        height: 0.5rem;
        background-color: #f5f8fc;
        display: flex;
        justify-content: space-around;
        // z-index: 9999;

        .tab-left-button {
            flex: 1;
            margin-right: 0.38rem;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }

        .tab-right-button {
            flex: 1;
            margin-left: 0.38rem;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .tab-title-box {
            width: 0.71rem;
            font-size: 0.15rem;
            line-height: 0.5rem;
            font-weight: 300;
            color: #000000;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-split {
            width: 0.25rem;
            height: 0.03rem;
            background-color: #ffffff;
        }

        .activeted-style {
            color: #f0250f;
            font-weight: 400;

            .button-split {
                background-color: #f0250f;
            }
        }
    }

    .button-box {
        .button-style {
            width: 100%;
            height: 100%;
            border: none;
            // border-radius: 0.23rem;
            font-size: 0.16rem;
            // line-height: 0.46rem;
            font-weight: 400;
            text-align: center;
            color: #ffffff;
            // background: linear-gradient(270deg,rgba(222,49,33,1) 0%,rgba(236,86,42,1) 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;

            .button-title-1 {
                // margin-top: 0.16rem;
            }

            .button-title-2 {
                font-size: 0.12rem;
                font-weight: 400;
            }
        }

        .operating-record-button {
            position: fixed;
            bottom: 0.95rem;
            right: 0.12rem;
            width: 1.32rem;
            height: 0.48rem;
            border: none;
            font-size: 0.18rem;
            font-weight: 500;
            color: #ffffff;
            background: linear-gradient(
                29deg,
                rgba(98, 169, 255, 1) 0%,
                rgba(76, 148, 234, 1) 100%
            );
            border-radius: 0.24rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    }

    .table-cell-box {
        margin-bottom: 0.83rem;

        .warning-title {
            padding: 0.12rem;
            font-size: 0.13rem;
            line-height: 0.18rem;
            color: #f0250f;
        }
    }

    .overlay-text-style {
        font-size: 0.15rem;
        font-weight: 400;
        color: #2e2d2d;
        line-height: 0.22rem;
        padding: 0 0.31rem 0.28rem 0.31rem;
        text-align: justify;

        .amount-style {
            color: #f0250f;
        }
    }

    .success-content {
        width: 100%;
        height: auto;
        font-size: 0.15rem;
        line-height: 0.22rem;
        font-weight: 400;
        color: #848484;
        text-align: center;
        margin-top: 0.24rem;

        .content-span {
            color: #2e2d2d;
        }

        .text-style {
            color: #f0250f;
        }
    }
  
}
.no-data {
    margin-top:.5rem;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #f5f8fc;
    .no-data-icon {
        width: 1.45rem;
        height: 1.45rem;
        background-color: #e4e4e4;
        border-radius: 50%;
        background: url('../../../../assets/img/empty.png') no-repeat;
        background-position: center center;
        background-size: 100% 100%;
    }
    .no-data-text {
        color: #2e2d2d;
        font-size: 0.15rem;
        font-weight: 500;
        text-align: center;
        margin-top: 0.28rem;
    }
}
.grey{
    background-color: #DDE0E3 !important;
}
/deep/ .van-icon-arrow{
    left: .06rem;
}
</style>
