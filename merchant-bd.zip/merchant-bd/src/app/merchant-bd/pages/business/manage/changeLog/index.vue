<template>
    <div class="record-performance-container">
        <div v-if="dataStatus" class="have-data">
            <div class="table-title-box">
                <table-cell
                    :titles="employeeTitles"
                    :isJump="false"
                    :isBold="true"
                    :isGayBGColor="false"
                    :hideArrow="true"
                />
            </div>
        
            <div id="scrollBox" class="scroll-box" :class="'scroll-height'">
                <pull-down-refresh
                    id="pullDownBox"
                    :threshold="120"
                    wrapper="comments-scroll"
                    @scroll="fetchMore"
                >
                    <table-cell
                        v-for="(item, index) in tableList"
                        :key="index"
                        :titles="item"
                        :titleKeys="listKeys"
                        :isJump="false"
                        :isBold="false"
                        :isGayBGColor="false"
                        :lastIsRight="true"
                        :hideArrow="true"
                    />
                </pull-down-refresh>
            </div>
        </div>

        <!-- 如果没有数据 就显示没有数据 的图标 -->
        <empty v-else></empty>
    </div>
</template>

<script>
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    // 引入 table-cell 组件
    import tableCell from '@/merchant-bd/components/tableCell'
    import * as manage from '@/merchant-bd/api/manage'
    import empty from '@/merchant-bd/components/empty'

    export default {
        name: 'changeLog',
        components: {
            pullDownRefresh,
            tableCell,
            empty
        },
        props: {},
        data () {
            const { merchantId } = this.$route.query
            return {
                employeeTitles: {
                    name: '变更前员工',
                    number: '变更后员工',
                    amount: '变更时间'
                },
                paramsList: {
                    currentPage: 1,
                    pageSize: 20,
                    merchantId
                },
                fetch: false,
                hasMore: true,
                tableList: [],
                listKeys: [
                    'from',
                    'to',
                    'createTime'
                ],
                onload: true,
                // 是否有数据
                dataStatus: true
            }
        },
        mounted () {
            this.getBDStaffChangeRecord()
        },
        methods: {
            fetchMore () {
                if (!this.fetch && this.hasMore) {
                    this.getBDStaffChangeRecord()
                }
            },
            getBDStaffChangeRecord () {
                this.fetch = true
                manage.getBDStaffChangeRecord(this.paramsList, d => {
                    this.fetch = false
                    this.tableList.push(...d.data)
                    this.paramsList.currentPage++
                    console.log(this.tableList)
                    if (d.data.length < 20) {
                        this.hasMore = false
                    }
                    setTimeout(() => {
                        if (this.tableList.length) {
                            this.dataStatus = true
                        } else {
                            this.dataStatus = false
                        }
                    }, 500)
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
.record-performance-container {
    // position: absolute;
    width: 100%;
    // height: 100vh;
    // display: flex;
    // flex-direction: column;

    /deep/ .van-dropdown-menu {
		background-color: #F5F8FC;
	}
    
    .have-data {
        .table-title-box {
            position: fixed;
            top: 0rem;
            width: 100%;
            z-index: 9999;
        }

        .scroll-box {
            // padding-top: 1rem;
        }

        .scroll-height {
            padding-top: 0.5rem;
        }
    }
    
    .no-data {
        position: fixed;
        top: 0;
        width: 100%;
        height: 100vh;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background-color: #F5F8FC;

        .no-data-icon {
            width: 1.45rem;
            height: 1.45rem;
            background-color: #E4E4E4;
            border-radius: 50%;
            background: url('../../../../assets/img/no_log_icon.png') no-repeat;
            background-position: center center;
            background-size: 100% 100%;
        }

        .no-data-text {
            color: #2E2D2D;
            font-size: 0.15rem;
            font-weight: 500;
            text-align: center;
            margin-top: 0.28rem;
        }
    }
}
</style>
