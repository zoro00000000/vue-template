<template>
    <div class="content" v-if="list.length>0">
        <div class="item" v-for="(item,index) in list" :key="index+'list'">
            <div class="head">
                <div class="room-name">{{item.merchantName}}</div>
                <div class="name-box">
                    <div class="name">
                        <span>{{item.staffName}}</span>
                        <img src="@/merchant-bd/assets/img/manage/manage_edit.png" alt="" @click="edit(item)"/>
                    </div>
                    <div class="change" @click="onChange(item)">
                        <span>变更记录</span>
                        <van-icon class="arrow" name="arrow" font-size="0.15rem" />
                    </div>
                </div>     
            </div>
            <div class="foot">
                <div class="foot-item left">
                    <div class="title">政策版本号</div>
                    <div class="mes">{{item.vension}}</div>
                </div>
                <div class="foot-item center">
                    <div class="title">商户状态</div>
                    <div class="mes">{{item.statusName}}</div>
                </div>
                <div class="foot-item right">
                    <div class="title">创建时间</div>
                    <div class="mes">{{item.createTime}}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            list: {
                type: Array,
                default () {
                    return []
                }
            }
        },
        data () {
            return {
        
            }
        },
        methods: {
            edit (item) {
                this.$emit('edit', item)
            },
            onChange (item) {
                this.$emit('changeList', item)
            }
        }
    }
</script>

<style lang = "scss" scoped>
    .content{
        width: 100%;
        overflow: hidden;
        .item{
            height:1.46rem;
            background:#fff;
            border-radius:.04rem;
            margin-bottom: .12rem;
            .head{
                display: flex;
                align-items: center;
                justify-content: space-between;
                height: .5rem;
                border-bottom:.01rem solid #EEF1F4;
                padding: 0 .05rem 0 .12rem;
                .room-name{
                    width: 1.5rem;
                    font-size: .15rem;
                    font-weight: 500;
                    overflow: hidden;
                    text-overflow:ellipsis;
                    white-space: nowrap;
                }
                .name-box{
                    font-size: .15rem;
                    font-weight: 400;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    .name{
                        display: flex;
                        align-items: center;
                        img{
                            width: .16rem;
                            height: .15rem;
                            margin-left: .06rem;
                        }
                    }
                    .change{
                        display: flex;
                        align-items: center;
                        margin-left: .17rem;
                        .arrow{
                            margin-left: .06rem;
                        }
                    }
                }
            }
            .foot{
                display: flex;
                height: .95rem;
                padding:0.26rem .12rem 0 .12rem;
                .foot-item{
                    width: 33.3%;
                    overflow: hidden;
                    .title{
                        color:#848484;
                        font-size: .12rem;
                        margin-bottom: .08rem;
                    }
                    .mes{
                        color:#2E2D2D;
                        font-size: .15rem;
                        font-weight: 400;
                    }
                }
                .left{
                    text-align: left
                }
                .center{
                    text-align: center;
                }
                .right{
                    text-align: right;
                }
            }
        }
    }

</style>
