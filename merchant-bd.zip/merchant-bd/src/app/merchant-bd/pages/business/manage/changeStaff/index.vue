<template>
    <div class="change-staff-container">
        <div class="warning-header-box">
            <div class="icon-class">
                <van-icon name="warning-o" color="red" />
            </div>
            <div class="warning-text">
                {{merchantName}}当前维护员工为 <span class="personal-style">{{staffName}}</span><br>
                请选择变更后的员工，不可以选择同一个人
            </div>
        </div>

        <div class="search-box">
            <van-search v-model="searchVal"
                :shape="'round'"
                :clearable="true"
                :background="'#F5F8FC'"
                class="search-style"
                @input="onSearch"
                left-icon="https://m.360buyimg.com/yocial/jfs/t1/98680/12/17063/1115/5e834ce2Eeecf39de/8c0503c4bfcdd92c.png"
            />
        </div>

        <div id="scrollBox" class="scroll-box">
            <pull-down-refresh
                id="pullDownBox"
                :threshold="120"
                wrapper="comments-scroll"
                @scroll="fetchMore"
            >
                <!-- <table-cell
                    v-for="(item, index) in tableList"
                    :key="index"
                    :titles="item"
                    :isJump="true"
                    :isBold="false"
                    :isGayBGColor="false"
                /> -->
                <van-radio-group v-model="radio">
                    <div class="radio-cell-box"
                        v-for="(item, index) in radioList"
                        :key="index"
                        @click="radioChange(item)"
                    >
                        <van-radio 
                            class="radio-style" 
                            slot="right-icon"
                            :name="item.key"
                            :disabled="item.freeze ==1 ||item.staffId ==staffId"
                        >
                        <template #icon="props">
                            <img
                                class="img-icon"
                                :src="item.freeze ==1 ||item.staffId ==staffId?freezeIcon: (props.checked ? activeIcon : inactiveIcon)"
                            >
                        </template>
                            <div class="radio-text">
                                <div>{{item.rename}}</div>
                                <div :class="item.blocked ? 'blocked-style' : ''">{{item.freeze ? '冻结' : '正常'}}</div>
                            </div>
                        </van-radio>
                    </div>
                </van-radio-group>
            </pull-down-refresh>
        </div>

        <div class="button-box">
            <tabbar-btn :custom="true">
                <div clstag="jr|keycount|dl_wdqy_shgl|tj" class="button-style" @click="confirm">提交</div>
            </tabbar-btn>
        </div>

        <alert-success v-if="alertStatus" 
            :successTitle="'变更成功'"
            :complete="completeFun"
        >
            <div class="success-content">
                您已将{{merchantName}}维护员工由 <br>
                <span class="content-span">{{staffName}}</span>
                成功变更为
                <span class="content-span">{{paramSubmit.newName}}</span>
            </div>
        </alert-success>
        <!-- 遮罩蒙层 -->
        <alert-overlay 
            :show="diglog"
            :alertType="2"
            :headerTitle="''"
            :contentText="contentText"
            :confirmEvent="confirmClick"
            :cancelEvent="cancelClick"
            :showSolt="false"
            :center="true"
            :tagStringConfirm="'jr|keycount|dl_wdqy_shgl_tc|qr'"
            :tagStringCancel="'jr|keycount|dl_wdqy_shgl_tc|qs'"
        />
    </div>
</template>

<script>
    // 引入下拉加载组件
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    // 引入 tabbar-btn 组件
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'
    import * as manage from '@/merchant-bd/api/manage'
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    // 引入成功浮层
    import alertSuccess from '../../performance/components/alertSuccess'

    export default {
        name: 'changeStaff',
        components: {
            pullDownRefresh,
            alertSuccess,
            tabbarBtn,
            alertOverlay
        },
        data () {
            const { staffId } = this.$route.query
            const { staffName } = this.$route.query
            const { merchantId } = this.$route.query
            const { merchantName } = this.$route.query
            return {
                paramsList: {
                    currentPage: 1,
                    pageSize: 15,
                    name: ''
                },
                paramSubmit: {
                    merchantId,
                    from: staffId,
                    to: '',
                    oldName: staffName,
                    newName: ''
                },
                staffId,
                merchantName,
                staffName,
                fetch: false,
                hasMore: true,
                searchValue: '',
                loading: false,
                searchVal: '',
                radio: -1,
                radioList: [],
                alertStatus: false,
                diglog: false,
                contentText: '', // 弹框内容
                activeIcon: 'https://m.360buyimg.com/yocial/jfs/t1/100213/10/17031/1977/5e834bf4E3742aef6/7932fb3aed3cb461.png',
                inactiveIcon: 'https://m.360buyimg.com/yocial/jfs/t1/108497/5/10845/1295/5e834f15Ebca2f85f/0eb69fb0fe4d30c0.png',
                freezeIcon: 'https://m.360buyimg.com/yocial/jfs/t1/94447/36/16579/992/5e844e9eEc64b1a0b/24e9239083253704.png'
            }
        },
        mounted () {
            this.queryBDStaffInfo()
        },
        methods: {
            fetchMore () {
                if (!this.fetch && this.hasMore) {
                    this.queryBDStaffInfo()
                }
                this.loading = false
            },
            // 单选框 change 事件
            radioChange (val) {
                console.log(val)
                if (val.freeze == 1 || val.staffId == this.staffId) {
                    console.log('禁止选择', val.name)
                } else {
                    this.paramSubmit.to = val.staffId
                    this.paramSubmit.newName = val.name
                    this.radio = val.key
                }
            },
            // 按钮提交事件
            confirm () {
                if (this.radio == -1) return
                if (!this.paramSubmit.to || !this.paramSubmit.newName) {
                    this.paramSubmit.to = this.radioList[0] ? this.radioList[0].staffId : ''
                    this.paramSubmit.newName = this.radioList[0] ? this.radioList[0].name : ''
                }
                this.paramSubmit.to = this.paramSubmit.to.toString()
                this.contentText = `员工将变更为：${this.paramSubmit.newName}`
                this.diglog = true
            },
            // 组件内 完成按钮事件
            completeFun () {
                this.alertStatus = false
                this.$router.push({
                    path: '/business/manage'
                })
            },
            onSearch () {
                this.paramsList.name = this.searchVal
                this.paramsList.currentPage = 1
                if (!this.paramsList.name) {
                    this.radioList = []
                }
                this.queryBDStaffInfo()
            },
            queryBDStaffInfo () {
                this.fetch = true
                manage.queryBDStaffInfo(this.paramsList, d => {
                    this.fetch = false
                    if (this.paramsList.name) {
                        this.radioList = d.data
                    } else {
                        this.radioList.push(...d.data)
                        this.paramsList.currentPage++
                        if (d.data.length < this.paramsList.pageSize) {
                            this.hasMore = false
                        }
                    }
                })
                console.log('员工变更列表1111', this.radioList, this.radioList.length)
            },
            updateBDMerchantAgent () {
                manage.updateBDMerchantAgent(this.paramSubmit, d => {
                    if (d.result.code == '0000') {
                        this.alertStatus = true
                    }
                })
            },
            confirmClick () {
                this.updateBDMerchantAgent()
                this.diglog = false
            },
            cancelClick () {
                this.diglog = false
            }
        }
    }
</script>

<style lang="scss" scoped>
.change-staff-container {
    width: 100%;
    height: auto;
    background-color: #F5F8FC;

    .warning-header-box {
        position: fixed;
        top: 0;
        width: 100%;
        height: 0.5rem;
        background-color: #F4E2E4;
        padding: 0 0.19rem;
        box-sizing: border-box;
        display: flex;
        flex-direction: row;
        align-items: center;
        z-index: 99;
        .icon-class {
            font-size: 0.15rem;
        }

        .warning-text {
            font-size: 0.12rem;
            font-weight: 400;
            color: #FF1900;
            margin-left: 0.1rem;
            .personal-style {
                font-weight: 600;
            }
        }
    }

    .search-box {
        position: fixed;
        top: 0.5rem;
        width: 100%;
        background-color: #F5F8FC;
        z-index: 99;
        /deep/ .van-search__content--round {
            background-color: #FFFFFF;
        }
    }

    .scroll-box {
        margin-top: 1rem;
        .radio-cell-box {
            width: 100%;
            height: 0.51rem;
            padding: 0 0.12rem;
            background-color: #FFFFFF;
            border-bottom: 0.01rem solid #EEF1F4;
            box-sizing: border-box;

            .radio-style {
                width: 100%;
                height: 0.5rem;
                font-size: 0.15rem;
                font-weight: 400;
                color: #2E2D2D;

                /deep/ .van-radio__label {
                    width: 100%;
                }

                .radio-text {
                    display: flex;
                    justify-content: space-between;

                    .blocked-style {
                        color: #F0250F;
                    }
                }
                .img-icon{
                    width: .18rem;
                    height: .18rem;
                }
            }
        }
    }

    .button-box {
        .button-style {
            width: 100%;
            height: 100%;
            border: none;
            // border-radius: 0.23rem;
            font-size: 0.16rem;
            line-height: 0.46rem;
            font-weight: 400;
            text-align: center;
            color: #FFFFFF;
            // background: linear-gradient(270deg,rgba(222,49,33,1) 0%,rgba(236,86,42,1) 100%);
        }
    }

    .success-content {
        width: 100%;
        height: auto;
        font-size: 0.15rem;
        line-height: 0.23rem;
        font-weight: 400;
        color: #848484;
        text-align: center;

        .content-span {
            color: #2E2D2D;
        }
    }
}
</style>
