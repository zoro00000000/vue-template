<template>
    <div class="wrap">
        <div class="search-box">
            <div class="search">
                <div class="left">
                    <van-icon name="search" class="icon_search" size=".22rem" color="#979797" />
                    <input clstag="jr|keycount|dl_wdqy_shgl|ss" type="text" placeholder="请输入员工姓名" v-model="searchValue" />
                    <van-icon v-if="searchValue" class="cancel" @click="onCancel" name="cross" />
                </div>
                <!-- <div class="cancel" v-if="searchValue" @click="onCancel">取消</div> -->
            </div>
        </div>
        <van-list
            v-model="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
            class="lists"
            v-if="list"
        >
            <list-item clstag="jr|keycount|dl_wdqy_shgl|ggyg" :list.sync="list" @edit="edit" @changeList="changeList"></list-item>
        </van-list>
        <empty v-else></empty>
    </div>
</template>

<script>
    // 引入防抖组件
    import { debounce } from '@/merchant-bd/utils/debounce/index'
    // import { timestampToYear } from '@/utils/tools'
    import * as manage from '@/merchant-bd/api/manage'
    // import { apiUrl, fetch } from '@/server/getData'
    import empty from '@/merchant-bd/components/empty'
    import ListItem from './component/ListItem'

    export default {
        data () {
            return {
                paramsObj: {
                    currentPage: 1,
                    pageSize: 10,
                    name: ''
                },
                fetch: false,
                hasMore: true,
                searchValue: '',
                finished: false,
                loading: false,
                list: []
            }
        },
        components: {
            ListItem,
            empty
        },
        methods: {
            onSearch () {
                console.log('搜索', this.searchValue)
            },
            onCancel () {
                this.searchValue = ''
            },
            onLoad () {
                if (!this.fetch && this.hasMore) {
                    this.queryBDOrganMerchant()
                }
                console.log('家在更多...')
                this.loading = false
            },
            queryBDOrganMerchant () {
                this.fetch = true
                manage.queryBDOrganMerchant(this.paramsObj, d => {
                    console.log('企业代理列表==', d)
                    console.log('列表11', this.list)
                    this.fetch = false
                    if (this.paramsObj.name) {
                        this.list = d.data
                    } else {
                        this.list.push(...d.data)
                        console.log('列表', this.list)
                        this.paramsObj.currentPage++
                        if (d.data.length < 10) {
                            this.hasMore = false
                        }
                    }
                })
            },
            edit (d) {
                this.$router.push({
                    path: '/business/manage/change-staff',
                    query: {
                        staffId: d.staffId,
                        merchantId: d.merchantId,
                        merchantName: d.merchantName,
                        staffName: d.staffName
                    }
                })            
            },
            changeList (d) {
                this.$router.push({
                    path: '/business/manage/change-log',
                    query: {
                        merchantId: d.merchantId
                    }
                }) 
            }
        },
        watch: {
            // searchValue () {
            //     this.list = []
            //     this.paramsObj.currentPage = 1
            //     this.paramsObj.name = this.searchValue
            //     this.queryBDOrganMerchant()
            // },
            searchValue: debounce(function () {
                this.list = []
                this.paramsObj.currentPage = 1
                this.paramsObj.name = this.searchValue
                this.queryBDOrganMerchant()
            }, 400, false)
        }
    }
</script>

<style lang = "scss" scoped>
    .wrap{
        padding:.12rem;
        background: #F5F8FC;
        .search-box{
            width: 100%;
            overflow: hidden;
            position: fixed;
            top:0;
            left: 0;
            z-index: 9;
        }
        .search{
            padding: .12rem;
            height: .35rem;
            display: flex;
            align-items: center;
            overflow: hidden;
            background: #F5F8FC;
            .left{
                flex:1;
                height: .33rem;
                display: flex;
                align-items: center;
                border-radius:.18rem;
                border:.01rem solid rgba(230,230,230,1);
                align-items: center;
                background: #fff;
                overflow: hidden;
                .icon_search{
                    width: .2rem;
                    height: .2rem;
                    margin:0 .12rem;
                }
                input{
                    width: 100%;
                    height: .33rem;
                    line-height: .33rem;
                    font-size: .15rem;
                    outline:none;  
                    border:0;    
                    margin-top: -0.01rem;                    
                }
                input:focus{
                    border: none;
                }
            }
            .cancel{
                font-size: .15rem;
                margin: 0 .12rem;
            }
        }
        .lists{
            margin-top: .5rem;
        }
    }
</style>
