<!--
 * @Date: 2020-03-23 17:49:50
 * @LastEditors: Zhaoyongzhen
 * @LastEditTime: 2020-03-23 18:08:41
 -->
<template>
    <div></div>
</template>

<script>
    export default {
        data () {
            return {
                aaa: '1111',
                bbb: '2222'
            }
        },
        methods: {
            fundemo () {
                console.log('1111')
            }
        }
    }
</script>

<style></style>
