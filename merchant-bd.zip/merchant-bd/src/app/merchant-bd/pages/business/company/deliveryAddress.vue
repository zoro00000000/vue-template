<template>
    <div>
        <section class="comp-top">
            <div class="top-logo">
                <img :src="companyInfo.logUrl"/>
            </div>
            <div class="top-cont">
                <h4>{{ companyInfo.organName }}</h4>
                <p class="change" @click="change" clstag="jr|keycount|dl_wdqy_qyxx|qhqy">切换企业</p>
            </div>
        </section>
        <section>
            <van-cell-group>
                <van-cell title="账户姓名" :value="companyInfo.principal" />
                <van-cell title="手机号" :value="companyInfo.principalPhone" />
                <van-cell title="京东Pin" :value="companyInfo.pin" />
            </van-cell-group>
        </section>
        <section style="margin-top:.12rem">
            <van-cell-group>
                <van-cell title="合同有效期" :value="companyInfo.invalidDate | formatTime" />
                <van-cell title="专属客服邮箱" title-class="title-email" :value="companyInfo.mail" />
                <van-cell title="专票邮寄地址" :value="companyInfo.address" />
            </van-cell-group>
        </section>
        <section style="margin-top:.12rem">
            <van-cell-group>
                <van-cell title="代理区域" clstag="jr|keycount|dl_wdqy_dlqy|dlqy" is-link :to="{ name: 'agencyArea' }" />
                <van-cell @click="goPath" title="代理企业对公户" is-link clstag="jr|keycount|dl_wdqy_dlqy|dlqydgh" />
                <van-cell title="纳税人类型" :is-link="false">
                    <template #right-icon>
                        {{taxpayer}}
                        <van-icon @click="clickWarning" name="warning-o" style="line-height: inherit;" />
                    </template>
                </van-cell>
            </van-cell-group>
        </section>

        <!-- 弹窗选择组件 -->
        <van-popup v-model="showPicker" position="bottom">
            <van-picker
                show-toolbar
                title="请选择以下企业"
                :columns="columns"
                @cancel="onCancel"
                @confirm="onConfirm"
                clstag="jr|keycount|dl_qyyj|dlqydgh"
            />
        </van-popup>

        <!-- warning 警告弹窗 -->
        <alert-overlay 
            :show="showWarning"
            :alertType="3"
            :headerTitle="'注意'"
            :contentText="questionText"
            :showSolt="false"
            :confirmEvent="confirmClick"
        >
        </alert-overlay>
    </div>
</template>
<script>
    import { Toast } from 'vant'
    import dayjs from 'dayjs'
    import { phoneHide } from '@/merchant-bd/utils/phoneHide'
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    import { imgHost } from '@/merchant-bd/utils/constV'
    // import { list } from './data'

    export default {
        components: {
            alertOverlay
        },
        data () {
            return {
                showPicker: false,
                organId: JSON.parse(localStorage.getItem('organId')) || '',
                companyInfo: {
                    // principal: '刘德华',
                    // organName:'各种壹基金',
                    // bank:'中国银行',
                    // bankBranch:'丰台支行',
                    // accountNo:67777777777777777
                }, // 返回信息
                columns: [], // 企业列表
                pin: 'pin123',
                taxpayer: '小规模纳税人',
                payTaxes: 'SMALL',
                showWarning: false,
                questionText: '小规模纳税人：指年销售额在规定标准以下（如服务行业不超500万），并且会计核算不健全，不能按规定报送有关税务资料的增值税纳税人，税率基本是3%。'
            }
        },
        created () {
            this.initData()
        },
        methods: {
            initData () {
                fetch.post(
                    {
                        url: apiUrl.queryBDOrganInfoByOrganId,
                        data: {
                            organId: this.organId
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            this.companyInfo = res.data
                            this.companyInfo.logUrl = imgHost + res.data.logUrl
                            this.companyInfo.principalPhone = phoneHide(res.data.principalPhone)
                            this.payTaxes = res.data.payTaxes || 'NORMAL'
                            this.taxpayer = res.data.payTaxes === 'SMALL' ? '小规模纳税人' : '一般纳税人'

                            this.questionText = this.payTaxes === 'SMALL' 
                                ? '小规模纳税人：指年销售额在规定标准以下（如服务行业不超500万），并且会计核算不健全，不能按规定报送有关税务资料的增值税纳税人，税率基本是3%。' 
                                : '一般纳税人：指年销售额超过规定标准（如服务行业超过500万），并且会计核算健全，能按规定报送有关税务资料的增值税纳税人，税率6%、9%、13%不等。'
                        } else {
                            Toast.fail(res.result.info)
                        }

                        console.log(this.payTaxes)
                        console.log(this.questionText)
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            getList () {
                fetch.post(
                    {
                        url: apiUrl.queryBDOrganInfoByPin,
                        data: {
            
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            const list = res.data
                            const cmList = list.map(item => {
                                const cell = item
                                cell.text = item.organName
                                return cell
                            })
                            this.columns = cmList
                            this.showPicker = true
                        } else {
                            Toast.fail(res.result.info)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            change () {
                this.getList()
            },
            onCancel () {
                this.showPicker = false
            },
            onConfirm (value, index) {
                console.log(value, index)
                this.companyInfo = this.columns[index]
                this.organId = value.organId
                //   this.initData()
                localStorage.setItem('staffId', JSON.stringify(value.staffId))
                localStorage.setItem('organId', JSON.stringify(value.organId))
                // 切换数据
                this.initData()
    
                this.showPicker = false
            },
            goPath () {
                this.$router.push({
                    name: 'agencyShop',
                    query: {
                        // organName: encodeURIComponent(this.companyInfo.organName),
                        accountName: encodeURIComponent(this.companyInfo.accountName),
                        bank: encodeURIComponent(this.companyInfo.bank),
                        bankBranch: encodeURIComponent(this.companyInfo.bankBranch),
                        accountNo: this.companyInfo.accountNo
                    }
                })
            },
            // 警告按钮点击
            clickWarning () {
                this.showWarning = true
            },
            // 弹窗确定事件
            confirmClick () {
                this.showWarning = false
            }
        },
        filters: {
            formatTime (val) {
                return dayjs(val).format('YYYY/MM/DD')
            }
        }
    }
</script>
<style lang="scss" scoped>
@import './style.scss';
.title-email {
    width: 30vw;
    flex: none;
}
</style>
