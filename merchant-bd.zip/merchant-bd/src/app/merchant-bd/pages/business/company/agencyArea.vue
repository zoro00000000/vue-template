<template>
    <div>
        <van-index-bar>
            <div v-for="(item, index) in areas" :key="index">
                <van-index-anchor :index="index">{{ item.lv }}</van-index-anchor>
                <van-cell
                    v-for="(cell, index) in item.data"
                    :key="index"
                    :title="cell.cityName"
                />
            </div>
        </van-index-bar>
    </div>
</template>
<script>
    import { Toast } from 'vant'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'

    export default {
        data () {
            return {
                organId: JSON.parse(localStorage.getItem('organId')) || '',
                areas: []
            }
        },
        created () {
            this.initData()
        },
        methods: {
            initData () {
                // this.areas = areas
                fetch.post(
                    {
                        url: apiUrl.queryBDOrganRegion,
                        data: {
                            organId: this.organId
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            this.areas = res.data
                        } else {
                            Toast.fail(res.result.info)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            }
        }
    }
</script>
<style lang="scss" scoped>
@import './style.scss';
</style>
