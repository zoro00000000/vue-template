/*
 * @Date: 2020-03-11 14:28:20
 * @LastEditors: Zhaoyongzhen
 * @LastEditTime: 2020-03-13 10:58:51
 */
export const list = [
    {
        id: 0,
        organId: 0,
        organName: 'str',
        principal: 'str',
        principalPhone: 'str',
        invalidDate: 1583731246845,
        accountName: 'str',
        accountNo: 'str',
        bank: 'str',
        bankBranch: 'str',
        status: 0,
        type: 0,
        settleType: 0,
        referral: 'str',
        pin: 'str',
        province: 'str',
        city: 'str',
        address: 'str',
        mail: 'str',
        logUrl: 'str',
        ex: 'str',
        uuid: 'str',
        createUser: 'str',
        createTime: 1583731246845,
        updateTime: 1583731246845,
        bizVersion: 'str',
        version: 0,
        freeze: 0
    },
    {
        id: 0,
        organId: 0,
        organName: 'str',
        principal: 'str',
        principalPhone: 'str',
        invalidDate: 1583731246845,
        accountName: 'str',
        accountNo: 'str',
        bank: 'str',
        bankBranch: 'str',
        status: 0,
        type: 0,
        settleType: 0,
        referral: 'str',
        pin: 'str',
        province: 'str',
        city: 'str',
        address: 'str',
        mail: 'str',
        logUrl: 'str',
        ex: 'str',
        uuid: 'str',
        createUser: 'str',
        createTime: 1583731246845,
        updateTime: 1583731246845,
        bizVersion: 'str',
        version: 0,
        freeze: 0
    }
]

export const areas = [
    {
        lv: 'a级',
        data: [
            {
                merId: 'str',
                merName: '北京',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '天津',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            }
        ]
    },
    {
        lv: 'b级',
        data: [
            {
                merId: 'str',
                merName: '保定',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '廊坊',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '济南',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            }
        ]
    },
    {
        lv: 'c级',
        data: [
            {
                merId: 'str',
                merName: '香河县',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '泰安',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '纽约',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '好莱坞',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            }
        ]
    },
    {
        lv: 'd级',
        data: [
            {
                merId: 'str',
                merName: '藩镇',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '长安',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '洛阳',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '直隶',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            }
        ]
    },
    {
        lv: 'e级',
        data: [
            {
                merId: 'str',
                merName: '罗马',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '巴比伦',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '孟买',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            },
            {
                merId: 'str',
                merName: '班加罗尔',
                bizVersion: 'str',
                addCount: 0,
                tradeAmount: 'BigDecimal'
            }
        ]
    }
]
export const workers = [
    {
        id: 0,
        name: 'str',
        organId: 0,
        phone: 'str',
        pin: 'str',
        mail: 'str',
        status: 0,
        address: 'str',
        parentId: 0,
        entryTime: 1583728873076,
        leaveTime: 1583728873076,
        createTime: 1583728873076,
        createUser: 'str',
        updateTime: 1583728873076,
        updateUser: 'str',
        version: 0,
        staffId: 0,
        imgUrl: 'str',
        freeze: 0
    },
    {
        id: 1,
        name: 'str',
        organId: 0,
        phone: 'str',
        pin: 'str',
        mail: 'str',
        status: 0,
        address: 'str',
        parentId: 0,
        entryTime: 1583728873076,
        leaveTime: 1583728873076,
        createTime: 1583728873076,
        createUser: 'str',
        updateTime: 1583728873076,
        updateUser: 'str',
        version: 0,
        staffId: 0,
        imgUrl: 'str',
        freeze: 0
    },
    {
        id: 2,
        name: 'str',
        organId: 0,
        phone: 'str',
        pin: 'str',
        mail: 'str',
        status: 0,
        address: 'str',
        parentId: 0,
        entryTime: 1583728873076,
        leaveTime: 1583728873076,
        createTime: 1583728873076,
        createUser: 'str',
        updateTime: 1583728873076,
        updateUser: 'str',
        version: 0,
        staffId: 0,
        imgUrl: 'str',
        freeze: 0
    }
]
