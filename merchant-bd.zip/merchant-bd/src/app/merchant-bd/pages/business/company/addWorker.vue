<template>
    <div class="worker">
        <h4 class="wk-title">员工姓名</h4>
        <van-cell-group>
            <van-field v-model="name" placeholder="请输入员工姓名" />
        </van-cell-group>
        <h4 class="wk-title">PIN</h4>
        <van-cell-group>
            <van-field v-model="pin" placeholder="请输入员工京东PIN" />
        </van-cell-group>
        <h4 class="wk-title">手机号</h4>
        <van-cell-group>
            <van-field v-model="tel" placeholder="请输入员工手机号" />
        </van-cell-group>
        <div class="btn-box">
            <van-button v-if="!isSubmit" class="disabled" round block>
                提交
            </van-button>
            <van-button v-else round block @click="submit">提交</van-button>
        </div>
    </div>
</template>
<script>
    import { Dialog, Toast } from 'vant'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'

    export default {
        data () {
            return {
                organId: JSON.parse(localStorage.getItem('organId')) || '',
                parentId: '123',
                isSubmit: false,
                name: '',
                pin: '',
                tel: '',
                nameNum: false,
                pinNum: false,
                telNum: false,
                goNum: ''
            }
        },
        methods: {
            submit () {
                if (
                    !/^(?:[\u4e00-\u9fa5·]{2,16})$/.test(this.name)
                    && !/(^[a-zA-Z]{1}[a-zA-Z\s]{0,20}[a-zA-Z]{1}$)/.test(this.name)
                ) {
                    Toast.fail('请输入正确的姓名')
                    return false
                }
                if (!/^(?:(?:\+|00)86)?1[3-9]\d{9}$/.test(this.tel)) {
                    Toast.fail('请输入正确的手机号')
                    return false
                }
                Dialog.confirm({
                    // title: `弹窗是否创建员工：${this.name}`
                    title: '是否确认操作？'
                })
                    .then(() => {
                        // on confirm
                        const param = {
                            organId: this.organId,
                            name: this.name,
                            phone: this.tel,
                            pin: this.pin,
                            parentId: this.organId
                        }
                        fetch.post(
                            {
                                url: apiUrl.addBDStaffInfo,
                                data: {
                                    ...param
                                }
                            },
                            res => {
                                if (res.result.code === '0000') {
                                    const hideTel = this.tel.slice(-4)
                                    const name = encodeURIComponent(this.name)
                                    this.$router.push({
                                        name: 'result',
                                        query: {
                                            tel: hideTel,
                                            name
                                        }
                                    })
                                } else {
                                    console.log(res.result.info)
                                    const err = res.result.info.slice(7, res.result.info.length - 1)
                                    Toast.fail(err)
                                }
                            },
                            err => {
                                console.log(err)
                            }
                        )
                    })
                    .catch(() => {
                        // on cancel
                    })
            }
        },
        watch: {
            name (val) {
                if (val.length == 0) {
                    this.nameNum = false
                } else {
                    this.nameNum = true
                }
                this.goNum = `${this.nameNum}${this.pinNum}${this.telNum}`
            },
            pin (val) {
                if (val.length == 0) {
                    this.pinNum = false
                } else {
                    this.pinNum = true
                }
                this.goNum = `${this.nameNum}${this.pinNum}${this.telNum}`
            },
            tel (val) {
                if (val.length == 0) {
                    this.telNum = false
                } else {
                    this.telNum = true
                }
                this.goNum = `${this.nameNum}${this.pinNum}${this.telNum}`
            },
            goNum (val) {
                console.log('this.goNum--->', val)
                if (val == 'truetruetrue') {
                    this.isSubmit = true
                } else {
                    this.isSubmit = false
                }
            }
        }
    }
</script>
<style lang="scss" scoped>
h4 {
    margin: 0;
    padding: 0;
}
.worker {
    font-size: 0.15rem;
}
.wk-title {
    height: 0.35rem;
    line-height: 0.35rem;
    color: rgba(132, 132, 132, 1);
    background: rgba(244, 244, 244, 1);
    font-weight: normal;
    padding: 0 0.12rem;
}
/deep/ .van-field {
    padding: 0 0.12rem;
    line-height: 0.5rem;
    font-size: 0.15rem;
}
.btn-box {
    margin: 0.28rem 0.12rem;
}
/deep/ .btn-box .van-button {
    height: 0.46rem;
    line-height: 0.46rem;
    font-size: 0.16rem;
    color: #fff;
    background: linear-gradient(
        270deg,
        rgba(222, 49, 33, 1) 0%,
        rgba(236, 86, 42, 1) 100%
    );
}
.btn-box .van-button.disabled {
    background: rgba(214, 219, 225, 1);
}
</style>
<style>
.van-dialog {
    border-radius: 5px !important;
}
.van-dialog__header {
    color: rgba(46, 45, 45, 1) !important;
    font-weight: normal !important;
}
</style>
