<template>
    <div class="result">
        <img src="../../../assets/img/company/icon-ok.png" alt="" />
            <p class="result-tip">创建成功</p>
            <div class="resul-info">
                您已成功创建员工账户：
                <span>{{name}}（{{hideTel}}）</span>
            <div @click="goBack" class="btn-done">完成</div>
        </div>
    </div>
</template>
<script>
    export default {
        data () {
            return {
                name: '',
                hideTel: ''
            }
        },
        created () {
            this.name = decodeURIComponent(this.$route.query.name)
            this.hideTel = this.$route.query.tel
        },
        methods: {
            goBack () {
                this.$router.push('/company/accounts')
            }
        }
    }
</script>
<style lang="scss" scoped>
.result {
    font-size: 0.15rem;
    text-align: center;
    padding-top: 1.86rem;
    & > img {
        width: 0.8rem;
        height: 0.8rem;
        display: block;
        margin: 0 auto;
    }
    .result-tip {
        line-height: 1;
        margin: 0.28rem 0;
    }
    .resul-info {
        color: rgba(132, 132, 132, 1);
        line-height: 1;
        span {
        color: #000;
        }
    }
    .btn-done {
        height: .4rem;
        line-height: .4rem;
        border-radius: .2rem;
        border: 1px solid rgba(240, 37, 15, 1);
        text-align: center;
        color:rgba(240,37,15,1);
        width: 1.2rem;
        margin:.28rem auto 0;
    }
}
</style>
