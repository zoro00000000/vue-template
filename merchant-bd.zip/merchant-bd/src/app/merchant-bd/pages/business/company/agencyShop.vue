<template>
    <div>
        <section>
            <van-cell-group>
                <van-cell title="户名" :value="accountName" />
                <van-cell title="账号" :value="accountNo" />
                <van-cell title="开户银行" :value="bank" />
                <van-cell title="开户支行" :value="bankBranch" />
            </van-cell-group>
        </section>
    </div>
</template>
<script>
    export default {
        data () {
            return {
                accountName: '',
                bank: '',
                bankBranch: '',
                accountNo: ''
            }
        },
        created () {
            this.accountName = decodeURIComponent(this.$route.query.accountName)
            this.bank = decodeURIComponent(this.$route.query.bank)
            this.bankBranch = decodeURIComponent(this.$route.query.bankBranch)
            this.accountNo = this.$route.query.accountNo
        }
    }
</script>
<style lang="scss" scoped>
@import './style.scss';
</style>
