<template>
    <div>
        <section class="comp-top" @click="goPath('deliveryAddress')" clstag="jr|keycount|dl_wdqy|qyxx">
            <div class="top-logo">
                <img :src="companyInfo.logUrl | imageLoadFilter" />
            </div>
            <div class="top-cont">
                <h4 class="short-title">{{ companyInfo.organName }}</h4>
                <p>
                    <span class="time-end">{{ companyInfo.invalidDate | formatTime }}到期</span>
                    <van-icon name="arrow" />
                </p>
            </div>
        </section>
        <section>
            <van-cell-group>
                <van-cell
                    clstag="jr|keycount|dl_wdqy_yjhf|yjhf"
                    title="佣金发放"
                    is-link
                    value="每月1号-10号确认佣金并邮寄专票"
                    to="/business/manage/commission"
                />
                <van-cell title="商户管理" is-link to="/business/manage" />
                <van-cell clstag="jr|keycount|dl_wdqy|ygzhgl" title="员工账户管理" is-link to="/company/accounts" />
            </van-cell-group>
        </section>
        <section style="margin-top:.12rem">
            <van-cell-group>
                <van-cell clstag="jr|keycount|dl_wdqy|ccwt" title="常见问题" is-link to="/business/my/questions" />
            </van-cell-group>
        </section>
        <section style="margin-top:.12rem;text-align:center">
            <van-cell-group>
                <van-cell title="退出登录" @click="loginout" />
            </van-cell-group>
        </section>
        <tabbarBtn 
            :custom="custom"
            leftTitle="企业业绩"
            rightTitle="我的企业"
            clickValue="2"
            @btnClickValue="btnClickValue"
        >
        </tabbarBtn>
        <alert-overlay :alertType=2 :show="show" :showSolt="false" :center="true" contentText="是否退出登陆" :confirmEvent="confirmEvent" :cancelEvent="cancelEvent"></alert-overlay>
        <div class="mask" v-if="showMask">
            <div class="mask-box">
                <h4>合同到期通知</h4>
                <p>合同已到期，已无法正常开展使用系统，请联系相关工作人员处理</p>
            </div>
        </div>
    </div>
</template>
<script>
    import { Toast } from 'vant'
    import dayjs from 'dayjs'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'
    import alertOverlay from '@/merchant-bd/components/alertOverlay'

    export default {
        data () {
            return {
                organId: JSON.parse(localStorage.getItem('organId')) || '',
                companyInfo: {}, // 返回信息
                custom: false,
                leftTitle: '企业业绩',
                show: false,
                showMask: false
            }
        },
        created () {
            this.initData()
        },
        methods: {
            initData () {
                fetch.post(
                    {
                        url: apiUrl.queryBDOrganInfoByOrganId,
                        data: {
                            organId: this.organId
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            this.companyInfo = res.data
                        } else {
                            console.log(res.result.info)
                            const err = res.result.info.slice(7, res.result.info.length - 1)
                            Toast.fail(err)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            goPath (name) {
                const currentTime = dayjs().valueOf()
                if (currentTime > this.companyInfo.invalidDate) {
                    this.showMask = true
                    return false
                }
                this.$router.push({
                    name
                })
            },
            btnClickValue (value) {
                // 商家时
                if (value === '1') {
                    // left
                    this.$router.push({
                        path: '/business/performance/company'
                    })
                } else if (value === '2') {
                    // right
                    this.$router.push({
                        // path: `/business/performance/personal/${this.merchantId}`
                        path: '/company/myCompany'
                    })
                }
            },
            loginout () {
                this.show = true
            },
            confirmEvent () {
                // 清除所有cookies
                localStorage.clear()
                const localUrl = encodeURIComponent(window.location.href)
                window.location.href = `//plogin.m.jd.com/cgi-bin/ml/mlogout?appid=566&returnurl=${localUrl}`
            },
            cancelEvent () {
                this.show = false
            }
        },
        filters: {
            formatTime (val) {
                return dayjs(val).format('YYYY/MM/DD')
            },
            imageLoadFilter (src) {
                if (/^(https?:)?\/\//.test(src)) {
                    return src
                } else {
                    return `//m.360buyimg.com/yocial/${src}`
                }
            }
        },
        components: {
            tabbarBtn,
            alertOverlay
        }
    }
</script>
<style lang="scss" scoped>
@import './style.scss';
</style>
