<template>
    <div class="account">
        <div class="search-box">
            <img
                class="icon-search"
                src="../../../assets/img/company/icon-search.png"
                alt=""
                @click="searchWorker"
            />
            <input
                clstag="jr|keycount|dl_wdqy_ygzhgl|ss"
                v-model="inputText"
                placeholder="请输入员工姓名/手机号进行查询"
                v-on:keyup.enter="searchWorker"
                type="text"
            />
            <van-icon v-if="inputText" class="cancel" @click="onCancel" name="cross" />
        </div>
        <pullDownRefresh @scroll="handleScroll">
            <ul class="wk-list" v-if="list.length">
                <li class="wk-item" v-for="(item, index) in list" :key="index">
                    <div class="item-top">
                        <div class="item-name">员工：{{ item.name }}</div>
                        <div @click="onFreezeemploy(item)">
                            管理<van-icon class="icon-arrow" name="arrow" />
                        </div>
                    </div>
                    <div class="wk-info">
                        <div class="info-item">
                        <p>
                            手机号
                            <img
                                v-if="item.eye"
                                @click="hideTel(index)"
                                class="icon-eye"
                                src="../../../assets/img/company/icon-eye.png"
                                alt=""
                            />
                            <img
                                v-else
                                @click="lookTel(index)"
                                class="icon-eye"
                                src="../../../assets/img/company/icon-bind.png"
                                alt=""
                            />
                        </p>
                        <span v-if="item.eye">{{ item.phone }}</span>
                        <span v-else>{{ item.hidePhone }}</span>
                        </div>
                        <div class="info-item">
                            <p>PIN编号</p>
                            <span>{{ item.pin }}</span>
                        </div>
                        <div class="info-item">
                            <p>状态</p>
                            <span v-if="item.freeze === 0">正常</span>
                            <span v-else class="red">冻结</span>
                        </div>
                    </div>
                </li>
            </ul>
            <div class="no-data" v-else>
                <div class="no-data-icon">
                    <div class="no-data-icon"></div>
                    <div class="no-data-text">
                        暂无数据
                    </div>
                </div>
            </div>
        </pullDownRefresh>
        <tabbarBtn :custom="custom">
            <div clstag="jr|keycount|dl_wdqy_ygzhgl|xzyg" class="btn-add" @click="goPath">
                <van-icon name="plus" />
                <span>新增员工</span>
            </div>
        </tabbarBtn>
    </div>
</template>
<script>
    // 引入防抖组件
    import { debounce } from '@/merchant-bd/utils/debounce/index'
    import { Toast } from 'vant'
    // import { format } from 'path'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    // import { workers } from './data'
    import pullDownRefresh from '@/merchant-bd/components/scroll/pullDownRefresh'
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'

    export default {
        data () {
            return {
                custom: true,
                inputText: '',
                list: [],
                organId: JSON.parse(localStorage.getItem('organId')) || '',
                name: '',
                phone: '',
                handlePhone: '',
                currentPage: 1,
                pageSize: 10,
                hasMore: false
            }
        },
        created () {
            this.initData()
        },
        methods: {
            initData (type) {
                const param = {
                    organId: this.organId,
                    currentPage: this.currentPage,
                    pageSize: this.pageSize
                }
                if (type === 0) {
                    param.name = this.inputText
                } else if (type === 1) {
                    param.phone = this.inputText
                }
                fetch.post(
                    {
                        url: apiUrl.queryBDStaffInfo,
                        data: {
                            ...param
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            const workers = res.data
                            this.hasMore = false
                            const changeList = workers.map(item => {
                                const cell = item
                                cell.eye = false
                                const phoneStr = cell.phone
                                cell.hidePhone = `${phoneStr.slice(0, 3)}****${phoneStr.slice(-4)}`
                                return cell
                            })
                            this.list = this.list.concat(changeList)
                            if (workers.length < this.pageSize) {
                                // Toast('到底了')
                                this.hasMore = true
                                return false
                            } else {
                                this.currentPage++
                            }
                        } else {
                            console.log(res.result.info)
                            // const err = res.result.info.slice(7, res.result.info.length - 1)
                            Toast.fail(res.result.info)
                        }
                    },
                    err => {
                        console.log(err)
                    }
                )
            },
            hideTel (index) {
                this.list[index].eye = false
            },
            lookTel (index) {
                this.list = this.list.map(item => {
                    item.eye = false
                    return item
                })
                this.list[index].eye = true
            },
            searchWorker () {
                if (/^\d{1,}$/.test(this.inputText)) {
                    // 手机号查询
                    this.currentPage = 1
                    this.list.splice(0)
                    this.initData(1)
                } else {
                    // 姓名
                    this.currentPage = 1
                    this.list.splice(0)
                    this.initData(0)
                }
            },
            handleScroll () {
                console.log('scroll--->')
                if (!this.hasMore) {
                    this.hasMore = true
                    this.scrollLoadData()
                }
            },
            scrollLoadData () {
                this.initData()
            },
            goPath () {
                console.log(909090900)
                this.$router.push({
                    path: '/company/addWorker'
                })
            },
            onFreezeemploy (d) {
                this.$router.push({
                    path: '/business/freezeemploy',
                    query: { staffId: d.staffId }
                })
            },
            onCancel () {
                this.inputText = ''
            }
        },
        components: {
            pullDownRefresh,
            tabbarBtn
        },
        watch: {
            inputText: debounce(function (val) {
                this.list = []
                this.currentPage = 1
                // this.paramsObj.name = this.searchValue

                if (/^\d{1,}$/.test(val)) {
                    // 手机号查询
                    this.currentPage = 1
                    // this.list.splice(0)
                    this.initData(1)
                } else {
                    // 姓名
                    this.currentPage = 1
                    // this.list.splice(0)
                    this.initData(0)
                }
            }, 400, false)
        }
    }
</script>
<style lang="scss" scoped>
.account {
    font-size: 0.15rem;
}
input::-webkit-input-placeholder {
    color: rgba(204, 204, 204, 1);
}
.search-box {
    margin: 0.12rem;
    height: 0.35rem;
    background: rgba(255, 255, 255, 1);
    border-radius: 18rem;
    border: 1px solid rgba(230, 230, 230, 1);
    display: flex;
    overflow: hidden;
    align-items: center;
    position: relative;
    z-index: 10;
    .icon-search {
        width: 0.16rem;
        height: 0.17rem;
        margin: 0 0.06rem 0 0.1rem;
    }
    input {
        -webkit-appearance: none;
        width: 2.9rem;
        height: 0.22rem;
        line-height: 0.22rem;
        border: none;
        font-size: 0.15rem;
    }
    .cancel {
        font-size: .15rem;
        margin: 0 .12rem;
    }
}

.wk-item {
    margin: 0.12rem;
    background: rgba(255, 255, 255, 1);
    border-radius: 0.04rem;
    margin-bottom: 0.12rem;
    .item-top {
        display: flex;
        justify-content: space-between;
        height: 0.5rem;
        align-items: center;
        padding: 0 0.12rem;
        color: rgba(46, 45, 45, 1);
        border-bottom: 1px solid rgba(238, 241, 244, 1);
    }
    .van-icon-arrow {
        position: relative;
        top: 0.02rem;
        width: 0.12rem;
    }
}
.wk-info {
    display: flex;
    padding: 0 0.12rem;
    .info-item {
        width: 33.33%;
        padding: 0.15rem 0;
        &:nth-child(2) {
            text-align: center;
        }
        &:nth-child(3) {
            text-align: right;
        }
        p {
            margin: 0;
            font-size: 0.12rem;
            color: rgba(132, 132, 132, 1);
            line-height: 1.5;
        }
        span {
            color: rgba(46, 45, 45, 1);
            display: block;
            line-height: 1.5;
            margin-top: 0.08rem;
        }
    }
    .icon-eye {
        width: 0.13rem;
        height: 0.11rem;
        position: relative;
        top: .006rem;
    }
}
.red {
    color: rgba(240, 37, 15, 1) !important;
}
.btn-add {
    color: rgba(255, 255, 255, 1);
    font-size: 0.18rem;
    text-align: center;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 0.6rem;
    & > span {
        margin-left: 0.05rem;
    }
}
.no-data {
    position: fixed;
    top: 0;
    width: 100%;
    height: 100vh;
    z-index: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #f5f8fc;
    .no-data-icon {
        width: 1.45rem;
        height: 1.45rem;
        background-color: #e4e4e4;
        border-radius: 50%;
        background: url('../../../assets/img/empty.png') no-repeat;
        background-position: center center;
        background-size: 100% 100%;
    }
    .no-data-text {
        color: #2e2d2d;
        font-size: 0.15rem;
        font-weight: 500;
        text-align: center;
        margin-top: 0.28rem;
    }
}
</style>
