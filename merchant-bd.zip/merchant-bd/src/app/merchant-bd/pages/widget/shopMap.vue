<template>
    <div class="bd-map">
        <div class="close-button" @click="closeEvent">
            <van-icon name="close" />
        </div>

        <div id="container">
            <baidu-map
                name="subMap"
                class="sub-view"
                :dragging="true"
                :scroll-wheel-zoom="true"
                :center="centerPoint"
                :zoom="15"
                :pinch-to-zoom="true"
                @ready="initMap"
                @dragend="getPoint"
                ak="rN3rzotGKGmVfAKo48wWGWaLaMWyYFpg"
            >
                <bm-marker
                    :position="centerPoint"
                    :dragging="isDrag"
                    @dragend="dragend"
                ></bm-marker>
            </baidu-map>
        </div>

        <div class="addres-submit">
            <p>{{ address }}</p>
            <div class="btn-manage" @click="setPosition">提交</div>
        </div>
    </div>
</template>

<script>
    import { BaiduMap, BmMarker } from 'vue-baidu-map'
    import { Toast } from 'vant'
    // import coordtransform from 'coordtransform'
    // 引入coockies
    // const Cookies = require('js-cookie')

    export default {
        name: 'shopMap',
        props: {
            address: {
                type: String,
                default () {
                    return ''
                }
            },
            center: {
                type: Object,
                default () {
                    return { lng: 39.915, lat: 116.404 }
                }
            },
            changePoint: {
                type: Object,
                default () {
                    return { lng: 39.915, lat: 116.404 }
                }
            }
        },
        data () {
            return {
                BMap: null,
                map: null,
                initCenter: this.center,
                isDrag: true,
                lng: '',
                lat: '',
                from: '',
                centerPoint: this.changePoint
            }
        },
        created () {
            console.log(this.center)
        },
        watch: {
            address (val) {
                this.address = val
            },
            center (val) {
                this.center = val
                console.log('this.center:', this.center)
            }
        },
        mounted () {},
        computed: {},
        // beforeRouteEnter (to, from, next) {
        //     Cookies.set('from', from.name)
        //     next()
        // },
        methods: {
            // 初始化map
            initMap ({ BMap, map }) {
                console.log('BMap, map----->', BMap, map)
                this.BMap = BMap
                this.map = map
            },
            getPoint (value) {
                this.position = value.point
            },
            dragend (value) {
                console.log(value)
                // const centerLng = value.point.lng
                // const centerLat = value.point.lat
                const right = this.initCenter.lng + 0.006
                const left = this.initCenter.lng - 0.006
                const top = this.initCenter.lat + 0.006
                const bottom = this.initCenter.lat - 0.006
                let centerLng = this.center.lng
                let centerLat = this.center.lat

                if (value.point.lng > right) {
                    Toast.fail('您更新的地点已超过初始定位1km范围')

                    centerLat = value.point.lat
                    centerLng = right
                }
                if (value.point.lng < left) {
                    Toast.fail('您更新的地点已超过初始定位1km范围')

                    centerLat = value.point.lat
                    centerLng = left
                }
                if (value.point.lat > top) {
                    Toast.fail('您更新的地点已超过初始定位1km范围')

                    centerLat = top
                    centerLng = value.point.lng
                }
                if (value.point.lat < bottom) {
                    Toast.fail('您更新的地点已超过初始定位1km范围')

                    centerLat = bottom
                    centerLng = value.point.lng
                }
                if (value.point.lat <= top && value.point.lat >= bottom && value.point.lng >= left && value.point.lng <= right) {
                    centerLat = value.point.lat
                    centerLng = value.point.lng
                }
                console.log('设置经纬度')
                this.centerPoint = {
                    lat: centerLat,
                    lng: centerLng
                }
            },
            setPosition () {
                this.$emit('dragendPoint', this.centerPoint)
            },
            closeEvent () {
                this.$emit('closeMapEvent', false)
            }
        },
        components: {
            BaiduMap,
            BmMarker
        }
    }
</script>

<style lang="scss" scoped>
.bd-map {
    position: fixed;
    top: 0;
    z-index: 1000;
    width: 100%;
    height: 100%;

    .close-button {
        position: absolute;
        top: 0.24rem;
        right: 0.24rem;
        height: 0.24rem;
        font-size: 0.2rem;
        z-index: 9;
        color: #F0250F;
    }

    #container {
        position: absolute;
        width: 100%;
        height: calc(100% - 0.6rem);
        left: 0;
        background-color: #eee;
    }

    .addres-submit {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 0.6rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #fff;
        padding: 0 0.24rem;
        box-sizing: border-box;

        & > p {
            width: 2.8rem;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            line-height: 1.5;
            font-size: 0.15rem;
        }

        .btn-manage {
            width: 0.6rem;
            height: 0.28rem;
            line-height: 0.29rem;
            color: #fff;
            background: #F0250F;
            border-radius: 0.15rem;
            font-size: 0.15rem;
            text-align: center;
        }
    }
}
.sub-view {
    width: 100%;
    height: 100%;
}
</style>
