<template>
    <div class="school-map-container">
        <div class="shop-map">
            <baidu-map
                v-if="initLocation"
                class="bm-view"
                :zoom="14"
                :pinch-to-zoom="false"
                :dragging="true"
                :center="centerPoint"
                :panel="false"
                @click="clickMap"
                @ready="initMap"
                @touchstart="goMapBefore"
                @touchend="goMap"
                ak="rN3rzotGKGmVfAKo48wWGWaLaMWyYFpg"
            >
                <!-- 定位后的中心点 -->
                <bm-marker
                    :position="centerPoint"
                    :offset="{width: 0, height: -10}"
                >
                </bm-marker>

                <!-- 学校的位置点 -->
                <bm-marker 
                    v-for="(item, index) in schoolInfoList" 
                    :key="index"
                    :position="{lng: item.longitude, lat: item.latitude}" 
                    :dragging="false" 
                    :panel="false"
                    :top="true"
                    :icon="{url: require('../../assets/img/local/school_map.png'), size: {width: 20, height: 25}}"
                >
                </bm-marker>
                
                <!-- <bm-local-search 
                    style="display: none;"
                    :position="centerPoint"
                    :keyword="searchAddress"
                    @searchcomplete="searchComplete"
                    :pageCapacity="1"
                    :autoViewport="true"
                    :location="location"
                >
                </bm-local-search> -->
            </baidu-map>
        </div>

        <!-- 地图检索 隐藏显示 -->
        <div v-show="false">
            <baidu-map
                v-if="initLocation"
                class="bm-view"
                :zoom="14"
                :pinch-to-zoom="false"
                :dragging="true"
                :center="centerPoint"
                :panel="false"
                @ready="initMap"
                ak="rN3rzotGKGmVfAKo48wWGWaLaMWyYFpg"
            >
                <bm-local-search 
                    style="display: none;"
                    :position="centerPoint"
                    :keyword="searchAddress"
                    @searchcomplete="searchComplete"
                    :pageCapacity="1"
                    :autoViewport="true"
                    :location="location"
                >
                </bm-local-search>
            </baidu-map>
        </div>

        <div class="school-zone">
            <h4>您的店铺将覆盖以下学校</h4>
            <div class="scroll-zone ">
                <div class="school-item" v-for="(item, index) in schoolInfoList" :key="index" @click="checkChange(index)">
                    <van-checkbox v-if="!disabled" v-model="item.isChecked" :disabled="(disabledIndex === index ? checkedStatus : false)" shape="square" icon-size="0.14rem" :name="item" ref="checkboxes">{{item.schoolName}}</van-checkbox>
                    <van-checkbox v-else v-model="item.isChecked" :disabled="disabled" shape="square" icon-size="0.14rem" :name="item" ref="checkboxes">{{item.schoolName}}</van-checkbox>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {
        BaiduMap, 
        BmLocalSearch, 
        BmMarker 
        // BmLabel, 
        // BmInfoWindow
    } from 'vue-baidu-map'
    // 引入防抖组件
    import { debounce } from '@/merchant-bd/utils/debounce/index'

    export default {
        name: 'schoolMap',
        components: {
            BaiduMap,
            BmLocalSearch,
            BmMarker
            // BmLabel,
            // BmInfoWindow
        },
        props: {
            initLocation: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 地图位置点
            center: {
                type: Object,
                default () {
                    return {
                        lng: 116.403963,
                        lat: 39.915119
                    }
                }
            },
            gpsLng: {
                type: Number,
                default () {
                    return 0
                }
            },
            gpsLat: {
                type: Number,
                default () {
                    return 0
                }
            },
            schoolInfoList: {
                type: Array,
                default () {
                    return []
                }
            },
            searchAddress: {
                type: String,
                default () {
                    return ''
                }
            },
            goMapBefore: {
                type: Function,
                default () {
                    return () => {}
                }
            },
            goMap: {
                type: Function,
                default () {
                    return () => {}
                }
            },
            clickMap: {
                type: Function,
                default () {
                    return () => {}
                }
            },
            disabled: {
                type: Boolean,
                default () {
                    return false
                }
            }
        },
        data () {
            return {
                merchantLng: '',
                merchantLat: '',
                centerPoint: this.center,
                newSchoolList: [],
                checkedCount: 0,
                disabledIndex: 0,
                checkedStatus: false,
                location: ''
            }
        },
        created () {
            // console.log('在地图上显示学校')
            // console.log(this.schoolInfoList)
        },
        watch: {
            center (val) {
                this.center = val
                this.centerPoint = val
                // console.log('this.center:', this.center)
            },
            searchAddress (val) {
                this.searchAddress = val
                console.log('this.searchAddress:', this.searchAddress)
            },
            schoolInfoList (array) {
                // console.log('schoolInfoList', array)
                // 重置数据
                this.disabledIndex = 0
                this.checkedStatus = false
                let counts = 0
                this.schoolInfoList.map((item, index) => {
                    if (item.isChecked) {
                        this.disabledIndex = index
                        counts++
                    }
                    return item
                })
                // console.log('counts:', counts)
                if (this.schoolInfoList.length === 1 || counts === 1) {
                    // this.disabledIndex = 0
                    this.checkedStatus = true
                }
                this.schoolInfoList = array
                // console.log('this.schoolInfoList:', this.schoolInfoList)
            }
        },
        methods: {
            // 初始化地图
            initMap ({ BMap, map }) {
                // console.log('BMap, map----->', BMap, map)
                this.centerPoint = this.center
                this.BMap = BMap
                this.map = map
            },
            // 搜索地址 成功后的返回内容
            // searchComplete (searchResult) {
            //     console.log('searchResult--------->', searchResult)
                
            //     if (searchResult) {
            //         const poi = searchResult.getPoi(0)
            //         // console.log(poi)
            //         if (poi) {
            //             // console.log('poi.point--->', poi.point)
            //             this.centerPoint = { lng: poi.point.lng, lat: poi.point.lat }

            //             const newPoint = {
            //                 Lng: poi.point.lng,
            //                 Lat: poi.point.lat
            //             }
            //             this.$emit('returnPoint', newPoint)
            //         }
            //     }
            // },
            // 防抖后的方法
            searchComplete: debounce(function (searchResult) {
                console.log('searchResult--------->', searchResult)
                
                if (searchResult) {
                    const poi = searchResult.getPoi(0)
                    // console.log(poi)
                    if (poi) {
                        // console.log('poi.point--->', poi.point)
                        this.centerPoint = { lng: poi.point.lng, lat: poi.point.lat }

                        const newPoint = {
                            Lng: poi.point.lng,
                            Lat: poi.point.lat
                        }
                        this.$emit('returnPoint', newPoint)
                    }
                }
            }, 400, false),
            // check change 事件
            checkChange (index) {
                this.checkedCount = this.schoolInfoList.length

                setTimeout(() => {
                    const { checked } = this.$refs.checkboxes[index]
                    console.log('学校勾选：', checked, this.checkedCount, index)

                    this.newSchoolList = this.schoolInfoList.map((item, i) => {
                        if (!item.isChecked) {
                            this.checkedCount--
                        } else {
                            this.disabledIndex = i
                        }
                        if (this.checkedCount === 1) {
                            // 当checkedCount 等于1的时候 禁止最后一个勾选
                            this.checkedStatus = true
                        } else if (index === i) { 
                            this.checkedStatus = false
                            item.isChecked = checked
                        }
                        return item
                    })
                    this.$emit('returnSchoolList', this.newSchoolList)
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
.school-map-container {
    width: 100%;
    height: auto;

    .shop-map {
        height: 2.07rem;
    }
    .school-zone{
        padding: 0 .16rem;
        
        & h4 {
            margin: 0;
            font-weight: normal;
            font-size: .13rem;
            color: rgba(127,127,127,1);
            margin: .16rem 0 0;
        }
        &>.scroll-zone {
            max-height: 1.53rem;
            overflow-y: scroll;
        }
        .school-item{
            display: flex;
            align-items: center;
            margin: .16rem 0;
            
            /deep/ .van-checkbox {
                width: 100%;
                margin: 0;
            }
            /deep/ .van-checkbox__label {
                font-size: 0.13rem;
                color: #000000;
                font-weight: 400;
            }
            /deep/ .van-checkbox__icon {
                border-radius: 0.03rem;
                overflow: hidden;
            }
        }
    }
    /deep/ .van-checkbox {
        margin: .16rem 0;
    }
    .bm-view {
        height: 2.07rem;
    }
    .form-item {
        display: flex;
        justify-content: space-between;
        padding: 0.16rem 0.16rem;
        position: relative;
        .label-md {
            color: rgba(0,0,0,.3);
            display: flex;
            align-items: center;
            span {
                margin-right: .08rem;
            }
        }
    }
    .form-item::after {
        content: '';
        position: absolute;
        width: 100%;
        height: 1px;
        background-color: #ebedf0;
        left: 0;
        bottom: 0;
        transform: scaleY(0.5);
    }
    .item-cont {
        display: flex;
        align-items: center;
        span {
            margin-right: .08rem;
        }
    }
}
</style>
