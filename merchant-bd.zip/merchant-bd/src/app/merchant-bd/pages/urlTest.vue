<template>
<div class="url-test-container">
    <van-cell-group>
        <van-field v-model="value" placeholder="请输入url" />
    </van-cell-group>
    <van-button type="default" @click="goTo">前往</van-button>
</div>
</template>

<script>
    export default {
        name: 'urlTest',
        data () {
            return {
                value: ''
            }
        },
        methods: {
            goTo () {
                if (this.value) {
                    window.location.href = this.value
                } else {
                    this.$router.push('/forbid')
                }
            }
        }
    }
</script>

<style scoped>
    .url-test-container{
        text-align: center;
        font-size: 14px;
    }

</style>
