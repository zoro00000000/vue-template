const DISTRICT_SUPERVISOR = 1
const PROVINCIAL_SUPERVISOR = 2
const PROFESSIONAL = 3
const SUBMITANDQR = 4
const GETQR = 5
const ENTRYRECORD = 6
const VISITRECORD = 7
const RECHANGERECORD = 8
const TREADERECORD = 9
const ADDMERCHANT = 10
const UPDATEMERCHANT = 11
// 新增 角色 商家代理 = 1 ; 员工代理 = 2
const ROLE_BUSINESS = 1
const ROLE_EMPLOYEE = 2
// 新增 角色 员工业绩 = 1; 交易记录 = 2
const TYPE_RECORD = 1
const TYPE_PERFORMANCE = 2

export const ENUMLIST = {
    UPDATEMERCHANT,
    ADDMERCHANT,
    TREADERECORD,
    DISTRICT_SUPERVISOR,
    PROVINCIAL_SUPERVISOR,
    PROFESSIONAL,
    SUBMITANDQR,
    GETQR,
    ENTRYRECORD,
    VISITRECORD,
    RECHANGERECORD,
    // 新增 角色 商家代理 = 1 ; 员工代理 = 2
    ROLE_BUSINESS,
    ROLE_EMPLOYEE,
    TYPE_RECORD,
    TYPE_PERFORMANCE
}

export const MONTHLIST = [{
    text: '1月',
    value: 1
}, {
    text: '2月',
    value: 2
}, {
    text: '3月',
    value: 3
}, {
    text: '4月',
    value: 4
}, {
    text: '5月',
    value: 5
}, {
    text: '6月',
    value: 6
}, {
    text: '7月',
    value: 7
}, {
    text: '8月',
    value: 8
}, {
    text: '9月',
    value: 9
}, {
    text: '10月',
    value: 10
}, {
    text: '11月',
    value: 11
}, {
    text: '12月',
    value: 12
}]
