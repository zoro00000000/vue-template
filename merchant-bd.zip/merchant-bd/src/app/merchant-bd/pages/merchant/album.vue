<template>
    <div class="album_container">
        <div class="album-item" v-if="fileList11.length > 0">
            <p class="title">头图照</p>
            <div class="album-item-content">
                <template  v-for="(item) in fileList11">
                    <div  class="inner" :key="innerItem.imgId" v-for="(innerItem) in item.images">
                        <img  :src="innerItem.imgUrl | imageLoadFilter" alt="">
                    </div>
                </template>
            </div>
        </div>

        <div class="album-item">
            <p class="title">门脸照</p>
            <div class="album-item-content">
                <template  v-for="(item) in fileList1">
                    <div  class="inner" :key="innerItem.imgId" v-for="(innerItem) in item.images">
                        <img  :src="innerItem.imgUrl | imageLoadFilter" alt="">
                    </div>
                </template>
            </div>
        </div>
        
        <div class="album-item">
            <p class="title">店内环境照</p>
            <div class="album-item-content">
                <template  v-for="(item) in fileList2">
                    <div  class="inner" :key="innerItem.imgId" v-for="(innerItem) in item.images">
                        <img  :src="innerItem.imgUrl | imageLoadFilter" alt="">
                    </div>
                </template>
            </div>
        </div>

        <div class="album-item" v-for="(item, index) in fileList5" :key="index">
            <!-- <p class="title">{{item.tag}}</p> -->
            <p class="title">行业特殊资质许可证</p>
            <div class="album-item-content">
                <div  class="inner" :key="innerItem.imgId" v-for="(innerItem) in item.images">
                    <img  :src="innerItem.imgUrl | imageLoadFilter" alt="">
                </div>

            </div>
        </div>
        
        <!-- 非法人的时候展示的照片 暂时去除 -->
        <div v-if="otherStatus">
            <div class="album-item">
                <p class="title">收款人手持营业执照和身份证照片</p>
                <div class="album-item-content">
                    <template>
                        <div  class="inner" :key="innerItem.imageId" v-for="(innerItem) in operatorImgList">
                            <img :src="innerItem.imageUrl | imageLoadFilter" alt="">
                        </div>
                    </template>
                </div>
            </div>

            <div class="album-item">
                <p class="title">结算账户授权书照片</p>
                <div class="album-item-content">
                    <template>
                        <div  class="inner" :key="innerItem.imageId" v-for="(innerItem) in settlementAuthImgList">
                            <img  :src="innerItem.imageUrl | imageLoadFilter" alt="">
                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'

    export default {
        name: 'albumManage',
        props: ['topTitle', 'topTips', 'isBottomBorder'],
        data () {
            return {
                fileList1: {},
                fileList2: {},
                fileList5: {},
                fileList11: {},
                merchantId: '',
                // otherStatus: localStorage.getItem('settlementType') === '2',
                otherStatus: false,
                operatorImgList: JSON.parse(localStorage.getItem('operatorImgList')),
                settlementAuthImgList: JSON.parse(localStorage.getItem('settlementAuthImgList'))
            }
        },
        watch: {
            fileList () {
                console.log(this.fileList.length)
                this.$emit('addAlbums', this.fileList)
            }
        },
        created () {
            this.merchantId = this.$route.params.merchantId
            this.queryBDMerchantAlbumInfo(1)
            this.queryBDMerchantAlbumInfo(2)
            this.queryBDMerchantAlbumInfo(5)
            this.queryBDMerchantAlbumInfo(11)
        },
        methods: {
            addPhoto () {
                // 解决chrome 浏览器单击不生效
                const evt = document.createEvent('MouseEvents')
                evt.initEvent('click', true, false)
                this.$refs.uploaderImg.dispatchEvent(evt)
            },
            getImages (event) {
                for (let i = 0; i < event.target.files.length; i++) {
                    const image = event.target.files[i]
                    const imgReaer = new FileReader()
                    imgReaer.readAsDataURL(image)
                    imgReaer.onload = readerEvent => {
                        const base64 = readerEvent.target.result
                        this.fileList.push({ url: base64, isImage: true })
                    }
                }
            },
            queryBDMerchantAlbumInfo (type) {
                console.log('queryBDMerchantAlbumInfo')
                return fetch.get({
                    url: apiUrl.queryBDMerchantOtherImageAlbumInfo,
                    data: {
                        merchantId: this.merchantId,
                        type
                    }
                }, res => {
                    console.log(res)
                    if (res.result && res.result.code === '0000') {
                        this[`fileList${type}`] = res.data && res.data || []
                    } else {
                        // this.goToPage(ENUMLIST.PROFESSIONAL)
                    }
                }, res => {
                    console.log(res)
                })
            }
        }
    }
</script>

<style lang="scss" scoped >
    .album_container {
        margin: 0;
        padding: 0 0.16rem;

        .title{
            font-size: .15rem;
            margin: .12rem 0;
        }

        .album-item-content{
            display: flex;
            flex-wrap: wrap;
            padding: .16rem 0.16rem 0.06rem 0.16rem;
            background:rgba(255,255,255,1);
            box-shadow:0px 8px 9px 0px rgba(163,169,177,0.1);
            border-radius:5px;
            .inner{
                width: 1.5rem;
                height: .84rem;
                font-size: 0;
                margin-right: .1rem;
                margin-bottom: .1rem;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            .inner:nth-child(2n){
                margin-right: 0;
            }
        }
    }
</style>
