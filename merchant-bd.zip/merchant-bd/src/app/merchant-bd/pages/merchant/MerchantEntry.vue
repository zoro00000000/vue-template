<template>
    <div>
        <!-- 店铺信息 -->
        <van-cell-group class="upload_block" :border="false">
            <div class="group-title">
                店铺信息
            </div>

            <van-field
                v-model="shopName"
                label="店铺名称"
                placeholder="在此输入店铺名称"
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
            <van-field
                v-model="shopTel"
                label="店铺电话（选填）"
                placeholder="在此输入店铺电话"
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
            <van-field
                v-model="shopOwner"
                label="店铺负责人"
                placeholder="在此输入店铺负责人"
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
            <van-field
                v-model="shopOwnerTel"
                label="负责人联系电话"
                placeholder="在此输入联系人电话"
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>

            <!-- 非法人结算 -->
            <van-field
                v-model="account"
                label="选择结算类型"
                right-icon="arrow"
                readonly
                label-class="label-style"
                label-width="1.65rem"
                input-align="right"
                placeholder="请选择"
                @click="chooseAccount()"
            >
            </van-field>

            <van-field label="关联合伙人邀请码"
                readonly
                v-if="!updateMerchantPage"
                @click="jumpTrading"
                right-icon="arrow"
                label-class="label-style"
                label-width="1.5rem"
                input-align="right"
            >
            </van-field>
        </van-cell-group>

        <!-- 选择行业 -->
        <van-cell-group class="upload_block" :border="false">
            <div class="group-title">
                选择行业
            </div>

            <van-field
                v-model="industry"
                label="选择所属行业"
                arrow-direction="left"
                readonly
                right-icon="arrow"
                label-class="label-style"
                label-width="1rem"
                input-align="right"
                placeholder="请选择"
                @click="chooseIndustry()"
            >
            </van-field>

            <!-- 同城新需求 -->
            <van-field v-if="switchStatus" name="switch" label="是否开通到校" :label-width="'1rem'">
                <template #input>
                    <div class="field-container">
                        <van-icon @click="clickSchoolWarning" class="field-icon" name="warning-o" />
                        <van-switch v-model="switchChecked" @change="switchChange" size="20" />
                    </div>
                </template>
            </van-field>

            <van-field
                v-model="managementContent"
                label="选择经营内容"
                right-icon="arrow"
                readonly
                label-class="label-style"
                label-width="1.65rem"
                input-align="right"
                placeholder="请选择"
                @click="chooseContent()"
            >
            </van-field>

            <van-field
                type="number"
                v-model="avgPrice"
                label="人均价格"
                placeholder="在此输入人均价格"
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
        </van-cell-group>

        <!-- 关联学校 -->
        <van-cell-group class="upload_block" :border="false">
            <div class="group-title">
                <div>关联学校</div>
            </div>

            <van-field
                v-model="address"
                label="店铺所在地"
                :placeholder="address ? address : '省/市/区/街道'"
                input-align="right"
                readonly
                label-class="label-style"
                label-width="1rem"
                @click="chooseShopAddress"
            >
            </van-field>
            <van-field
                v-model="detailedAddress"
                label="具体地址"
                placeholder="请精确到门牌号"
                input-align="right"
                label-class="label-style"
                label-width="1rem"
            >
            </van-field>

            <!-- 新增学校 -->
            <school-map 
                v-if="showMap"
                :initLocation="initLocation"
                :center="center"
                :gpsLng="gpsLng"
                :gpsLat="gpsLat"
                :schoolInfoList="schoolInfoList"
                :clickMap="clickMap"
                :goMap="goMap"
                :goMapBefore="goMapBefore"
                :searchAddress="searchAddress"
                @returnPoint="returnPoint"
                @returnSchoolList="returnSchoolList"
            />
        </van-cell-group>

        <div style="display: none" id="map"></div>

        <!-- 新增 收款人信息 -->
        <div v-if="accountVal === 2" class="id-card-info">
            <div class="desc_title">
                <div class="desc_title_left">收款人信息</div>
            </div>

            <auth-upload-img
                :imgBgUrl="'idCardFront'"
                :bottomTitle="'请上传收款人身份证信息面'"
                @addAlbums="getImgList('front', $event)"
                :file="idCardFront"
                :type="'P'"
                @idCardInfo="getIdCardInfo('front', $event)"
                :merchant-id="merchantId"
                :title="'收款人身份证信息面'"
                :initFile="idCardFrontImg"
                :isORC="true"
            ></auth-upload-img>

            <auth-upload-img
                :imgBgUrl="'idCardBack'"
                :bottomTitle="'请上传收款人身份证国徽面'"
                @addAlbums="getImgList('back', $event)"
                :file="idCardBack"
                :type="'N'"
                @idCardInfo="getIdCardInfo('back', $event)"
                :merchant-id="merchantId"
                :title="'收款人身份证国徽面'"
                :initFile="idCardBackImg"
                :isORC="true"
            ></auth-upload-img>

            <van-cell-group class="upload_block" :border="false">
                <van-field
                    v-model="manageName"
                    label="收款人姓名"
                    placeholder="在此输入收款人姓名"
                    input-align="right"
                    label-class="label-style"
                    label-width="1.65rem"
                    maxlength="16"
                >
                </van-field>

                <van-field
                    v-model="idCard"
                    label="收款人身份证号"
                    placeholder="在此输入收款人身份证号"
                    input-align="right"
                    label-class="label-style"
                    label-width="1.1rem"
                    maxlength="18"
                >
                </van-field>

                <van-field
                    v-model="indate"
                    label="证件有效期"
                    right-icon="arrow-down"
                    readonly
                    label-class="label-style"
                    label-width="1.65rem"
                    input-align="right"
                    placeholder="请选择"
                    @click="chooseDate()"
                >
                </van-field>

                <van-field
                    v-model="startTime"
                    label="起始有效期"
                    placeholder="在此输入起始有效期"
                    input-align="right"
                    label-class="label-style"
                    label-width="1rem"
                    maxlength="10"
                    :clearable="true"
                    @click="showDatePicker(1)"
                    :disabled="true"
                >
                </van-field>

                <van-field
                    v-if="!endTimeStatus"
                    v-model="endTime"
                    label="结束有效期"
                    placeholder="在此输入结束有效期"
                    input-align="right"
                    label-class="label-style"
                    label-width="1.1rem"
                    maxlength="10"
                    :clearable="true"
                    @click="showDatePicker(2)"
                    :disabled="true"
                >
                </van-field>
            </van-cell-group>
        </div>

        <!-- 上传相关照片 -->
        <van-cell-group
            class="upload_block"
            :border="false"
        >
            <div class="group-title">
                上传相关照片
            </div>

            <!-- 同城新增 -->
            <auth-album
                topTitle="展示头图照（长宽比为1：1）"
                topText="请上传logo、精品菜或等其他能代表店铺特色的美观照片"
                :imageType="11"
                :file="head"
                :init-file="headFileList"
                :merchant-id="merchantId"
                :fixedNumber="[1, 1]"
                @addAlbums="setFileList(11, $event)"
            />

            <!-- logo -->
            <auth-album
                topTitle="门脸图（图片小于10兆）"
                topText="请上传有完整牌匾与正门，处于营业状态的门脸图"
                :imageType="1"
                :file="logo"
                :init-file="logoFileList"
                :merchant-id="merchantId"
                @addAlbums="setFileList(1, $event)"
            />

            <!-- 门店环境 -->
            <auth-album
                topTitle="店内环境图（图片小于10兆）"
                topText="请上传清晰、整洁，处于营业状态的店内环境图"
                topTips="增加照片"
                :imageType="2"
                :file="env"
                :init-file="envFileList"
                :merchant-id="merchantId"
                @addAlbums="setFileList(2, $event)"
            />
        </van-cell-group>

        <!-- 新增 经营者资料  -->
        <van-divider
            style="margin-left: .32rem; margin-right: .32rem; opacity: 1; color: #7F7F7F; font-size: .15rem"
        >
            补充资料
        </van-divider>

        <auth-album
            type2="true"
            :key="1"
            :disabledMenu="true"
            :headerTitle="'行业特殊资质许可证'"
            :init-file="otherFileList"
            @addAlbums="setFileList(3, $event)"
            :merchant-id="merchantId"
            :file="other"
        >
        </auth-album>

        <!-- 非法人 -->
        <div v-if="accountVal === 2">
            <auth-album
                type2="true"
                :key="2"
                :disabledMenu="true"
                :headerTitle="'收款人手持营业执照和身份证照片'"
                :headerText="'左手持营业执照, 右手持身份证信息面'"
                :init-file="operatorImgFileList"
                @addAlbums="setFileList(4, $event)"
                :merchant-id="merchantId"
                :file="operatorImgList"
            >
            </auth-album>

            <auth-album
                type2="true"
                :key="3"
                :disabledMenu="true"
                :headerTitle="'结算账户授权书照片'"
                :headerText="'结算账户指定书，企业必须加盖公章' + ' \n ' + '个体工商户加盖公章或法人签名、按手印'"
                :init-file="settlementAuthImgFileList"
                @addAlbums="setFileList(5, $event)"
                :merchant-id="merchantId"
                :file="settlementAuthImgList"
            >
            </auth-album>

            <van-cell-group class="upload_block" :border="false">
                <div class="download-box" @click="showImgTemplate">
                    <div class="download-title">获取授权书模板</div>
                    <div class="download-text">授权书模板保存到相册并打印</div>
                    <div class="arrows-box"><van-icon class="arrows-style" name="upgrade" /></div>
                </div>
            </van-cell-group>
        </div>

        <!--    通用选择弹窗    -->
        <van-popup
            v-model="showPopup"
            position="bottom"
            :style="{ height: '30%' }"
        >
            <van-picker
                show-toolbar
                :title="popupTitleQualification"
                :columns="itemsQualification"
                :default-index="defaultIndexQualification"
                :visible-item-count="visibleItemCountQualification"
                :item-height="itemHeightQualification"
                :swipe-duration="100"
                @cancel="showPopup = false"
                @confirm="onConfirm"
            >
            </van-picker>
        </van-popup>

        <van-popup v-model="qrShow" round>
            <div class="qr_style">
                <p class="title">扫码入驻</p>
                <div ref="qrDiv" class="qr_content"></div>
                <p class="foot">{{ dataFormat() }}</p>
            </div>
        </van-popup>
        
        <!--    四级地址选择弹窗    -->
        <dist-picker
            v-if="distPickerShowFlag"
            @close="distPickerClose"
            @selected="distPickerSelect"
            :province="merchantAddress.province"
            :city="merchantAddress.city"
            :country="merchantAddress.country"
            :town="merchantAddress.town"
            :provinceId="merchantAddress.provinceId"
            :cityId="merchantAddress.cityId"
            :countryId="merchantAddress.countryId"
            :townId="merchantAddress.townId"
        ></dist-picker>

        <div class="submit">
            <p>
                {{
                    updateMerchantPage
                        ? '请确认商户信息修改无误后提交'
                        : '提交信息后可生成并提交二维码'
                }}
            </p>
            <button class=" btn" @click="submit()">
                {{ updateMerchantPage ? '更新商家信息' : '提交并生成二维码' }}
            </button>
        </div>

        <!-- 新增保存图片弹窗 -->
        <van-popup
            v-model="showSaveImgPopup"
            :style="{ width: '100vw', height: 'auto', maxHeight: '80vh' }"
        >
            <div @touchstart="touchStart" @touchend="touchEnd">
                <img class="tempalte-img" width="100%" height="auto" src="//m.360buyimg.com/yocial/jfs/t1/99206/40/17208/1252468/5e843a7fE2c25409c/d4179d40a3be1f96.jpg">
            </div>
        </van-popup>
        <!-- 新增时间选择器 -->
        <van-popup v-model="showPicker" position="bottom">
            <van-datetime-picker
                type="date"
                @confirm="onTimeConfirm"
                @cancel="showPicker = false"
                :min-date="minDate"
                :max-date="maxDate"
            />
        </van-popup>

        <!-- 同城新增 关联学校提示弹窗 -->
        <alert-overlay 
            :show="schoolWarning"
            :alertType="3"
            :headerTitle="'提示'"
            :contentText="'勾选即表示商家店铺支持自配送到校服务，学生将通过梨涡APP与商家在线沟通；如不支持到校自配送服务，请勿勾选'"
            :showSolt="false"
            :confirmEvent="confirmClick"
        >
        </alert-overlay>

        <!-- 全屏shop map 组件 -->
        <shop-map
            v-if="showFullMap"
            :address="fullAddress"
            :center="fullCenter"
            :changePoint="changePoint"
            @dragendPoint="dragendPoint"
            @closeMapEvent="closeMapEvent"
        ></shop-map>
    </div>
</template>

<script>
    import QRCode from 'qrcodejs2'
    import coordtransform from 'coordtransform'
    import api from '@/merchant-bd/api/main'
    import dayjs from 'dayjs'
    import alertOverlay from '@/merchant-bd/components/alertOverlay'
    import {
        validatorPhone, validatorTel, validatorIdCard, validatorSpace
    } from '@/merchant-bd/utils/formRule'
    import JME from '@/merchant-bd/utils/jdme.js'
    import { getUrlString } from '@/merchant-bd/utils/tools'
    import distPicker from '@/merchant-bd/components/distPicker/distPicker'
    import authAlbum from '../layout/albumManage'
    // 引用图片上传
    import authUploadImg from '../layout/authUploadImg'
    import 'swiper/css/swiper.css'
    // 引入 蒙层 组件
    import { ENUMLIST } from '../enum'
    import { imgHost } from '../../utils/constV'
    // native 交互方法
    import { initDsBridge } from '../../utils/JDMESDK'
    // 引入地图组件
    import schoolMap from '../widget/schoolMap'
    // 引入全屏地图组件
    import shopMap from '../widget/shopMap'

    // 资质上传界面
    export default {
        name: 'merchantEntry',
        components: {
            authAlbum,
            distPicker,
            authUploadImg,
            schoolMap,
            alertOverlay,
            shopMap
        },
        props: ['updateMerchantPage'],
        data () {
            return {
                pageType: '', // 页面类型 新增商户还是修改商户
                material: 0, // 添加补充材料的个数  字段太多 待优化
                merchantId: '', // 商户id
                currentErp: '', // 当前erp
                logoFileList: [], // 相册相关
                logo: [],
                envFileList: [],
                env: [],
                door: [],
                doorFileList: [], // 头图
                otherFileList: [], // 行业资质许可证
                otherImgFileList: [],
                operatorImgList: [], // 收款人手持营业照和身份证照
                operatorImgFileList: [],
                settlementAuthImgList: [], // 结算账户授权书照片
                settlementAuthImgFileList: [],
                other: [],
                // licenceFileList: [[], [], [], [], [], [], [], [], [], []],
                avgPrice: undefined,
                schoolInfoList: [], // 存储回显时的学校数据
                school: [], // 用于在页面展示学校列表
                schoolList: [], // 掉接口返回的学校列表
                discount: [], // 上传的折扣列表
                defaultDiscount: '',
                disCountList: {
                    first: [0],
                    second: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
                },
                discountIndex: 0,
                flag: '', // 控制下拉弹窗的类型
                schoolCount: 2, // 计数
                schoolCountFlag: -1, // 控制监视器是否变化
                itemHeightQualification: 36,
                visibleItemCountQualification: 4,
                defaultIndexQualification: 1,
                itemsQualification: [],
                showPopup: false,
                popupTitleQualification: '',
                managementContent: '',
                industry: '',
                industryList: [],
                industryContent: [],
                otherImages: [],
                category: { // 记录回填的行业信息
                    type: '',
                    id: '',
                    name: ''
                },
                categoryContent: { // 记录回填的经营内容信息
                    type: '',
                    id: '',
                    name: ''
                },
                value: '',
                shopName: '',
                shopTel: '',
                shopOwner: '',
                shopOwnerTel: '',
                shopOwnerEmail: '',
                distPickerShowFlag: false,
                merchantAddress: {
                    city: '',
                    cityId: '',
                    country: '',
                    countryId: '',
                    province: '',
                    provinceId: '',
                    town: '',
                    townId: 0
                },
                detailedAddress: '',
                merchantLng: '', // 经度0-180
                merchantLat: '', // 维度 0-90
                version: 0,
                qrShow: false,
                qrTimeStamp: '',
                qrCode: null,
                dividerShow: true,
                industryWatch: -1, // 监视器开关
                schoolWatch: -1,
                testDatas: ['查询中..', '查询中..', '查询中..', '查询中..'], // 测试数据
                account: '',
                accountVal: 1,
                accountList: [],
                manageName: '', // 新增 收款人姓名
                idCard: '', // 收款人身份证号
                startTime: '', // 身份证起始有效期
                endTime: '', // 身份证结束有效期
                indate: '固定', // 证件有效期
                indateVal: 1,
                endTimeStatus: false, // 是否禁用 身份证结束有效期
                indatetList: [],
                idCardFront: [], // 身份证 img URL
                idCardFrontImg: [],
                idCardBack: [],
                idCardBackImg: [],
                idCardHand: [],
                idCardHandImg: [],
                showSaveImgPopup: false,
                timer: null, // 长按事件定时器
                centerPoint: {
                    lng: 116.403963,
                    lat: 39.915119
                },
                minDate: new Date(1990, 1, 1),
                maxDate: new Date(2050, 12, 31),
                showPicker: false,
                dateType: 1, // 1=startTime、2=endTime
                switchChecked: true, // 同城新增
                showMap: false,
                initLocation: false,
                center: {},
                gpsLng: 116.403963,
                gpsLat: 39.915119,
                nearSchoolList: [],
                presentIndustry: {}, // 当前选择选择的行业
                switchStatus: false,
                schoolWarning: false,
                newLng: null,
                newLat: null,
                showFullMap: false,
                fullCenter: {},
                changePoint: {},
                schools: [],
                head: [],
                headFileList: [],
                firstShowSchool: 0,
                fullAddress: '',
                goMapTime1: null,
                goMapTime2: null
            }
        },
        created () {
            // 如果是新增商家 初始化仅仅获取商户ID
            console.log('create')
            if (this.updateMerchantPage) {
                console.log('请求回填信息')
                this.initBackFillInfo()
            } else {
                this.initData()
            }
            // 初始化 JMSDK
            initDsBridge()
        },
        computed: {
            address () {
                return (
                    (this.merchantAddress.province ? this.merchantAddress.province : '') 
                    + (this.merchantAddress.city ? `/${this.merchantAddress.city}` : '') 
                    + (this.merchantAddress.country ? `/${this.merchantAddress.country}` : '') 
                    + (this.merchantAddress.town ? `/${this.merchantAddress.town}` : '')
                )
            },
            searchAddress () {
                return (this.merchantAddress.province ? this.merchantAddress.province : '')
                    + (this.merchantAddress.city ? this.merchantAddress.city : '')
                    + (this.merchantAddress.country ? this.merchantAddress.country : '')
                    + (this.merchantAddress.town ? this.merchantAddress.town : '')
                    + (this.detailedAddress)
            },
            // 返回已选择的行业信息
            currentIndustry () {
                const newIndustry = this.industryList.length > 0
                    ? this.industryList.filter(value => value.name == this.industry)[0]
                    : this.category
                return newIndustry
            },
            // 返回已选择的经营内容
            currentManagementContent () {
                return this.industryContent.length > 0
                    ? this.industryContent.filter(value => value.name === this.managementContent)[0]
                    : this.categoryContent
            }
        },
        beforeRouteEnter (to, from, next) {
            console.log('beforerouteenter')
            if (from.name === 'tradingRecord') {
                console.log('来自合伙人什么都不做')
                next()
            } else {
                console.log('刷新')
                next(vm => {
                    Object.assign(vm.$data, vm.$options.data())
                    if (vm.$refs.qrDiv) {
                        // 解决二维码重复的问题
                        vm.$refs.qrDiv.innerHTML = ''
                    }
                    if (vm.pageType === ENUMLIST.UPDATEMERCHANT) {
                        vm.initBackFillInfo()
                    } else {
                        vm.initData()
                    }
                })
            }
        },
        watch: {
            defaultDiscount (newValue) {
                if (this.pageType === ENUMLIST.UPDATEMERCHANT && (this.category.id === -1 || this.category.id === 0)) {
                    this.category.id = -2
                    return
                }
                for (let i = 0; i < this.schoolCount; i++) {
                    this.discount.splice(i, 1, newValue)
                }
            },
            material (newValue) {
                if (newValue > 9) {
                    this.dividerShow = false
                }
            },
            schoolCount (newValue, oldValue) {
                if (this.schoolCountFlag === 1) {
                    this.schoolCountFlag = 0
                    return
                }
                for (let i = oldValue; i < this.schoolCount; i++) {
                    this.discount.splice(i, 1, this.defaultDiscount)
                }
            },
            'currentManagementContent.type': function () {
                if (this.pageType === ENUMLIST.UPDATEMERCHANT && this.category.id === -1) {
                    this.category.id = 0
                    return
                }
                if (!this.currentManagementContent || !this.currentManagementContent.type) {
                    return
                }
                
                const data = {
                    type: this.currentManagementContent.type
                }

                this.searchDiscountLimit(data)
            },
            'currentIndustry.type': function (type) {
                if (type !== undefined && ['cy', 'sc', 'shfw', 'canyin', 'shangchao', 'shenghuofuwu'].indexOf(type) !== -1) {
                    this.switchStatus = true
                } else {
                    this.switchStatus = false
                }

                if (this.industryWatch === 0) {
                    this.industryWatch++
                    return
                } else {
                    this.switchChecked = true
                }
                this.managementContent = ''
            },
            // 地址变动的时候计数
            searchAddress () {
                this.fullAddress = `${this.address}/${this.detailedAddress}`
                this.firstShowSchool++
            }
        },
        methods: {
            initData () {
                console.log('添加商家信息页面')
                this.pageType = ENUMLIST.ADDMERCHANT
                // 1. 获取商户id
                api.merchant.generateVenderId({}, res => {
                    if (res && res.result && res.result.code === '0000') {
                        this.merchantId = res.data
                    } else {
                        this.$toast(`错误码${res.result.code}`)
                    }
                })
            },
            // 修改商户信息的回填接口
            initBackFillInfo () {
                console.log('修改商家信息页面')
                this.merchantId = this.$route.params.merchantId
                this.pageType = ENUMLIST.UPDATEMERCHANT

                const data = { merchantId: this.$route.query.merchantId }
                const requestUrl = this.$route.query.staffId ? 'queryAgentMerchantBaseInfo' : 'queryBDMerchantBaseInfo'
                const urlType = this.$route.query.staffId ? 'newBusiness' : 'merchant'
                api[urlType][requestUrl](data, res => {
                    if (res && res.result && res.result.code === '0000') {
                        this.shopName = res.data.name || ''
                        this.shopTel = res.data.phone || ''
                        this.shopOwner = res.data.contacts || ''
                        this.shopOwnerTel = res.data.contactsPhone || ''
                        this.shopOwnerEmail = res.data.email || ''
                        this.merchantAddress.province = res.data.provinceName || ''
                        if (this.merchantAddress.province) {
                            this.schoolWatch = 0
                        }
                        this.merchantAddress.provinceId = res.data.provinceId || ''
                        this.merchantAddress.country = res.data.countyName || ''
                        this.merchantAddress.countryId = res.data.countyId || ''
                        this.merchantAddress.city = res.data.cityName || ''
                        this.merchantAddress.cityId = res.data.cityId || ''
                        this.merchantAddress.town = res.data.townName || ''
                        this.merchantAddress.townId = res.data.townId || 0
                        this.detailedAddress = res.data.address || ''
                        this.avgPrice = res.data.avgCost || 0
                        this.industry = res.data.mainTypeName || ''
                        this.category.name = this.industry
                        if (this.industry) {
                            this.industryWatch = 0
                        }
                        this.defaultDiscount = res.data.discountLimit || 0
                        this.category.id = -1
                        this.category.type = res.data.mainType
                        this.managementContent = res.data.subTypeName || ''
                        this.categoryContent.name = this.managementContent
                        this.categoryContent.type = res.data.subType
                        if (res.data.bindingSchools.length > 0) {
                            this.discount = []
                            this.school = []
                            this.schools = []
                            this.schoolCount = res.data.bindingSchools.length
                            this.schoolCountFlag = 1
                            this.schoolInfoList = res.data.bindingSchools
                            this.schoolInfoList.map(item => {
                                this.school.push(item.schoolName)
                                this.discount.push(item.discountValue / 10)
                                item.isChecked = true
                                this.schools.push(item.schoolId.toString())
                                return item
                            })
                        }
                        // ! 同城新增 学校数据回填
                        const typeShowSchools = ['canyin', 'sc', 'shfw']
                        this.isToSchool = typeShowSchools.includes(this.category.type)
                        this.industry = this.category.name
                        this.switchChecked = res.data.isDeliverySchool
                        // 显示地图与否
                        if (this.merchantAddress.province && this.merchantAddress.city && this.merchantAddress.country) {
                            this.showMap = true
                        } else {
                            this.showMap = false
                        }
                        this.initLocation = true
                        // wgs84转国测局坐标
                        // const wgs84togcj02 = coordtransform.wgs84togcj02(res.data.longitude, res.data.latitude)
                        // // 国测局坐标转百度经纬度坐标
                        // const gcj02tobd09 = coordtransform.gcj02tobd09(wgs84togcj02[0], wgs84togcj02[1])
                        // this.center = { lng: gcj02tobd09[0], lat: gcj02tobd09[1] }
                        const point = {
                            lng: res.data.longitude,
                            lat: res.data.latitude
                        }
                        this.center = this.pointToBd(point)
                        this.gpsLng = res.data.longitude
                        this.gpsLat = res.data.latitude
                        // 经营者手持营业执照和身份证照片
                        const operatorImgListFile = res.data.operatorImgList
                        operatorImgListFile.forEach(value => {
                            const fileItem = {
                                url: imgHost + value.imageUrl,
                                isImage: true
                            }
                            this.operatorImgList.push(fileItem)
                            this.operatorImgFileList = res.data.operatorImgList
                        })
                        // 结算账户授权书照片
                        const settlementAuthImgListFile = res.data.settlementAuthImgList
                        settlementAuthImgListFile.forEach(value => {
                            const fileItem = {
                                url: imgHost + value.imageUrl,
                                isImage: true
                            }
                            this.settlementAuthImgList.push(fileItem)
                            this.settlementAuthImgFileList = res.data.settlementAuthImgList
                        })
                        this.accountVal = res.data.settlementType || 1
                        if (res.data.settlementType === 2) {
                            this.account = '结算非法人'
                            // 身份证信息
                            this.manageName = res.data.operatorInfo.operatorName || ''
                            this.idCard = res.data.operatorInfo.operatorIdCard || ''
                            this.indateVal = res.data.operatorInfo.idCardValidityPeriod || 1
                            if (res.data.operatorInfo.idCardValidityPeriod === 2) {
                                this.indate = '长期'
                                this.endTimeStatus = true
                            } else {
                                this.indate = '固定'
                                this.endTimeStatus = false
                            }
                            // 身份证 起始时间 结束时间 正面 反面
                            this.startTime = res.data.operatorInfo.idCardStartTime || ''
                            this.endTime = res.data.operatorInfo.idCardEndTime || ''
                            const idCardImgFront = {
                                url: imgHost + res.data.operatorInfo.operatorIdCardFrontImage.imageUrl,
                                isImage: true
                            }
                            this.idCardFront.push(idCardImgFront)
                            this.idCardFrontImg.push(res.data.operatorInfo.operatorIdCardFrontImage)
                            const idCardImgBack = {
                                url: imgHost + res.data.operatorInfo.operatorIdCardBackImage.imageUrl,
                                isImage: true
                            }
                            this.idCardBack.push(idCardImgBack)
                            this.idCardBackImg.push(res.data.operatorInfo.operatorIdCardBackImage)
                        } else {
                            this.account = '结算同法人'
                        }
                        // 查询最低折扣
                        this.searchDiscountLimit({ type: this.categoryContent.type })
                    } else {
                        this.$toast(res.result.info)
                    }
                })

                // ? 获取相册信息 1 店铺log 2 店内环境 4 资质类型 11 头图
                const datas = [
                    {
                        merchantId: this.merchantId,
                        type: 11,
                        name1: 'head',
                        name2: 'headFileList'
                    },
                    {
                        merchantId: this.merchantId,
                        type: 1,
                        name1: 'logo',
                        name2: 'logoFileList'
                    },
                    {
                        merchantId: this.merchantId,
                        type: 2,
                        name1: 'env',
                        name2: 'envFileList'
                    }
                ]

                for (const i of datas) {
                    api.merchant.queryBDMerchantAlbumInfo(i, res => {
                        if (res && res.result && res.result.code === '0000') {
                            const envFile = res.data.list
                            if (envFile.length > 0) {
                                envFile.forEach(value => {
                                    const imageObj = {
                                        url: imgHost + value.imgUrl,
                                        isImage: true
                                    }
                                    const submitImageObj = {
                                        categoryType: value.type,
                                        imageUrl: value.imgUrl,
                                        sortOrder: value.orderBy,
                                        tag: value.tag,
                                        venderId: this.merchantId
                                    }
                                    this[i.name1].push(imageObj)
                                    this[i.name2].push(submitImageObj)
                                })
                            }
                        } else {
                            this.$toast(`错误码${res.result.code}`)
                        }
                    })
                }

                const params = {
                    merchantId: this.merchantId,
                    type: 5
                }
                // 请求补充材料
                api.merchant.queryBDMerchantOtherImageAlbumInfo(params, res => {
                    if (res && res.result && res.result.code === '0000') {
                        if (res.data.length > 0) {
                            const otherImages = res.data[0].images
                            if (otherImages.length > 0) {
                                this.material = otherImages.length
                                otherImages.forEach(value => {
                                    const imageObj = {
                                        url: imgHost + value.imgUrl,
                                        isImage: true
                                    }
                                    const submitImageObj = {
                                        categoryType: value.type,
                                        imageUrl: value.imgUrl,
                                        sortOrder: value.orderBy,
                                        tag: value.tag,
                                        venderId: this.merchantId
                                    }
                                    this.other.push(imageObj)
                                    this.otherFileList.push(submitImageObj)
                                })
                            }
                        }
                    } else {
                        this.$toast(`错误码${res.result.code}`)
                    }
                })
            },
            /**
             *  创建商户接口 / 更新商户信息
             */
            submit () {
                const bindingSchoolList = []
                if (!this.defaultDiscount) {
                    this.$dialog.alert({
                        message: '请选择经营内容'
                    })
                    return
                } else if (this.schoolInfoList.length > 0) {
                    // 折扣值有的的时候
                    this.schoolInfoList.map(item => {
                        if (item.isChecked) {
                            item.venderId = this.merchantId
                            item.discountValue = this.defaultDiscount * 10 || 0
                            // 坐标点转84
                            const newPoint = this.pointToBS({
                                lat: item.latitude,
                                lng: item.longitude
                            })
                            item.latitude = newPoint.lat
                            item.longitude = newPoint.lng
                            bindingSchoolList.push(item)
                        }
                        return item
                    })

                    console.log('schoolInfoList:', this.schoolInfoList)
                    console.log('schoolList:', this.schoolList)

                    if (bindingSchoolList.length === 0) {
                        this.$dialog.alert({
                            message: '当前未勾选学校'
                        })
                        return
                    }
                } else {
                    this.$dialog.alert({
                        message: '当前地址无学校，请重新选择'
                    })
                    return
                }

                if (!this.validate()) {
                    return ''
                }

                // BD 坐标转 84
                const newBSPoint = this.pointToBS({
                    lat: this.merchantLat,
                    lng: this.merchantLng
                })
                // 接口入参整理
                const param = {
                    envImages: this.envFileList,
                    logoImages: this.logoFileList,
                    otherImages: this.otherImgFileList,
                    headImages: this.headFileList,
                    operatorImgList: this.operatorImgFileList,
                    settlementAuthImgList: this.settlementAuthImgFileList,
                    bindingSchools: bindingSchoolList,
                    vender: {
                        address: this.detailedAddress,
                        avgPrice: String(this.avgPrice),
                        categoryMainName: this.currentIndustry.name,
                        categoryMainType: this.currentIndustry.type,
                        categoryMainLev2Name: this.currentManagementContent.name,
                        categoryMainLev2Type: this.currentManagementContent.type,
                        contacts: this.shopOwner,
                        contactsPhone: this.shopOwnerTel,
                        counselor: (this.currentErp = getUrlString('sid') || JME.getUserNameForCookie()),
                        venderLng: newBSPoint.lng,
                        venderLat: newBSPoint.lat,
                        venderId: this.merchantId,
                        venderPhone: this.shopTel,
                        venderName: encodeURIComponent(this.shopName),
                        provinceName: this.merchantAddress.province,
                        provinceId: this.merchantAddress.provinceId,
                        cityId: this.merchantAddress.cityId,
                        cityName: this.merchantAddress.city,
                        countyId: this.merchantAddress.countryId,
                        countyName: this.merchantAddress.country,
                        townId: this.merchantAddress.townId || 0,
                        version: 0,
                        townName: this.merchantAddress.town,
                        settlementType: this.accountVal,
                        discount: this.defaultDiscount * 10
                    }
                }

                if (['cy', 'sc', 'shfw', 'canyin', 'shangchao', 'shenghuofuwu'].indexOf(this.currentIndustry.type) !== -1) param.vender.isDeliverySchool = this.switchChecked

                // 当 为非法人 时
                const param2 = {
                    operatorInfo: {
                        operatorIdCardFrontImage: this.idCardFrontImg[0],
                        operatorIdCardBackImage: this.idCardBackImg[0],
                        operatorName: this.manageName,
                        operatorIdCard: this.idCard,
                        operatorIdCardValidityPeriod: this.indateVal,
                        operatorIdCardStartTime: this.startTime,
                        operatorIdCardEndTime: this.endTime
                    }
                }

                if (this.$route.query.staffId) {
                    // ? 路由传过来有 staffId 的情况 将staffId 传入到 counselor 中
                    param.vender.counselor = this.$route.query.staffId
                    param.vender.bindType = 1
                    param.vender.agentName = decodeURI(this.$route.query.userName)
                }
                // 如果是非法人结算
                if (this.accountVal === 2) Object.assign(param, param2)
                
                console.log('param:', param)

                if (this.pageType === ENUMLIST.ADDMERCHANT) {
                    const requestUrl = this.$route.query.staffId ? 'createAgentVender' : 'createBdVender'
                    const urlType = this.$route.query.staffId ? 'newBusiness' : 'merchant'
                    api[urlType][requestUrl](param, res => {
                        if (res && res.result && res.result.code === '0000') {
                            this.searchQR()
                        } else {
                            this.$toast(res.result.info)
                        }
                    })
                } else {
                    const requestUrl = this.$route.query.staffId ? 'updateAgentVender' : 'updateBdVender'
                    const urlType = this.$route.query.staffId ? 'newBusiness' : 'merchant'
                    api[urlType][requestUrl](param, res => {
                        if (res && res.result && res.result.code === '0000') {
                            this.$router.replace(`/merchantDetails/${this.merchantId}/9999`)
                        } else {
                            this.$toast(res.result.info)
                        }
                    })
                }
            },
            // 查找二维码
            searchQR () {
                this.qrShow = true
                this.$nextTick(this.createQRode)
            },
            // 创建二维码
            createQRode () {
                if (this.qrCode) {
                    return
                }
                this.currentErp = getUrlString('sid') || JME.getUserNameForCookie()
                const p = this.$route.query.staffId
                    ? {
                        erp: this.$route.query.staffId,
                        merchantId: this.merchantId,
                        settlementType: this.accountVal,
                        bindType: 1
                    }
                    : {
                        erp: this.currentErp,
                        merchantId: this.merchantId,
                        settlementType: this.accountVal,
                        bindType: 2
                    }
                
                this.qrCode = new QRCode(this.$refs.qrDiv, {
                    text: JSON.stringify(p),
                    colorDark: '#333333', // 二维码颜色
                    colorLight: '#fff',
                    width: 180,
                    height: 180,
                    correctLevel: QRCode.CorrectLevel.M // 容错率，L/M/H
                })
            },
            // 时间格式化
            dataFormat () {
                const date = new Date()
                return (
                    `${date.getFullYear()}.${date.getMonth() + 1}.${date.getDate()}`
                )
            },
            // ! 校验
            validate () {
                const reg3 = /^1(3|4|5|6|7|8|9)\d{9}$/g

                if (this.shopOwnerTel && !reg3.test(this.shopOwnerTel)) {
                    this.$toast('请填写11位有效的手机号')
                    return false
                } else if (Number(this.avgPrice) < 0) {
                    this.$toast('请填写正确的平均价格 平均价格大于等于0')
                    return false
                } else if (!this.shopName) {
                    this.$dialog.alert({
                        message: '请填入商户名'
                    })
                    return false
                } else if (!validatorSpace(this.shopName)) {
                    this.$dialog.alert({
                        message: '请填入正确格式的商户名'
                    })
                    return false
                } else if (!this.shopOwner) {
                    this.$dialog.alert({
                        message: '请填入店铺负责人'
                    })
                    return false
                } else if (!validatorPhone(this.shopOwnerTel)) {
                    this.$dialog.alert({
                        message: '请输入负责人11位有效电话'
                    })
                    return false
                } else if (!this.address) {
                    this.$dialog.alert({
                        message: '请选择店铺所在地'
                    })
                    return false
                } else if (!this.detailedAddress) {
                    this.$dialog.alert({
                        message: '请输入详细地址'
                    })
                    return false
                } else if (!validatorSpace(this.detailedAddress)) {
                    this.$dialog.alert({
                        message: '请输入正确格式的详细地址'
                    })
                    return false
                } else if (!this.industry) {
                    this.$dialog.alert({
                        message: '请选择行业资质'
                    })
                    return false
                } else if (!this.managementContent) {
                    this.$dialog.alert({
                        message: '请选择经营内容'
                    })
                    return false
                } else if (!this.avgPrice || this.avgPrice <= 0) {
                    this.$dialog.alert({
                        message: '人均价格需大于0'
                    })
                    return false
                } else if (!this.account) {
                    this.$dialog.alert({
                        message: '请选择结算类型'
                    })
                    return false
                } else if (this.shopTel && !validatorTel(this.shopTel)) {
                    this.$dialog.alert({
                        message: '请填写正确的手机号或座机号'
                    })
                    return false
                } else if (!this.merchantLng || !this.merchantLat) {
                    this.$dialog.alert({
                        message: '经纬度获取失败 请重新填写地址'
                    })
                    return false
                } else if (this.envFileList.length < 1 || this.logoFileList.length < 1 || this.headFileList.length < 1) {
                    this.$dialog.alert({
                        message: '展示头图、门脸图、店内环境图片不能为空'
                    })
                    return false
                } else if (this.accountVal === 2 && this.idCardFrontImg.length !== 1) {
                    console.log(this.idCardFront.length)
                    this.$dialog.alert({
                        message: '请上传收款人身份证信息面'
                    })
                    return false
                } else if (this.accountVal === 2 && this.idCardBackImg.length !== 1) {
                    this.$dialog.alert({
                        message: '请上传收款人身份证国徽面'
                    })
                    return false
                } else if (this.accountVal === 2 && this.operatorImgFileList.length < 1) {
                    this.$dialog.alert({
                        message: '请上传收款人手持营业执照和身份证照片'
                    })
                    return false
                } else if (this.accountVal === 2 && this.settlementAuthImgFileList.length < 1) {
                    this.$dialog.alert({
                        message: '请上传结算账户授权书照片'
                    })
                    return false
                } else if (this.accountVal === 2 && !this.manageName) {
                    this.$dialog.alert({
                        message: '请填写收款人姓名'
                    })
                    return false
                } else if (!validatorSpace(this.manageName)) {
                    this.$dialog.alert({
                        message: '请填写正确格式的收款人姓名'
                    })
                    return false
                } else if (this.accountVal === 2 && !validatorIdCard(this.idCard)) {
                    this.$dialog.alert({
                        message: '请填写有效的收款人身份证号码'
                    })
                    return false
                } else if (this.accountVal === 2 && !this.indate) {
                    this.$dialog.alert({
                        message: '请填选择证件有效期类型'
                    })
                    return false
                } else if (this.accountVal === 2 && !this.startTime) {
                    this.$dialog.alert({
                        message: '请填写身份证起始有效期'
                    })
                    return false
                } else if (this.accountVal === 2 && (!this.endTime && this.indateVal !== 2)) {
                    this.$dialog.alert({
                        message: '请填写身份证结束有效期'
                    })
                    return false
                } else if (this.endTime && this.startTime) {
                    if (this.getNum(this.startTime) >= this.getNum(this.endTime)) {
                        this.$dialog.alert({
                            message: '身份证起始有效期应小于身份证结束有效期'
                        })
                        return false
                    }
                }
                return true
            },
            // 地址选择事件
            distPickerSelect (address) {
                this.distPickerClose()
                this.merchantAddress = {
                    city: address.city ? address.city : '',
                    cityId: address.cityId ? address.cityId : '',
                    country: address.country ? address.country : '',
                    countryId: address.countryId ? address.countryId : '',
                    province: address.province ? address.province : '',
                    provinceId: address.provinceId ? address.provinceId : '',
                    town: address.town ? address.town : '',
                    townId: address.townId ? address.townId : 0
                }
                this.showMap = true
                this.initLocation = true
            },
            /**
            *  选择学校接口
            *  根据详细地址及省市获取经纬度
            *  merchantLng 经度 merchantLat 纬度
            */
            chooseSchool () {
                this.schoolInfoList = []
                if (this.address || this.detailedAddress) {
                    const point = {
                        lng: this.merchantLng,
                        lat: this.merchantLat
                    }
                    // const newPoint = this.pointToBS(point)
                    const newPoint = point
                    const data = {
                        latitude: newPoint.lat,
                        longitude: newPoint.lng,
                        distance: 5000
                    }

                    if (this.$route.query.lng && this.$route.query.lat) {
                        data.latitude = this.$route.query.lat 
                        data.longitude = this.$route.query.lng
                        this.center = {
                            lng: this.$route.query.lng,
                            lat: this.$route.query.lat
                        }
                        this.merchantLng = this.$route.query.lng
                        this.merchantLat = this.$route.query.lat
                    }
                    api.merchant.queryBDSchoolInfoListByCoordinate(data, res => {
                        if (res && res.result && res.result.code === '0000') {
                            this.schoolList = res.data.list
                            // console.log('schoolList:', res.data.list)
                            // console.log('firstShowSchool:', this.firstShowSchool)
                            if (this.schools.length > 0 && (this.firstShowSchool <= 1)) {
                                // 编辑的时候 回来的是 84 坐标
                                console.log('编辑')
                                this.schoolList.forEach(value => {
                                    const newObject = { ...value }
                                    newObject.discount = this.discountValue / 10
                                    if (this.schools.indexOf(value.schoolId) > -1) { 
                                        newObject.isChecked = true
                                    } else {
                                        newObject.isChecked = false
                                    }
                                    // const point1 = {
                                    //     lng: value.longitude,
                                    //     lat: value.latitude
                                    // }
                                    // const newPoint1 = this.pointToBS(point1)
                                    // value.longitude = newPoint1.lng
                                    // value.latitude = newPoint1.lat
                                    this.schoolInfoList.push(newObject)
                                })
                            } else if (this.schoolList.length > 0) {
                                // 新增的时候是 百度坐标
                                console.log('新增')
                                this.schoolList.forEach(value => {
                                    const newObject = { ...value }
                                    newObject.discount = this.discountValue / 10
                                    newObject.isChecked = true
                                    // const point1 = {
                                    //     lng: value.longitude,
                                    //     lat: value.latitude
                                    // }
                                    // const newPoint1 = this.pointToBS(point1)
                                    // value.longitude = newPoint1.lng
                                    // value.latitude = newPoint1.lat
                                    this.schoolInfoList.push(newObject)
                                })
                            } else {
                                // 当前地址无学校，请重新选择
                                this.$dialog.alert({
                                    message: '当前地址无学校，请重新选择'
                                })
                                // 关闭软键盘
                                document.activeElement.blur()
                            }
                        }
                    })
                } else {
                    this.$dialog.alert({
                        message: '请先选择地址'
                    })
                    return ''
                }
            },
            /**
            *  显示选择行业资质弹窗 设置弹窗标题与弹窗类型,置空选项数组 从接口获取数据
            *  为选项和行业类型字段填充数据
            */
            chooseIndustry () {
                this.popupTitleQualification = '请选择行业资质'
                this.flag = 'industry'
                this.itemsQualification = []

                const data = {}
                api.merchant.queryBDMerchantTypeList(data, res => {
                    if (res.result && res.result.code === '0000') {
                        const industryList = res.data.list
                        industryList.forEach(value => {
                            this.industryList.push(value)
                            this.itemsQualification.push(value.name)
                        })
                    }
                }, error => {
                    console.log(error)
                })
                this.showPopup = true
            },
            /**
            *  显示经营内容弹窗 设置弹窗标题 置空选项数组 从接口获取数据
            *  为经营内容字段和选项填充数据
            */
            chooseContent () {
                this.flag = 'managementContent'
                this.popupTitleQualification = '请选择经营内容'
                this.itemsQualification = []
                console.log(this.currentIndustry)
                if (!this.currentIndustry.type) {
                    this.$dialog.alert({
                        message: '请先选择行业资质'
                    })
                    return ''
                }

                const data = { type: this.currentIndustry.type }
                api.merchant.queryBDMerchantBusinessRange(data, res => {
                    if (res.result && res.result.code === '0000') {
                        // console.log('请求行业资质成功')
                        const industryContent = res.data.list
                        industryContent.forEach(value => {
                            this.itemsQualification.push(value.name)
                            this.industryContent.push(value)
                        })
                    } else {
                        this.$toast(`错误码${res.result.code}`)
                    }
                })
                this.showPopup = true
            },
            /**
            * 新增 非法人结算选择
            */
            chooseAccount () {
                if (this.updateMerchantPage) return
                this.popupTitleQualification = '请选择结算类型'
                this.flag = 'account'
                this.itemsQualification = []
                this.itemsQualification = ['结算同法人', '结算非法人']
                this.accountList = [
                    { name: '结算同法人', value: 1 },
                    { name: '结算非法人', value: 2 }
                ]
                this.defaultIndexQualification = 0
                this.showPopup = true
            },
            /**
            * 新增 有效期选择
            */
            chooseDate () {
                this.popupTitleQualification = '请选择有效期类型'
                this.flag = 'indate'
                this.itemsQualification = []
                this.itemsQualification = ['固定', '长期']
                this.indateList = [
                    { name: '固定', value: 1 },
                    { name: '长期', value: 2 }
                ]
                this.defaultIndexQualification = 0
                this.showPopup = true
            },
            /**
            * 点击弹窗确认按钮  根据不同的弹窗类型 走不同的处理逻辑
            * discount  显示折扣列表 折扣数值为0-10
            * industry  行业资质弹窗
            * managementContent 经营内容弹窗
            * default 学校弹窗处理
            * @param checked
            * @return {*}
            */
            onConfirm (checked) {
                switch (this.flag) {
                    case 'industry':
                        // 选择所属行业
                        this.industryHandle(checked)
                        break
                    case 'managementContent':
                        this.industryContentHandle(checked)
                        break
                    case 'account':
                        this.accountHandle(checked)
                        break
                    case 'indate':
                        this.indateHandle(checked)
                        break
                    // 非以上几项全部按选择的学校处理
                    default:
                        break
                }
                this.showPopup = false
                return checked
            },
            // 选择所属行业
            industryHandle (checked) {
                this.industry = checked
            },
            // 选择经营内容的处理逻辑 查最低折扣
            industryContentHandle (checked) {
                if (Array.isArray(checked) && checked.length < 1) {
                    this.managementContent = null
                } else {
                    this.managementContent = checked
                }
            },
            // 选择结算类型
            accountHandle (checked) {
                this.accountList.map(item => {
                    if (item.name === checked) {
                        this.accountVal = item.value
                    }
                    return item
                })
                this.account = checked
            },
            // 选择身份证有效期类型
            indateHandle (checked) {
                this.indateList.map(item => {
                    if (item.name === checked) {
                        this.indateVal = item.value
                    }
                    return item
                })
                // 当选择长期则禁用 endtime
                if (this.indateVal === 2) {
                    this.endTimeStatus = true
                } else {
                    this.endTimeStatus = false
                }
                this.indate = checked
            },
            // 获取 环境 logo  补充材料的图片信息
            setFileList (type, files) {
                switch (type) {
                    case 1:
                        this.logoFileList = files
                        break
                    case 2:
                        this.envFileList = files
                        break
                    case 3:
                        this.otherImgFileList = files
                        break
                    case 4:
                        this.operatorImgFileList = files
                        break
                    case 5:
                        this.settlementAuthImgFileList = files
                        break
                    case 11:
                        this.headFileList = files
                        break
                    default:
                        // this.licenceFileList.splice(type - 4, 1, files)
                        this.headFileList = files
                        break
                }
            },
            // 获取图片url
            getImgList (type, files) {
                switch (type) {
                    case 'front':
                        this.idCardFrontImg = files
                        break
                    case 'back':
                        this.idCardBackImg = files
                        break
                    case 'hand':
                        this.idCardHandImg = files
                        break
                    default:
                        break
                }
            },
            // 获取身份证信息
            getIdCardInfo (type, data) {
                switch (type) {
                    case 'front':
                        this.manageName = data.name
                        this.idCard = data.cardNo
                        break
                    case 'back':
                        console.log('getIdCardInfo', data)
                        this.startTime = data.singDateStr
                        this.endTime = data.expirationDateStr
                        this.itemsQualification = []
                        this.itemsQualification = ['固定', '长期']
                        this.indateList = [
                            { name: '固定', value: 1 },
                            { name: '长期', value: 2 }
                        ]
                        this.defaultIndexQualification = data.idCardValidityPeriod
                        this.indateVal = data.idCardValidityPeriod || 1
                        if (data.idCardValidityPeriod === 2) {
                            this.indate = '长期'
                            this.endTimeStatus = true
                            this.endTime = ''
                        } else {
                            this.indate = '固定'
                            this.endTimeStatus = false
                        }
                        break
                    default:
                        break
                }
            },
            // 显示地址列表
            chooseShopAddress () {
                this.distPickerShowFlag = true
            },
            // 关闭地址列表
            distPickerClose () {
                this.distPickerShowFlag = false
            },
            // 获取字符串上的所有数字
            getNum (str) {
                const num = str.replace(/[^0-9]/ig, '')
                return num
            },
            // 显示 保存图片弹窗
            showImgTemplate () {
                this.showSaveImgPopup = true
            },
            // touch start
            touchStart () {
                // 手指触摸
                clearTimeout(this.timer)
                this.timer = setTimeout(() => {
                    const options = {
                        downloadUrl: '//m.360buyimg.com/yocial/jfs/t1/99206/40/17208/1252468/5e843a7fE2c25409c/d4179d40a3be1f96.jpg',
                        // filePath: 'localhost://127.0.0.1/webapp/0.0.4.2/Doc.md',
                        name: '授权书模板',
                        // size: 29708,
                        type: 'jpg',
                        // saveTypeList: 'typeList',
                        callback (res) {
                            console.log('保存成功!', res)
                        }
                    }
                    /* eslint-disable */
                    jme.file.saveFile(options)
                    /* eslint-enable */
                }, 400)
            },
            // touch end
            touchEnd () {
                clearTimeout(this.timer)
            },
            // 展示时间选择组件
            showDatePicker (type) {
                if (type == 1) {
                    this.minDate = new Date(1990, 1, 1)
                    this.maxDate = new Date(dayjs().format('YYYY-MM-DD'))
                    this.dateType = 1
                    this.showPicker = true
                } else if (type == 2) {
                    this.minDate = new Date(dayjs().format('YYYY-MM-DD'))
                    this.maxDate = new Date(2050, 12, 31)
                    this.dateType = 2
                    this.showPicker = true
                }
            },
            // 时间选择
            onTimeConfirm (value) {
                if (this.dateType == 1) {
                    this.startTime = dayjs(value).format('YYYY-MM-DD')
                } else if (this.dateType == 2) {
                    this.endTime = dayjs(value).format('YYYY-MM-DD')
                }
                this.showPicker = false
            },
            // 新增跳转前
            goMapBefore () {
                this.goMapTime1 = new Date().getTime()
            },
            // 跳转地图页面
            goMap () {
                this.goMapTime2 = new Date().getTime()
                if (this.goMapTime2 - this.goMapTime1 < 300) this.showFullMap = true
            },
            // 点击地图
            clickMap () {
                this.showFullMap = true
            },
            // 返回坐标点
            returnPoint (val) {
                // 组件根据地质 搜索出来的 坐标 中心点
                this.merchantLng = val.Lng
                this.merchantLat = val.Lat
                this.fullCenter = {
                    lng: val.Lng,
                    lat: val.Lat
                }
                this.changePoint = this.fullCenter
                this.chooseSchool()
            },
            // 返回学校数据
            returnSchoolList (val) {
                this.schoolInfoList = val
            },
            // 关联学校 warning 按钮
            clickSchoolWarning () {
                this.schoolWarning = true
            },
            // 关联学校 按钮确定
            confirmClick () {
                this.schoolWarning = false
            },
            // 拖拽地图定位后的 位置回填
            dragendPoint (val) {
                this.firstShowSchool++
                // 拖拽点回填
                this.showFullMap = false
                this.merchantLng = val.lng
                this.merchantLat = val.lat
                this.changePoint = {
                    lng: val.lng,
                    lat: val.lat
                }
                console.log('changePoint:', this.changePoint)
                this.center = val
                this.chooseSchool()
            },
            // 关闭 map 弹窗
            closeMapEvent (val) {
                this.showFullMap = val
            },
            // 是否需要到校 
            switchChange (val) {
                this.switchChecked = val
            },
            // 84 坐标转 百度坐标
            pointToBd (point) {
                // wgs84转国测局坐标
                const wgs84togcj02 = coordtransform.wgs84togcj02(point.lng, point.lat)
                // 国测局坐标转百度经纬度坐标
                const gcj02tobd09 = coordtransform.gcj02tobd09(wgs84togcj02[0], wgs84togcj02[1])
                const newPoint = {
                    lng: gcj02tobd09[0],
                    lat: gcj02tobd09[1]
                }
                return newPoint
            },
            // 百度 坐标转 84 坐标
            pointToBS (point) {
                const bd09togcj02 = coordtransform.bd09togcj02(point.lng, point.lat)
                // 国测局坐标转wgs84坐标
                const gcj02towgs84 = coordtransform.gcj02towgs84(bd09togcj02[0], bd09togcj02[1])
                const newPoint = {
                    lng: gcj02towgs84[0],
                    lat: gcj02towgs84[1]
                }
                return newPoint
            },
            // 跳转关联合伙人
            jumpTrading () {
                if (this.$route.query.staffId) {
                    this.$router.push({
                        name: 'tradingRecord',
                        path: '/tradingRecord',
                        query: {
                            staffId: this.$route.query.staffId, 
                            shopId: this.merchantId
                        }
                    })
                } else {
                    this.$router.push({
                        name: 'tradingRecord',
                        path: '/tradingRecord',
                        query: {
                            // staffId: this.$route.query.staffId, 
                            shopId: this.merchantId
                        }
                    })
                }
            },
            // 查询最低折扣方法
            searchDiscountLimit (data) {
                api.merchant.queryBDMerchantBusinessDiscountLimit(data, res => {
                    this.defaultDiscount = res.data.discountLimit / 10 || 100
                }, () => {
                    console.log('查询最低折扣失败')
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
$lh: 0.2rem;
/deep/ .van-dropdown-menu__title--active, /deep/.van-dropdown-item__option--active {
    color: #F0250F;
}
.submit {
    height: auto;
    color: #848484;
    background-color: white;
    font-size: .14rem;
    text-align: center;
    padding: .1rem .12rem .20rem .12rem;
    margin-top: 0.12rem;

    .btn {
        width: 100%;
        height: .4rem;
        border: .01rem solid #F0250F;
        border-radius: .3rem;
        color: white;
        background: linear-gradient(270deg,rgb(222,49,33) 0%,rgb(236,86,42) 100%);
    }

    .btn {
        width: 100%;
        height: 0.4rem;
        border: 0.01rem solid #f0250f;
        border-radius: 0.3rem;
        color: white;
        background: linear-gradient(
            270deg,
            rgb(222, 49, 33) 0%,
            rgb(236, 86, 42) 100%
        );
    }

    .btn:active {
        opacity: 0.8;
    }
}

/deep/ .label-style {
    font-size: 0.15rem;
}

/deep/.van-cell:not(:last-child)::after {
    left: 0rem;
}
.upload_block {
    // margin: 0rem 0rem 0.16rem 0rem;

    .group-title {
        box-sizing: border-box;
        width: 100%;
        height: 0.5rem;
        font-size: 0.15rem;
        line-height: 0.18rem;
        font-weight: 400;
        color: #848484;
        background-color: #F5F8FC;
        display: flex;
        align-items: center;
        padding-left: 0.12rem;
        display: flex;
        align-items: center;

        .group-icon {
            display: flex;
            align-items: center;
            font-size: 0.15rem;
            line-height: 0.18rem;
            color: #F0250F;
            margin-left: 0.08rem;

            /deep/ .van-icon-warning-o {
                font-size: 0.15rem;
                line-height: 0.18rem;
            }
        }
    }

    .field-container {
        box-sizing: border-box;
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        // padding-left: 0.08rem;

        .field-icon {
            font-size: 0.15rem;
            line-height: 0.18rem;
            color: #F0250F;
        }
    }
}

.desc_title {
    font-size: 0.16rem;
    color: #2d2d2d;
    height: $lh;
    margin: 0.16rem 0.12rem 0.16rem 0.12rem;

    .desc_title_left {
        width: 50%;
        line-height: $lh;
        text-align: left;
        float: left;
    }

    .desc_title_right {
        width: 50%;
        line-height: $lh;
        text-align: right;
        float: left;
        .van_icon {
            position: relative;
            top: 0.02rem;
        }
    }
}

/deep/ .van-cell {
    font-size: 0.15rem;
    padding: 0.1rem 0.12rem;
}

.submitBtn {
    width: 3.43rem;
    height: 0.45rem;
    background: rgb(0, 130, 110);
    border-radius: 0.3rem;
    border: 0rem;
    text-align: center;
    font-size: 0.18rem;
    color: white;
}

.submitBtn:active {
    opacity: 0.8;
}

.qr_style {
    width: 2.7rem;
    height: auto;
    background: white;
    font-size: 0.15rem;
    border-radius: 0.06rem;

    .title {
        font-size: 0.18rem;
        color: #2e2d2d;
        font-weight: 500;
        text-align: center;
    }

    .qr_content {
        width: 100%;
        height: auto;
        display: flex;
        justify-content: center;

        img {
            width: 100%;
            height: 100%;
        }
    }

    .foot {
        font-size: 0.14rem;
        text-align: center;
        color: #2e2d2d;
    }
}

.desc_title {
    font-size: 0.15rem;
    color: #000000;
    height: $lh;

    .desc_title_left {
        width: 50%;
        line-height: $lh;
        text-align: left;
        float: left;
    }

    .desc_title_right {
        width: 50%;
        line-height: $lh;
        text-align: right;
        float: left;
        color: #f0250f;

        .van_icon {
            margin-bottom: 0.03rem;
        }
    }
}

.download-box {
    margin-top: 0.12rem;
    position: relative;
    height: 0.72rem;
    text-align: center;
    // line-height: 0.6rem;
    font-size: 0.15rem;
    font-weight: 900;
    color: rgba(0,0,0,1);

    .download-title {
        padding-top: 0.18rem;
        margin-bottom: 0.08rem;
        font-size: 0.15rem;
        line-height: 0.15rem;
        font-weight: 600;
        color: #F0250F;
    }

    .download-text {
        font-size: 0.13rem;
        line-height: 0.13rem;
        font-weight: 400;
        color: #F0250F;
    }

    .arrows-box {
        position: absolute;
        top: 0.24rem;
        right: 0.24rem;
        .arrows-style {
            transform: rotate(90deg);
            color: #F0250F;
            font-size: 0.23rem;
        }
    }
}

.button-download {
    width: 100%;
    height: 100%;
}

.shop-map{
    height:2.07rem;
}
.school-zone{
    padding:0 .16rem;
    
    & h4{
        margin:0;
        font-weight: normal;
        font-size:.13rem;
        color:rgba(127,127,127,1);
        margin:.16rem 0 0;
    }
    &>.scroll-zone{
        max-height: 1.53rem;
        overflow-y: scroll;
    }
    .school-item{
        display: flex;
        align-items: center;
        margin: .16rem 0;
        
        /deep/ .van-checkbox {
            margin: 0;
        }
        /deep/ .van-checkbox__label {
            font-size: 0.13rem;
            color: #000000;
            font-weight: 400;
        }
    }
    
}
/deep/ .van-checkbox {
    margin:.16rem 0;
}
.bm-view{
    height: 2.07rem;
}
.form-item{
    display: flex;
    justify-content: space-between;
    padding: 0.16rem 0.16rem;
    position: relative;
    .label-md{
        color:rgba(0,0,0,.3);
        display: flex;
        align-items: center;
        span{
            margin-right: .08rem;
        }
    }
}
.form-item::after{
   content: '';
   position: absolute;
   width: 100%;
   height: 1px;
   background-color: #ebedf0;
   left: 0;
   bottom: 0;
   transform: scaleY(0.5);
}
.item-cont{
    display: flex;
    align-items: center;
    span{
        margin-right: .08rem;
    }
}
</style>
