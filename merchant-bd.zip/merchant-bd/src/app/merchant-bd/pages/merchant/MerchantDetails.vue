<template>
    <div class="merchant-detail-container">
        <van-cell-group class="upload_block">
            <!-- v1.1 新增 -->
            <div class="group-title">
                店铺信息
            </div>

            <!-- <van-field v-model="storeId"
                label="店铺ID"
                input-align="right"
                readonly
                label-class="label-style"
                label-width="1.65rem"
            >
                <template #button>
                    <van-button size="small" type="primary" @click="copyEvent">复制</van-button>
                </template>
            </van-field> -->

            <div class="merchant-id-box">
                <div class="left-id">店铺ID</div>
                <div class="right-container">
                    <div class="merchant-id">
                        {{this.$route.query.merchantId || this.$route.params.merchantId}}
                    </div>
                    <van-button size="small" type="primary" @click="copyEvent">复制</van-button>
                </div>
            </div>

            <van-field v-model="merchantInfo.name"
                label="店铺名称"
                input-align="right"
                readonly
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
            <van-field v-model="merchantInfo.phone"
                label="店铺电话"
                readonly
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
            <van-field v-model="merchantInfo.contacts"
                label="店铺负责人"
                readonly
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
            <van-field v-model="merchantInfo.contactsPhone"
                label="负责人联系电话"
                readonly
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>

            <!-- BD V1.1 -->
            <van-field
                v-model="account"
                label="结算类型"
                readonly
                label-class="label-style"
                label-width="1.65rem"
                input-align="right"
            >
            </van-field>
        </van-cell-group>

        <!-- 选择行业 -->
        <van-cell-group class="upload_block" :border="false">
            <div class="group-title">
                选择行业
            </div>

            <van-field
                v-model="merchantInfo.mainTypeName"
                label="所属行业"
                readonly
                label-class="label-style"
                label-width="1rem"
                input-align="right"
            >
            </van-field>

            <!-- 同城新需求 -->
            <van-field v-if="switchStatus" name="switch" label="是否开通到校" :label-width="'1rem'">
                <template #input>
                    <div class="field-container">
                        <van-icon class="field-icon" name="warning-o" />
                        <van-switch :disabled="true" v-model="switchChecked" size="20" />
                    </div>
                </template>
            </van-field>

            <van-field
                v-model="merchantInfo.subTypeName"
                label="经营内容"
                readonly
                label-class="label-style"
                label-width="1.65rem"
                input-align="right"
            >
            </van-field>

            <van-field
                type="number"
                v-model="merchantInfo.avgCost"
                label="人均价格"
                placeholder="在此输入人均价格"
                input-align="right"
                label-class="label-style"
                label-width="1.65rem"
            >
            </van-field>
        </van-cell-group>

        <!-- 关联学校 -->
        <van-cell-group class="upload_block" :border="false">
            <div class="group-title">
                <div>关联学校</div>
                <!-- <div class="group-icon" @click="clickSchoolWarning">
                    <van-icon name="warning-o" />
                </div> -->
            </div>

            <van-field
                v-model="address"
                label="店铺所在地"
                input-align="right"
                readonly
                label-class="label-style"
                label-width="1rem"
            >
            </van-field>
            <van-field
                v-model="merchantInfo.address"
                label="具体地址"
                input-align="right"
                label-class="label-style"
                label-width="1rem"
            >
            </van-field>

            <!-- 新增学校 -->
            <school-map 
                v-if="showMap"
                :initLocation="initLocation"
                :center="center"
                :gpsLng="gpsLng"
                :gpsLat="gpsLat"
                :schoolInfoList="schoolInfoList"
                :searchAddress="searchAddress"
                @returnPoint="returnPoint"
                @returnSchoolList="returnSchoolList"
                :disabled="true"
            />
        </van-cell-group>

        <van-cell-group class="upload_block">
            <div class="group-title">
                <div>其他信息</div>
            </div>

            <van-field v-model="albums"
                label="商家相册"
                readonly
                right-icon="arrow"
                label-class="label-style"
                label-width="1rem"
                input-align="right"
                @click="$router.push(`/album/${merchantId}`)"
            >
            </van-field>
            <van-field v-model="NOTEXT"
                label="关联合伙人邀请码"
                readonly
                right-icon="arrow"
                label-class="label-style"
                label-width="1.5rem"
                input-align="right"
                @click="tradingRecord"
            >
            </van-field>
            <van-field
                label="配置白名单"
                readonly
                right-icon="arrow"
                label-class="label-style"
                label-width="1.5rem"
                input-align="right"
                @click="settingWhite"
            >
            </van-field>
        </van-cell-group>

        <div class="group-title-other">
            <div>其他信息</div>
        </div>

        <div class="record">
            <div class="record_iteam "
                :class="activeType === ENUM.ENTRYRECORD ? 'active' : ''"
                @click="getRecord(ENUM.ENTRYRECORD)">
                入驻记录
            </div>
            <div class="record_iteam"
                :class="activeType === ENUM.VISITRECORD ? 'active' : ''"
                @click="getRecord(ENUM.VISITRECORD)"
            >
                访问记录
            </div>
            <div class="record_iteam"
                :class="activeType === ENUM.RECHANGERECORD ? 'active' : ''"
                @click="getRecord(ENUM.RECHANGERECORD)"
            >
                充值记录
            </div>
            <div class="record_iteam"
                :class="activeType === ENUM.TREADERECORD ? 'active' : ''"
                @click="getRecord(ENUM.TREADERECORD)"
            >
                交易记录
            </div>
        </div>

        <van-popup v-model="showPopup"
            position="bottom"
            :style="{ height: '30%' }"
        >
            <van-picker
                show-toolbar
                :title="popupTitleQualification"
                :columns="itemsQualification"
                :default-index="defaultIndexQualification"
                :visible-item-count="visibleItemCountQualification"
                :item-height="itemHeightQualification"
                @cancel="showPopup = false"
                @confirm="onConfirm"
            >
            </van-picker>
        </van-popup>
        <pullDownRefresh @scroll="handleScroll" :threshold="130" style="min-height: 20vh">
            <div v-if="activeType === ENUM.ENTRYRECORD">
                <cell-iteam :one="true"
                    v-for="(item, index) in merchantEnterHistory"
                    :key="index"
                    :date= "item.recordTime | dateFilter"
                    :tipText="item.remark"
                    :name="item.recordContent"
                >
                </cell-iteam>
            </div>
            <div v-if="activeType === ENUM.VISITRECORD">
                <cell-iteam :normal="true"
                    v-for="(item, index) in merchantVisitHistory"
                    :key="index"
                    :name="item.recordContent"
                    :contentTop="item.agentStaff"
                    :contentBottom="item.recordTime|dateFilter"
                >
                </cell-iteam>
            </div>
            <div v-if="activeType === ENUM.RECHANGERECORD">
                <cell-iteam :one="true"
                    v-for="(item, index) in merchantRechargeFlowList"
                    :key="index"
                    :date="item.orderTime | dateFilter"
                    :name="`+ ￥${item.payAmount}`"
                >
                </cell-iteam>
            </div>
            <div v-if="activeType === ENUM.TREADERECORD">
                <cell-iteam :one="true"
                    v-for="(item, index) in merchantRevenueFlowList"
                    :key="index"
                    :date="item.tradeTime | dateFilter"
                    :name="`+ ￥${item.payAmount}`"
                >
                </cell-iteam>
            </div>
        </pullDownRefresh>

        <van-dialog v-model="addRecordShow"
            title="添加访问记录"
            confirm-button-text = '提交'
            confirm-button-color="#F0250F"
            class="vdialog"
            closeOnClickOverlay
            @confirm="addRecordHandle"
        >
            <van-field
                v-model="visitContent"
                type="textarea"
                maxlength="200"
                placeholder="请在此输入访问记录"
                show-word-limit
            />
        </van-dialog>

        <van-popup v-model="qrShow" round>
            <div class="qr_style">
                <p class="title">扫码入驻</p>
                <div ref="qrDiv" class="qr_content"></div>
                <p class="foot">{{qrTimeStamp | dateFilter('YYYY.MM.DD')}}</p>
            </div>
        </van-popup>

        <!-- <div class="submit">
            <button class="btn"  @click="addVisitorRecord">
                添加访问记录
            </button>
            <button class="btn" @click="searchQR">
                查看二维码
            </button>
            <button v-if="isUpdate" class="updateBtn" @click="repairBusinessInfo">
                修改商户信息
            </button>
        </div> -->

        <div class="btn-box">
            <van-button v-if="isUpdate" icon="records" type="primary" class="btn-1" @click="repairBusinessInfo">
            </van-button>

            <van-button type="primary" icon="photo-o" class="btn-2" @click="searchQR">
            </van-button>
        </div>

        <tabbar-btn
            :clickValue="'2'"
            @btnClickValue="addVisitorRecord"
            :custom="true"
        >
            <div class="add-button" :custom="true">
                <div class="add-icon">
                    <van-icon name="plus" style="{margin-right: '0.03rem'}"/>
                </div>

                <div class="add-text">
                    添加访问记录
                </div>
            </div>
        </tabbar-btn>
    </div>
</template>

<script>
    import QRCode from 'qrcodejs2'
    import api from '@/merchant-bd/api/main'
    import coordtransform from 'coordtransform'
    // import alertOverlay from '@components/alertOverlay'
    // 引入 tabbar-btn 组件
    import tabbarBtn from '@/merchant-bd/components/tabbarBtn'
    import { getUrlString } from '@/merchant-bd/utils/tools'
    import JME from '@/merchant-bd/utils/jdme.js'
    import { ENUMLIST } from '../enum'
    import cellIteam from '../layout/iteam'
    import { apiUrl, fetch } from '../../server/getData'
    // 通用弹窗组件
    import pullDownRefresh from '../../components/scroll/pullDownRefresh'
    // 引入地图组件
    import schoolMap from '../widget/schoolMap'

    // 资质上传界面
    export default {
        name: 'MetchantDetail',
        components: {
            cellIteam,
            pullDownRefresh,
            schoolMap,
            // alertOverlay,
            tabbarBtn
        },
        data () {
            return {
                NOTEXT: '',
                qrTimeStamp: '',
                visitContent: '',
                addRecordShow: false,
                activeType: ENUMLIST.ENTRYRECORD,
                albums: '',
                ENUM: ENUMLIST,
                qrBtn: false,
                // 相册相关
                logoFileList: [],
                envFileList: [],
                licenceFileList: [],
                // 学校相关
                school: [],
                discount: [],
                // 控制
                flag: '',
                qrShow: false,
                qrCode: null,
                // 计数
                schoolCount: 2,
                //  popup
                itemHeightQualification: 36,
                visibleItemCountQualification: 3,
                defaultIndexQualification: 1,
                itemsQualification: [],
                showPopup: false,
                popupTitleQualification: '',
                //  表面数据
                enterpriseNameNumber: '',
                enterpriseName: '',
                type: '统一组织代码证号：',
                managementContent: '',
                industry: '',
                shopName: '',
                shopTel: '',
                shopOwner: '',
                shopOwnerTel: '',
                BDErp: '',
                detailedAddress: '',
                address: '',
                // 测试数据
                testDatas: ['中国建设银行', '中国工商银行北京支行', '中国弄农业银行', '中国银行'],
                merchantInfo: {},
                merchantEnterHistory: [],
                merchantVisitHistory: [],
                merchantRechargeFlowList: [], // 充值记录
                merchantRevenueFlowList: [], // 交易记录
                merchantId: '',
                merchantStatus: -2,
                currentErp: '',
                // 是否允许修改商户信息
                isUpdate: false,
                pageSize: 10,
                pageNumber: 1,
                hasMore: true,
                isFetching: false,
                // TODO: BD 商户详情页变更
                storeId: 'id123456',
                account: '结算法人',
                switchStatus: true,
                switchChecked: true,
                avgPrice: 100,
                showMap: false,
                initLocation: false,
                center: {},
                gpsLng: 116.403963,
                gpsLat: 39.915119,
                schoolInfoList: [],
                // 经度0-180
                merchantLng: '',
                // 维度 0-90
                merchantLat: '',
                fullCenter: {},
                schools: []
            }
        },
        created () {
            this.currentErp = getUrlString('sid') || JME.getUserNameForCookie() //
            this.merchantId = this.$route.params.merchantId
            this.merchantStatus = Number(this.$route.params.status)

            if (this.merchantStatus === 1
                || this.merchantStatus === 3
                || this.merchantStatus === 22
                || this.merchantStatus === 23
                || this.merchantStatus === 32) {
                this.isUpdate = true
            } else {
                this.isUpdate = false
            }
            if (this.school.length) {
                // console.log('true')
            } else {
                // console.log('false')
            }
            this.queryBDMerchantBaseInfo().then(() => {
                const a = this.getFullAddress()
                this.address = a || ''
            })
            this.loadData()
        },
        computed: {
            searchAddress () {
                return (this.address || '') + (this.merchantInfo.address || '')
            }
        },
        watch: {
            searchAddress (val) {
                if (val) {
                    this.showMap = true
                    this.initLocation = true
                }
            }
        },
        methods: {
            loadData () {
                if (this.activeType == ENUMLIST.ENTRYRECORD) {
                    // this.merchantEnterHistory = []
                    this.searchBDRecordByType(1)
                } else if (this.activeType == ENUMLIST.VISITRECORD) {
                    // this.merchantVisitHistory = []
                    this.searchBDRecordByType(2)
                } else if (this.activeType == ENUMLIST.RECHANGERECORD) {
                    console.log('充值记录')
                    this.queryBDMerchantRechargeFlowList()
                } else if (this.activeType == ENUMLIST.TREADERECORD) {
                    console.log('交易记录')
                    this.queryBDMerchantRevenueFlowList()
                }
            },
            queryBDMerchantBaseInfo () {
                const requestUrl = this.$route.query.staffId ? apiUrl.queryAgentMerchantBaseInfo : apiUrl.queryBDMerchantBaseInfo
                return fetch.post({
                    url: requestUrl,
                    data: {
                        merchantId: this.merchantId
                    }
                }, res => {
                    if (res.result && res.result.code === '0000') {
                        res.data.bindingSchools.forEach(item => {
                            this.schools.push(item.schoolId.toString())
                        })
                        this.merchantInfo = res.data
                        // 新增
                        this.schoolInfoList = res.data.bindingSchools.map(item => {
                            item.isChecked = true
                            return item
                        })
                        
                        if (res.data.settlementType === 2) {
                            this.account = '结算非法人'
                        } else {
                            this.account = '结算法人'
                        }

                        localStorage.setItem('settlementType', JSON.stringify(res.data.settlementType))
                        
                        if (res.data.operatorImgList.length > 0) {
                            localStorage.setItem('operatorImgList', JSON.stringify(res.data.operatorImgList))
                        }
                        if (res.data.settlementAuthImgList.length > 0) {
                            localStorage.setItem('settlementAuthImgList', JSON.stringify(res.data.settlementAuthImgList))
                        }
                        if (JSON.stringify(res.data.operatorInfo) !== '{}') {
                            localStorage.setItem('operatorInfo', JSON.stringify(res.data.operatorInfo))
                        }
                    } else {
                        // this.goToPage(ENUMLIST.PROFESSIONAL)
                        this.$toast(res.result.info)
                    }
                }, res => {
                    console.log(res)
                })
            },
            // 查询商户的历史记录
            searchBDRecordByType (type) {
                this.isFetching = true
                const data = {
                    venderId: this.merchantId,
                    recordType: type,
                    currentPage: this.pageNumber,
                    size: this.pageSize,
                    agentOrganId: type === 1 ? null : JSON.parse(localStorage.getItem('organId'))
                }
                
                return fetch.get({
                    url: apiUrl.searchBDRecordByType,
                    data
                }, res => {
                    this.isFetching = false
                    if (res.result && res.result.code === '0000') {
                        if (type == 1) {
                            if (!res.data || res.data.length < this.pageSize) {
                                this.hasMore = false
                            }
                            this.pageNumber++
                            this.merchantEnterHistory = this.merchantEnterHistory.concat(res.data ? res.data : [])
                        } else if (type == 2) {
                            if (!res.data || res.data.length < this.pageSize) {
                                this.hasMore = false
                            }
                            this.pageNumber++
                            this.merchantVisitHistory = this.merchantVisitHistory.concat(res.data ? res.data : [])
                        }
                    } else {
                        // this.goToPage(ENUMLIST.PROFESSIONAL)
                        this.$toast(res.result.info)
                    }
                }, res => {
                    console.log(res)
                    this.isFetching = false
                })
            },
            // 充值记录
            queryBDMerchantRechargeFlowList () {
                const _this = this
                this.isFetching = true
                if (this.$route.query.staffId) {
                    const data = {
                        merchantId: this.merchantId,
                        pageSize: this.pageSize,
                        id: this.merchantRechargeFlowList.length ? this.merchantRechargeFlowList[this.merchantRechargeFlowList.length - 1].id.toString() : '0'
                    }
                    api.newBusiness.queryAgentMerchantRechargeFlowList(data, res => {
                        _this.isFetching = false
                        if (res.result && res.result.code === '0000') {
                            if (res.data.list.length < _this.pageSize) {
                                _this.hasMore = false
                            }
                            // this.pageNumber++
                            _this.merchantRechargeFlowList = _this.merchantRechargeFlowList.concat(res.data.list)
                        }
                    }).catch(e => {
                        console.log(e)
                        _this.isFetching = false
                    })
                } else {
                    return fetch.get({
                        url: apiUrl.queryBDMerchantRechargeFlowList,
                        data: {
                            merchantId: this.merchantId,
                            pageSize: this.pageSize,
                            id: this.merchantRechargeFlowList.length ? this.merchantRechargeFlowList[this.merchantRechargeFlowList.length - 1].id.toString() : '0'
                        }
                    }, res => {
                        this.isFetching = false
                        if (res.result && res.result.code === '0000') {
                            if (res.data.list.length < this.pageSize) {
                                this.hasMore = false
                            }
                            // this.pageNumber++
                            this.merchantRechargeFlowList = this.merchantRechargeFlowList.concat(res.data.list)
                        }
                    }, res => {
                        console.log(res)
                        this.isFetching = false
                    })
                }
            },
            // 交易记录
            queryBDMerchantRevenueFlowList () {
                this.isFetching = true

                if (this.$route.query.staffId) {
                    const _this = this
                    const data = {
                        merchantId: this.merchantId,
                        pageSize: this.pageSize,
                        pageNo: this.pageNumber
                    }
                    api.newBusiness.queryAgentMerchantRevenueFlowList(data, res => {
                        _this.isFetching = false
                        if (res.result && res.result.code === '0000') {
                            if (res.data.list.length < _this.pageSize) {
                                _this.hasMore = false
                            }
                            _this.pageNumber++
                            _this.merchantRevenueFlowList = _this.merchantRevenueFlowList.concat(res.data.list)
                        } else {
                            // this.goToPage(ENUMLIST.PROFESSIONAL)
                            this.$toast(res.result.info)
                        }
                    }).catch(e => {
                        console.log(e)
                        _this.isFetching = false
                    })
                } else {
                    return fetch.get({
                        url: apiUrl.queryBDMerchantRevenueFlowList,
                        data: {
                            merchantId: this.merchantId,
                            pageSize: this.pageSize,
                            pageNo: this.pageNumber
                        // id: this.merchantRevenueFlowList.length ? this.merchantRevenueFlowList[this.merchantRevenueFlowList.length - 1].id.toString() : '0'
                        }
                    }, res => {
                        this.isFetching = false
                        if (res.result && res.result.code === '0000') {
                            if (res.data.list.length < this.pageSize) {
                                this.hasMore = false
                            }
                            this.pageNumber++
                            this.merchantRevenueFlowList = this.merchantRevenueFlowList.concat(res.data.list)
                        } else {
                            // this.goToPage(ENUMLIST.PROFESSIONAL)
                            this.$toast(res.result.info)
                        }
                    }, res => {
                        this.isFetching = false
                        console.log(res)
                    })
                }
            },
            /**
             * 新增访问记录
             * */
            createBDRecord () {
                // console.log('createBDRecord')
                this.isFetching = true
                if (localStorage.getItem('staffId')) {
                    const _this = this
                    const data = {
                        venderId: this.merchantId,
                        recordType: 2,
                        recordContent: this.visitContent,
                        pin: this.currentErp || JSON.parse(localStorage.getItem('staffId')),
                        agentOrganId: JSON.parse(localStorage.getItem('organId'))
                    }
                    api.newBusiness.createAgentRecord(data, res => {
                        _this.isFetching = false
                        if (res.result && res.result.code === '0000') {
                            // _this.merchantVisitHistory.unshift({
                            //     recordContent: _this.visitContent,
                            //     pin: _this.currentErp || JSON.parse(localStorage.getItem('staffId')),
                            //     recordTime: Date.parse(new Date())
                            // })
                            this.pageNumber = 1
                            this.merchantVisitHistory = []
                            _this.searchBDRecordByType(2)
                        }
                    }).catch(e => {
                        console.log(e)
                        this.isFetching = false
                    })
                } else {
                    return fetch.post({
                        url: apiUrl.createBDRecord,
                        data: {
                            venderId: this.merchantId,
                            recordType: 2,
                            recordContent: this.visitContent,
                            pin: this.currentErp,
                            agentOrganId: JSON.parse(localStorage.getItem('organId'))
                        }
                    }, res => {
                        this.isFetching = false
                        if (res.result && res.result.code === '0000') {
                            // this.merchantVisitHistory.unshift({
                            //     recordContent: this.visitContent,
                            //     pin: this.currentErp,
                            //     recordTime: Date.parse(new Date())
                            // })
                            this.pageNumber = 1
                            this.merchantVisitHistory = []
                            this.searchBDRecordByType(2)
                        }
                    }, res => {
                        this.isFetching = false
                        console.log(res)
                    })
                }
            },
            searchQR () {
                this.qrShow = true
                // 多次查看二维码 二维码显示多个  问题待解决
                this.qrTimeStamp = new Date()
                this.$nextTick(this.createQRode)
            },
            createQRode () {
                if (this.qrCode) {
                    return
                }
                let p = {}
                if (this.$route.query.staffId) {
                    p = {
                        erp: this.$route.query.staffId,
                        merchantId: this.merchantId,
                        settlementType: this.merchantInfo.settlementType,
                        bindType: 1
                    }
                } else {
                    p = {
                        erp: this.currentErp,
                        merchantId: this.merchantId,
                        settlementType: this.merchantInfo.settlementType,
                        bindType: 2
                    }
                }
                // canvas 的 宽 高 需要动态设置
                this.qrCode = new QRCode(this.$refs.qrDiv, {
                    text: JSON.stringify(p) || this.$route.query.organId,
                    colorDark: '#333333', // 二维码颜色
                    colorLight: '#fff',
                    width: 180 * (window.screen.width / 375),
                    height: 180 * (window.screen.width / 375),
                    correctLevel: QRCode.CorrectLevel.M // 容错率，L/M/H
                })
            },
            getRecord (type) {
                this.activeType = type
                this.hasMore = true
                this.pageNumber = 1
                this.merchantEnterHistory = []
                this.merchantVisitHistory = []
                this.merchantRechargeFlowList = []
                this.merchantRevenueFlowList = []
                this.loadData()
            },
            onConfirm (checked) {
                switch (this.flag) {
                    case 'industry':
                        this.industry = checked
                        break
                    case 'address':
                        this.address = checked
                        break
                    case 'managementContent':
                        this.managementContent = checked
                        break
                    // 非以上几项全部按选择的学校处理
                    default:
                        this.school[this.flag] = checked
                        break
                }
                // this.showPopup = false
                return checked
            },
            addIteam (type) {
                if (type === 1) {
                    this.schoolCount++
                }
                return ''
            },
            submit (type) {
                if (type === this.ENUM.SUBMITANDQR) {
                    this.qrBtn = true
                } else if (type === this.ENUM.GETQR) {
                    this.qrBtn = true
                }
            },
            addVisitorRecord () {
                this.visitContent = ''
                this.addRecordShow = true
            },
            addRecordHandle () {
                if (this.visitContent && !this.isFetching) {
                    this.createBDRecord()
                }
            },
            getFullAddress () {
                const {
                    provinceName = '', cityName = '', countyName = '', townName = ''
                } = this.merchantInfo
                return `${provinceName}${cityName}${countyName}${townName}`
            },
            getDiscountValue (v) {
                return `${v / 10}折`
            },
            handleScroll () {
                if (this.hasMore && !this.isFetching) {
                    this.loadData()
                }
            },
            repairBusinessInfo () {
                this.$router.push({
                    path: `/updateMerchantInfo/${this.merchantId}`,
                    query: {
                        staffId: this.$route.query.staffId,
                        merchantId: this.merchantId,
                        userName: this.merchantInfo.contacts || ''
                    }
                })
            },
            // 关联合伙人
            tradingRecord () {
                console.log('关联合伙人')
                if (this.$route.query.staffId) {
                    this.$router.push({
                        name: 'tradingRecord',
                        path: '/tradingRecord',
                        query: {
                            staffId: this.$route.query.staffId,
                            shopId: this.merchantId
                        }
                    })
                } else {
                    this.$router.push({
                        name: 'tradingRecord',
                        path: '/tradingRecord',
                        query: {
                            // staffId: this.$route.query.staffId,
                            shopId: this.merchantId
                        }
                    })
                }
            },
            // 设置白名单
            settingWhite () {
                this.$router.push({
                    name: '/white',
                    query: {
                        userCode: this.$route.params.merchantId,
                        type: 1,
                        staffId: this.$route.query.staffId,
                        shopName: this.merchantInfo.name
                    }
                })
            },
            /**
            *  选择学校接口
            *  根据详细地址及省市获取经纬度
            *  merchantLng 经度 merchantLat 纬度
            */
            // chooseSchool () {
            //     this.schoolInfoList = []
            //     if (this.address || this.detailedAddress) {
            //         const point = {
            //             lng: this.merchantLng,
            //             lat: this.merchantLat
            //         }
            //         const newPoint = this.pointToBS(point)
            //         const data = {
            //             latitude: newPoint.lat,
            //             longitude: newPoint.lng,
            //             distance: 5000
            //         }

            //         if (this.$route.query.lng && this.$route.query.lat) {
            //             data.latitude = this.$route.query.lat 
            //             data.longitude = this.$route.query.lng
            //             this.center = {
            //                 lng: this.$route.query.lng,
            //                 lat: this.$route.query.lat
            //             }
            //             this.merchantLng = this.$route.query.lng
            //             this.merchantLat = this.$route.query.lat
            //         }
            //         api.merchant.queryBDSchoolInfoListByCoordinate(data, res => {
            //             if (res && res.result && res.result.code === '0000') {
            //                 this.schoolList = res.data.list

            //                 this.schoolList.forEach(value => {
            //                     const newObject = { ...value }
            //                     newObject.discount = this.discountValue / 10
            //                     if (this.schools.indexOf(value.schoolId) > -1) { 
            //                         newObject.isChecked = true
            //                     } else {
            //                         newObject.isChecked = false
            //                     }
            //                     const point1 = {
            //                         lng: value.longitude,
            //                         lat: value.latitude
            //                     }
            //                     const newPoint1 = this.pointToBS(point1)
            //                     value.longitude = newPoint1.lng
            //                     value.latitude = newPoint1.lat
            //                     this.schoolInfoList.push(newObject)
            //                 })
            //             }
            //         })
            //     } else {
            //         this.$dialog.alert({
            //             message: '店铺地址不能为空'
            //         })
            //         return ''
            //     }
            // },
            // 84 坐标转 百度坐标
            pointToBd (point) {
                // wgs84转国测局坐标
                const wgs84togcj02 = coordtransform.wgs84togcj02(point.lng, point.lat)
                // 国测局坐标转百度经纬度坐标
                const gcj02tobd09 = coordtransform.gcj02tobd09(wgs84togcj02[0], wgs84togcj02[1])
                const newPoint = {
                    lng: gcj02tobd09[0],
                    lat: gcj02tobd09[1]
                }
                return newPoint
            },
            // 百度 坐标转 84 坐标
            pointToBS (point) {
                const bd09togcj02 = coordtransform.bd09togcj02(point.lng, point.lat)
                // 国测局坐标转wgs84坐标
                const gcj02towgs84 = coordtransform.gcj02towgs84(bd09togcj02[0], bd09togcj02[1])
                const newPoint = {
                    lng: gcj02towgs84[0],
                    lat: gcj02towgs84[1]
                }
                return newPoint
            },
            // 返回坐标点
            returnPoint (val) {
                // 组件根据地质 搜索出来的 坐标 中心点
                this.merchantLng = val.Lng
                this.merchantLat = val.Lat
                this.fullCenter = {
                    lng: val.Lng,
                    lat: val.Lat
                }
                // this.chooseSchool()
            },
            // 返回学校数据
            returnSchoolList (val) {
                this.schoolInfoList = val
            },
            // 复制事件
            copyEvent () {
                console.log('copy events create input copy delete')
                const inputDom = document.createElement('input')
                inputDom.setAttribute('readonly', 'readonly')
                inputDom.setAttribute('value', this.$route.query.merchantId || this.$route.params.merchantId)
                inputDom.style = 'opacity: 0;'
                document.body.appendChild(inputDom)
                inputDom.select()
                document.execCommand('Copy')
                document.body.removeChild(inputDom)
                this.$toast.success('复制成功')
            }
        }
    }
</script>

<style lang="scss" scoped>
    $lh:0.20rem;

    .merchant-detail-container {
        padding-bottom: 1.2rem;
        
        .merchant-id-box {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.15rem;
            padding: .1rem .12rem;
            color: #323233;

            .right-container {
                display: flex;
                justify-content: flex-end;
                align-items: center;

                .merchant-id {
                    margin-right: 0.04rem;
                }
            }
        }
    }

    .qr_style {
        width: 2.7rem;
        height: auto;
        background: white;
        font-size: .15rem;
        border-radius: .06rem;

        .title {
            font-size: .18rem;
            color: #2e2d2d;
            font-weight: 500;
            text-align: center;
        }

        .qr_content {
            width: 1.8rem;
            height: 1.8rem;
            margin: auto;
        }

        .foot {
            font-size: .14rem;
            text-align: center;
            color: #2e2d2d;
        }
    }

    .group-title-other {
        box-sizing: border-box;
        width: 100%;
        height: 0.5rem;
        font-size: 0.15rem;
        line-height: 0.18rem;
        font-weight: 400;
        color: #848484;
        background-color: #F5F8FC;
        display: flex;
        align-items: center;
        padding-left: 0.12rem;
        display: flex;
        align-items: center;
    }

    .record {
        width: 100%;
        height: .5rem;
        color: #848484;
        font-size: .15rem;
        margin: 0 0 0.1rem 0;
        /*position: sticky;*/
        /*top: 0;*/
        /*z-index: 100;*/
        /*background: #fff;*/

        .active {
            border: 1px solid #F0250F;
            color: #F0250F;
            font-weight: 500;
        }

        .record_iteam {
            margin-left: .1rem;
            width: .8rem;
            height: 100%;
            line-height: .5rem;
            background-color: white;
            text-align: center;
            float: left;
        }
    }

    .vdialog {
        /deep/ .van-cell {
            padding: .1rem .12rem;
            height: 2.8rem;
        }
        /deep/.van-cell__value--alone {
            background-color: #F5F8FC;
        }
        /deep/ .van-field__control{
            min-height: 2.4rem;
        }
    }

    .submit {
        width: 100%;
        min-height: .5rem;
        color: #848484;
        background-color: white;
        font-size: .14rem;
        text-align: center;
        padding-top: .2rem;
        padding-bottom: .2rem;
        position: fixed;
        bottom: 0;

        .updateBtn {
            width: 3.5rem;
            height: .4rem;
            border: .01rem solid #F0250F;
            border-radius: .3rem;
            margin-left: .05rem ;
            margin-right: .05rem;
            margin-top: .1rem;
            color: white;
            background: linear-gradient(270deg,rgb(222,49,33) 0%,rgb(236,86,42) 100%);
        }

        .btn {
            width: 1.7rem;
            height: .4rem;
            border: .01rem solid #F0250F;
            border-radius: .3rem;
            margin-left: .05rem ;
            margin-right: .05rem;
            color: white;
            background: linear-gradient(270deg,rgb(222,49,33) 0%,rgb(236,86,42) 100%);
        }

        .btn:active,  .updateBtn:active{
            opacity: .8;
        }
    }

    /deep/ .van-cell {
        padding: .1rem .12rem;
        height: .5rem;
        box-sizing: border-box;
        
    }

    /deep/.van-cell:not(:last-child)::after {
        left: 0rem;
    }

    /deep/ .van-field__value {
        line-height: 0.3rem;
    }

    /deep/ .label-style {
        font-size: 0.15rem;
        line-height: 0.3rem;
    }

    .qualification_title {
        color: #000;
        text-align: center;

        .qualification_title_enterpriseName{
            font-size: 0.25rem;
            margin-bottom: 0rem;
            white-space: nowrap;
            overflow: hidden;
        }

        .qualification_title_enterpriseNameNumber{
            font-size: 0.15rem;
        }
    }

    .upload_block {
        // margin: 0rem 0rem .16rem 0rem;

        .group-title {
            box-sizing: border-box;
            width: 100%;
            height: 0.5rem;
            font-size: 0.15rem;
            line-height: 0.18rem;
            font-weight: 400;
            color: #848484;
            background-color: #F5F8FC;
            display: flex;
            align-items: center;
            padding-left: 0.12rem;
            display: flex;
            align-items: center;
        }

        .field-container {
            box-sizing: border-box;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            // padding-left: 0.08rem;

            .field-icon {
                font-size: 0.15rem;
                line-height: 0.18rem;
                color: #F0250F;
            }
        }
    }

    .desc_title {
        font-size: 0.15rem;
        color: #000000;
        height: $lh;
        margin: .12rem;

        .desc_title_left {
            width: 50%;
            line-height: $lh;
            text-align: left;
            float: left;
        }

        .desc_title_right {
            width: 50%;
            line-height: $lh;
            text-align: right;
            float: left;

            .van_icon {
                margin-bottom: 0.01rem;
            }
        }
    }

    .tabbar-box {
        .add-button {
            width: 100%;
            font-size: 0.18rem;
            font-weight: 400;
            line-height: 0.18rem;
            color: #FFFFFF;
            // opacity: 0.3;
            // text-align: ;
            // margin-top: 0.2rem;
            display: flex;
            justify-content: center;
            align-items: center;

            .add-icon {
                height: 0.24rem;
                margin-right: 0.03rem;
                // line-height: 0.24rem;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .add-text {
                height: 0.24rem;
                line-height: 0.24rem;
            }
        }
    }

    .btn-box {
        position: fixed;
        right: 0.12rem;
        bottom: 0.72rem;
        height: 1.12rem;
        display: flex;
        flex-direction: column;
        justify-content: space-between;

        .btn-1, .btn-2 {
            width: 0.5rem;
            height: 0.5rem;
            border-radius: 50%;
            border: none;
        }

        .btn-1 {
            background: linear-gradient(180deg,rgba(100,199,121,1) 0%,rgba(116,215,137,1) 100%);
        }

        .btn-2 {
            background: linear-gradient(29deg,rgba(98,169,255,1) 0%,rgba(76,148,234,1) 100%);
        }
    }
</style>
