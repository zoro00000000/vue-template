<template>
  <div class="photo-edit">
    <div class="edit-box">
      <div class="draggable-zone">
        <div class="img-item" v-for="(item,index) in imgList" :key="index">
          <img :src="item.imgUrl" alt />
          <p v-if="item.tag" class="img-title">{{item.tag}}</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
    export default {
        data () {
            return {

                imgList: [
                    {
                        imgId: 22,
                        imgUrl:
                            'https://img14.360buyimg.com/pop/s1180x940_jfs/t1/92978/31/4467/175641/5de710a1Ed8e7dbcf/e5cf9d932045b0f2.jpg.webp',
                        orderBy: 1,
                        tag: '店内环境',
                        type: 2
                    },
                    {
                        imgId: 11,
                        imgUrl:
                            'http://storage.jd.com/album.forum.jd.com/201906/03/153102blc9d3g8f7jfgd6w.jpg',
                        orderBy: 2,
                        tag: 'LOGO',
                        type: 2
                    },
                    {
                        imgId: 114,
                        imgUrl:
                            'https://misc.360buyimg.com/mtd/pc/index_2019/1.0.0/assets/img/4dca746078b49c72a9877d2998d0abc8.png',
                        orderBy: 2,
                        tag: 'LOGO',
                        type: 2
                    }
                ]
            }
        }

    }
</script>
<style lang="scss" scoped>
h1,
h2,
h3,
h4,
h5,
p {
    margin: 0;
    padding: 0;
}

input {
    border: none;
}

.edit-box {
    margin: .5rem 0 0 .08rem;

}
.draggable-zone{
    display: flex;
}
.upload-btn {
    width: 1.15rem;
    height: 1.15rem;
    border: 1px solid rgba(0, 130, 110, 1);
    font-size: .13rem;
    text-align: center;
    border-radius: .05rem;
    margin: 0 .07rem .07rem 0;
    position: relative;
    overflow: hidden;
    background-color: #fff;

    .upload-input {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
    }

    .icon-zone {
        padding-top: .38rem;
    }

    p {
        color: rgba(0, 130, 110, 1);
        font-size: .13rem;
        margin-top: .06rem;

    }
}

.img-item {
    width: 1.15rem;
    height: 1.15rem;
    border-radius: .05rem;
    overflow: hidden;
    position: relative;
    margin: 0 .07rem .07rem 0;

    .btn-close {
        position: absolute;
        top: .06rem;
        right: .05rem;
        background: #fff;
        width: .15rem;
        height: .15rem;
        border-radius: 50%;
    }

    img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .img-title {
        position: absolute;
        width: 100%;
        left: 0;
        bottom: 0;
        height: .21rem;
        line-height: .21rem;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: .11rem;
        background-color: rgba(0, 0, 0, 0.6);
        color: rgba(255, 255, 255, 0.8);
    }
}

.handle-zone {
    padding: 0 .16rem;

    .handle-btn {
        height: .6rem;
        line-height: .6rem;
        text-align: center;
        font-size: .16rem;
        background-color: #fff;
        border-radius: .05rem;

        &:first-child {
            color: #F85050;
            margin-bottom: .12rem;
        }
    }
}

</style>
