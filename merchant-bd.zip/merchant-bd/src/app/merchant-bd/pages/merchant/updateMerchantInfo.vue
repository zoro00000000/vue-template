<template>
    <merchant-entry update-merchant-page="yes" ref="updateObj"></merchant-entry>
</template>

<script>
    import merchantEntry from './MerchantEntry'

    export default {
        name: 'updateMerchantInfo',
        components: {
            merchantEntry
        },
        methods: {
            init () {
                // 这段代码有bug 会造成 接口请求两次
                // this.$refs.updateObj.initBackFillInfo()
            }
        },
        beforeRouteEnter (to, from, next) {
            console.log('beforerouteenter')
            if (from.name === 'tradingRecord') {
                console.log('来自合伙人什么都不做')
                next()
            } else {
                console.log('不是来自合伙人，重新请求接口')
                // eslint-disable-next-line no-return-assign
                next(vm => vm.init())
            }
        },
        comments: {
            merchantEntry
        }
    }
</script>
