<template>
    <div>
        <ul class="code-handle">
            <li class="code-item">
                <span>已绑定邀请码</span>
                <em v-if="invitationCode">{{ invitationCode }}</em>
                <em v-else>无</em>
            </li>
            <li class="code-item">
                <span>对应PIN</span>
                <em v-if="pin">{{ pin }}</em>
                <em v-else>无</em>
            </li>
        </ul>
        <div class="search-code">
            <span>录入绑定邀请码</span>
            <input type="text" v-model="invitationCodeText" placeholder />
            <strong @click="searchPIN">查询PIN</strong>
        </div>
        <p class="search-result">
            <span v-if="pinText">{{ pinText }}</span>
        </p>
        <div class="btn-bouding" @click="bindBDPartnerCode">绑定邀请码</div>
        <template v-if="partnerCodeBindHistoryList.length">
            <h4 class="list-title">邀请码绑定记录</h4>
            <pullDownRefresh @scroll="handleScroll">
                <ul class="code-handle">
                    <li
                        class="code-item"
                        v-for="(item, index) in partnerCodeBindHistoryList"
                        :key="index"
                    >
                        <span>邀请码：{{ item.invitationCode }}</span>
                        <em>{{ item.bindDate | dateFormat }}</em>
                    </li>
                </ul>
            </pullDownRefresh>
        </template>
    </div>
</template>
<script>
    import dayjs from 'dayjs'
    import { apiUrl, fetch } from '@/merchant-bd/server/getData'
    import JME from '@/merchant-bd/utils/jdme.js'
    import { getUrlString } from '@/merchant-bd/utils/tools'
    import pullDownRefresh from '../../components/scroll/pullDownRefresh'

    export default {
        data () {
            return {
                shopId: '',
                currentErp: '',
                erp: '',
                invitationCode: '',
                pin: '',
                invitationCodeText: '', // 输入框里的邀请码
                pinText: '', //  提示用的
                pinTure: '', // 真正传餐的
                partnerCodeBindHistoryList: [],
                total: 0,
                currentPage: 1,
                pageId: 1,
                pageSize: 10,
                hasMore: false
            }
        },
        created () {
            // 1. 调接口查看是否是BD人员
            const { shopId } = this.$route.query
            this.shopId = shopId
            this.currentErp = getUrlString('sid') || JME.getUserNameForCookie()
            this.queryBDBindPartnerCode()
            this.queryBDPartnerCodeBindHistory()
        },
        methods: {
            queryBDBindPartnerCode () {
                fetch.get(
                    {
                        url: apiUrl.queryBDBindPartnerCode,
                        data: {
                            shopId: this.shopId
                        }
                    },
                    res => {
                        this.invitationCode = res.data.invitationCode
                        this.pin = res.data.pin
                        console.log('res---->', res.data)
                    }
                )
            },
            searchPIN () {
                if (this.invitationCodeText.length == 0) {
                    this.$toast.fail('请填写绑定邀请码')
                    return false
                }
                fetch.get(
                    {
                        url: apiUrl.queryBDPinByPartnerCode,
                        data: {
                            invitationCode: this.invitationCodeText
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            // 查询结果：PIN为
                            this.pinText = res.data.pin
                                ? `查询结果：PIN为${res.data.pin}`
                                : '您所填写的邀请码无效，请认真核对'
                            this.pinTure = res.data.pin
                        } else {
                            this.$toast.fail(res.result.info)
                        }
                    }
                )
            },
            queryBDPartnerCodeBindHistory () {
                const options = {
                    shopId: this.shopId,
                    pageId: this.pageId,
                    pageSize: this.pageSize
                }
                fetch.get(
                    {
                        url: apiUrl.queryBDPartnerCodeBindHistory,
                        data: {
                            ...options
                        }
                    },
                    res => {
                        if (res.result.code === '0000') {
                            console.log('pageId++')
                            this.total = res.data.total
                            this.currentPage = res.data.currentPage
                            this.hasMore = false
                            if (!res.data.partnerCodeBindHistoryList) return
                            this.partnerCodeBindHistoryList = this.partnerCodeBindHistoryList.concat(
                                res.data.partnerCodeBindHistoryList
                            )
                            if (this.partnerCodeBindHistoryList.length === this.total) {
                                this.hasMore = true
                                return false
                            } else {
                                this.pageId++
                            }
                        }
                    }
                )
            },
            bindBDPartnerCode () {
                console.log(this.$route)
                const options = {
                    shopId: this.shopId,
                    pin: this.pinTure,
                    inviteCode: this.invitationCodeText,
                    erp: this.currentErp || this.$route.query.staffId
                }
                console.log('options:', options)
                if (options.shopId && options.pin && options.inviteCode && options.erp) {
                    fetch.get(
                        {
                            url: apiUrl.bindBDPartnerCode,
                            data: {
                                ...options
                            }
                        },
                        res => {
                            this.partnerCodeBindHistoryList.splice(0)
                            if (res.result.code === '0000') {
                                this.invitationCodeText = ''
                                this.$toast.success('绑定成功')
                                this.pageId = 1
                                this.queryBDBindPartnerCode()
                                this.queryBDPartnerCodeBindHistory()
                            } else {
                                this.$toast.fail(res.result.info)
                            }
                        }
                    )
                } else {
                    this.$toast.fail('请先录入有效的绑定邀请码并查询PIN')
                }
            },
            handleScroll () {
                console.log('scroll')
                if (!this.hasMore) {
                    this.hasMore = true
                    this.scrollLoadData()
                }
            },
            scrollLoadData () {
                this.queryBDPartnerCodeBindHistory()
            }
        },
        filters: {
            dateFormat (value) {
                return dayjs(value).format('YYYY.MM.DD')
            }
        },
        components: {
            pullDownRefresh
        }
    }
</script>
<style lang="scss" scoped>
* {
  font-size: 0.15rem;
}

ul,
li,
p,
h4 {
  font-size: 0.15rem;
  padding: 0;
  margin: 0;
}
em {
  font-style: normal;
}
.code-handle {
  .code-item {
    border-bottom: 1px solid #eef1f4;
    &:last-child {
      border: none;
    }
  }
}
.code-item {
  display: flex;
  justify-content: space-between;
  height: 0.5rem;
  line-height: 0.5rem;
  background: #fff;
  font-size: 0.15rem;
  padding: 0 0.12rem;
  span {
    color: #2e2d2d;
  }
  em {
    color: #848484;
  }
}
.search-code {
  margin-top: 0.11rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 0.5rem;
  line-height: 0.5rem;
  background: #fff;
  font-size: 0.15rem;
  padding: 0 0.12rem;
  em {
    color: #848484;
  }
  input {
    text-align: center;
    height: 28px;
    line-height: 28px;
    font-size:15px;
    padding: 2px 0;
    width: 1rem;
    border: none;
    display: inline-block;
    box-sizing: border-box;
  }

  strong {
    width: 0.8rem;
    height: 0.3rem;

    border-radius: 0.17rem;
    font-size: 0.15rem;
    border: 1px solid rgba(240, 37, 15, 1);
    color: rgba(240, 37, 15, 1);
    font-weight: normal;
    text-align: center;
    line-height: 0.3rem;
    &:active {
      background: rgba(240, 37, 15, 0.1);
    }
  }
}
.search-result {
  height: 0.5rem;
  line-height: 0.5rem;
  text-align: center;
  color: rgba(240, 37, 15, 1);
  font-size: 15px;
}
.btn-bouding {
  width: 2.63rem;
  height: 0.46rem;
  line-height: 0.46rem;
  text-align: center;
  background: linear-gradient(
    270deg,
    rgba(222, 49, 33, 1) 0%,
    rgba(236, 86, 42, 1) 100%
  );
  border-radius: 0.23rem;
  font-size: 18px;
  color: rgba(255, 255, 255, 0.8);
  margin: 0 auto;
}
.list-title {
  color: #2e2d2d;
  margin-top: 0.5rem;
  height: 0.5rem;
  line-height: 0.5rem;
  background: #fff;
  font-size: 0.15rem;
  font-weight: normal;
  text-align: center;
  border-bottom: 1px solid #eef1f4;
}
</style>
