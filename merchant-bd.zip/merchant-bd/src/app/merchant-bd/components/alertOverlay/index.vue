<template>
    <div class="alert-overlay-container">
        <van-overlay
            :show="showStatus"
        >
            <div class="wrapper-box">
                <div class="inner-content">
                    <div v-if="alertType === 1">
                        <div class="header-title">
                            {{headerTitle}}
                        </div>
                        <div class="content-text">
                            {{contentText}}
                        </div>
                    </div>
                    
                    <!-- 有确认按钮 跟 取消按钮 -->
                    <div v-if="alertType === 2" class="content-box">
                        <div class="content-text-2" :class="center? 'center': ''">
                            {{contentText}}
                        </div>
                        
                        <div class="content-slot-box" v-if="showSolt">
                            <slot></slot>
                        </div>

                        <div class="tabbar-box">
                            <div class="button-cancel" @click="cancelEvent">取消</div>
                            <div class="tabbar-split" style="width:1px"></div>
                            <div class="button-confirm" :clstag="tagStringConfirm" @click="confirmEvent">确定</div>
                        </div>
                    </div>

                    <div v-if="alertType === 3" class="content-box">
                        <div v-if="headerTitle" class="header-title">
                            {{headerTitle}}
                        </div>

                        <div class="content-text-2" :class="center? 'center': ''">
                            {{contentText}}
                        </div>
                        
                        <div class="content-slot-box" v-if="showSolt">
                            <slot></slot>
                        </div>

                        <div class="tabbar-box">
                            <div class="button-confirm-one" :clstag="tagStringCancel || tagString" @click="confirmEvent">确定</div>
                        </div>
                    </div>
                </div>
            </div>
        </van-overlay>
    </div>
</template>

<script>
    export default {
        name: 'alertOverlay',
        props: {
            // 是否显示遮罩层
            show: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 遮罩层类型，1 只是文案 2 是有带有确认按钮 取消按钮的
            alertType: {
                type: Number,
                default () {
                    return 1
                }
            },
            headerTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            contentText: {
                type: String,
                default () {
                    return ''
                }
            },
            confirmEvent: {
                type: Function,
                default () {
                    return function () {}
                }
            },
            cancelEvent: {
                type: Function,
                default () {
                    return function () {}
                }
            },
            showSolt: {
                type: Boolean,
                default () {
                    return true
                }
            },
            center: {
                type: Boolean,
                default () {
                    return false
                }
            },
            tagStringConfirm: {
                type: String,
                default () {
                    return ''
                }
            },
            tagStringCancel: {
                type: String,
                default () {
                    return ''
                }
            },
            tagString: {
                type: String,
                default () {
                    return ''
                }
            }
        },
        data () {
            return {
                showStatus: this.show
            }
        },
        mounted () {},
        updated () {
            console.log('触发了更新', this.show)  
        },
        methods: {
            // cancelClick () {
            //     this.$emit('show', false)
            //     this.showStatus = false
            // }
        },
        watch: {
            show () {
                console.log('show', this.show)
                this.showStatus = this.show
            }
        }
    }
</script>

<style lang="scss" scoped>
.alert-overlay-container {
    // position: absolute;
    // top: 0;
    // width: 100%;
    // height: 100vh;
    overflow: hidden;
    .van-overlay{
        z-index: 999;
    }
    .wrapper-box {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;

        .inner-content {
            // box-sizing: border-box;
            width: 2.7rem;
            min-height: 1.16rem;
            border-radius: 0.04rem;
            background-color: #FFFFFF;
            overflow: hidden;
            display: flex;
            flex-direction: column;

            .content-box {
                min-height: 1.16rem;
            }

            .header-title {
                font-size: 0.15rem;
                line-height: 0.15rem;
                color: #2E2D2D;
                margin-top: 0.24rem;
                text-align: center;
                padding: 0 0.37rem;
            }

            .content-text {
                font-size: 0.14rem;
                color: #848484;
                line-height: 0.21rem;
                margin-top: 0.24rem;
                margin-bottom: 0.28rem;
                padding: 0 0.37rem;
            }

            .content-text-2 {
                flex: 1;
                box-sizing: border-box;
                width: 100%;
                height: auto;
                font-size: 0.15rem;
                line-height: 0.22rem;
                font-weight: 400;
                margin: 0.24rem 0;
                color: #848484;
                padding: 0 0.29rem;
                text-align: justify;
            }

            .content-slot-box {
                min-height: 0.5rem;
            }

            .tabbar-box {
                width: 100%;
                height: 0.44rem;
                border-top: 0.01rem solid #E5E5E5;
                display: flex;
                flex-direction: row;
                align-items: center;

                .button-cancel {
                    width: 50%;
                    height: 100%;
                    text-align: center;
                    font-size: 0.15rem;
                    font-weight: 400;
                    color: #000000;
                    line-height: 0.44rem;
                }

                .tabbar-split {
                    width: 0.01rem;
                    height: 0.3rem;
                    background-color: #E5E5E5;
                }

                .button-confirm {
                    width: 50%;
                    height: 100%;
                    text-align: center;
                    font-size: 0.15rem;
                    font-weight: 400;
                    color: #F0250F;
                    line-height: 0.44rem;
                }

                .button-confirm-one {
                    width: 100%;
                    height: 100%;
                    text-align: center;
                    font-size: 0.15rem;
                    font-weight: 400;
                    color: #F0250F;
                    line-height: 0.44rem;
                }
            }
            .center {
                text-align: center;
            }
        }
    }
}
</style>
