<template>
    <div v-if="showStatus" class="return-button-container" @click="clickReturn"></div>
</template>

<script>
    export default {
        name: 'returnButton',
        data () {
            return {
                showStatus: true
            }
        },
        watch: {
            '$route.path': function () {
                // console.log('@@@route:@@@', this.$route)
                if (this.$route.meta.hideReturn || this.$route.query.noHome || (this.$route.path === '/')) {
                    this.showStatus = false
                } else {
                    this.showStatus = true
                }
            },
            showStatus (value) {
                this.showStatus = value
            }
        },
        methods: {
            clickReturn () {
                // console.log('return click route:', this.$route)
                switch (this.$route.name) {
                    case 'accounts':
                        this.$router.push({ path: '/company/myCompany' })
                        break
                    case '/business/manage':
                        this.$router.push({ path: '/company/myCompany' })
                        break
                    default:
                        // 点击了 返回 按钮
                        this.$router.go(-1)
                        break
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
.return-button-container {
    position: fixed;
    z-index: 999;
    top: 0.12rem;
    left: 0.12rem;
    width: 0.26rem;
    height: 0.26rem;
    background-image: url('../../assets/img/auth/return.png');
    background-size: 100% 100%;
}
</style>
