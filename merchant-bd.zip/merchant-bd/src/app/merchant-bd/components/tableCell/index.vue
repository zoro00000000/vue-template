<template>
    <div class="table-cell-container">
        <div class="table-cell-box"
            :class="{ 'cell-box-bg': isGayBGColor }"
            @click="jumpEvent"
        >
            <div v-if="titleKeys.length === 0" class="cell-texts">
                <div class="cell-item"
                    v-for="(item, index) in titles"
                    :key="index"
                    :class="{ 'text-bold': isBold, 'last-child-right': index === Object.keys(titles).pop() && lastIsRight }"
                >{{item}}</div>
            </div>

            <div v-if="titleKeys.length > 0" class="cell-texts">
                <div class="cell-item"
                    v-for="(item, index) in titleKeys"
                    :key="index"
                    :class="{ 'text-bold': isBold, 'last-child-right': index === Object.keys(titleKeys).pop() && lastIsRight }"
                >{{titles[item]}}</div>
            </div>

            <div v-if="!hideArrow" class="arrow-right"><van-icon v-if="isJump" name="arrow" /></div>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            // title list 可能有多个展示的 title
            titles: {
                type: Object,
                default () {
                    return {}
                }
            },
            // 需要展示的key
            titleKeys: {
                type: Array,
                default () {
                    return []
                }
            },
            // 是否有跳转功能
            isJump: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 是否文本加粗
            isBold: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 背景是灰色
            isGayBGColor: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 隐藏箭头
            hideArrow: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 最后一行靠右
            lastIsRight: {
                type: Boolean,
                default () {
                    return false
                }
            }
        },
        methods: {
            jumpEvent () {
                console.log('click event')
                if (this.isJump) this.$emit('click')
            }
        }
    }
</script>

<style lang="scss" scoped>
.table-cell-container {
    width: 100%;
    height: 0.5rem;
    background-color: #FFFFFF;

    .table-cell-box {
        padding: 0 0.12rem;
        height: 100%;
        display: flex;
        align-items: center;
        border-bottom: 0.01rem solid #EEF1F4;
        box-sizing: border-box;
        // min-width: 0;

        .cell-texts {
            flex: 1;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            height: 100%;
            min-width: 0; // 解决  white-space: nowrap; 撑大盒子的问题
            // width: 100%;

            .cell-item {
                flex: 1;
                font-size: 0.15rem;
                line-height: o.5rem;
                color: #2E2D2D;
                text-align: center;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }
            .cell-item:first-child {
                text-align: left;
                width: 40%;
                flex: none;
            }
            .last-child-right {
                text-align: right;
            }
        }

        .arrow-right {
            width: 0.12rem;
            height: 0.12rem;
            font-size: 0.12rem;
            margin-left: 0.11rem;
        }

        .text-bold {
            font-size: 0.15rem;
            font-weight: 500;
            color: #2E2D2D;
        }
    }

    .cell-box-bg {
        background-color: #F4F4F4;
    }
}
</style>
