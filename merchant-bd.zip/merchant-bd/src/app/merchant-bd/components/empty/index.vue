<template>
     <div  class="no-data">
            <div class="no-data-icon"></div>
            <div class="no-data-text">
                {{ showTitle }}
            </div>
        </div>
</template>

<script>
    export default {
        props: {
            // 是否显示遮罩层
            showTitle: {
                type: String,
                default () {
                    return '暂无员工变更记录'
                }
            }
        },
        data () {
            return {
            
            }
        }
    }
</script>

<style lang = "scss" scoped>
       .no-data {
        position: fixed;
        top: 0;
        width: 100%;
        height: 100vh;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background-color: #F5F8FC;
        .no-data-icon {
            width: 1.45rem;
            height: 1.45rem;
            background-color: #E4E4E4;
            border-radius: 50%;
            background: url('../../assets/img/empty.png') no-repeat;
            background-position: center center;
            background-size: 100% 100%;
        }
        .no-data-text {
            color: #2E2D2D;
            font-size: 0.15rem;
            font-weight: 500;
            text-align: center;
            margin-top: 0.22rem;
        }
    }

</style>
