<template>
    <div class="card-cell-container">
        <div class="card-box"  @click="jumpEvent">
            <div class="card-header-box">
                <div class="header-left-text">{{headerTitle}}</div>
                <div class="header-right-text">{{headerText}}</div>
            </div>

            <div class="card-split"></div>

            <div class="card-content-box">
                <div v-for="(item, index) in contentList" :key="index" class="card-content-item-box">
                    <div class="content-title">{{item.title}}</div>
                    <div class="content-text">{{item.text}}</div>
                </div>
            </div>

            <div v-if="headerBottomType" class="card-bottom-box">
                <div class="card-split"></div>
                <slot></slot>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'cardCell',
        props: {
            headerTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            headerText: {
                type: String,
                default () {
                    return ''
                }
            },
            contentList: {
                type: Array,
                default () {
                    return []
                }
            },
            headerBottomType: {
                type: Boolean,
                default () {
                    return false
                }
            },
            // 是否有跳转功能
            isJump: {
                type: Boolean,
                default () {
                    return false
                }
            }
        },
        methods: {
            jumpEvent () {
                console.log('click event')
                if (this.isJump) this.$emit('click')
            }
        }
    }
</script>

<style lang="scss" scoped>
.card-cell-container {
    width: 100%;
    height: auto;
    padding: 0 0.12rem 0.12rem 0.12rem;
    box-sizing: border-box;

    .card-box {
        border-radius: 0.04rem;
        background-color: #FFFFFF;
        overflow: hidden;

        .card-header-box {
            height: 0.5rem;
            padding: 0 0.12rem;
            box-sizing: border-box;
            display: flex;
            justify-content: space-between;
            align-items: center;

            .header-left-text {
                flex: 1;
                font-size: 0.15rem;
                font-weight: 500;
                color: #2E2D2D;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
                margin-right: 0.12rem;
            }

            .header-right-text {
                font-size: 0.15rem;
                font-weight: 400;
                color: #2E2D2D;
            }
        }

        .card-split {
            width: 100%;
            height: 0.01rem;
            background-color: #EEF1F4;
        }

        .card-content-box {
            width: 100%;
            height: 0.95rem;
            display: flex;
            padding: 0 0.12rem;
            box-sizing: border-box;

            .card-content-item-box {
                flex: 1;
                text-align: center;
                display: flex;
                flex-direction: column;
                justify-content: center;
                max-width: 33%;

                .content-title {
                    font-size: 0.12rem;
                    font-weight: 400;
                    color: #848484;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    overflow: hidden;
                }

                .content-text {
                    font-size: 0.15rem;
                    font-weight: 400;
                    color: #2E2D2D;
                    margin-top: 0.12rem;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    overflow: hidden;
                }
            }
            .card-content-item-box:first-child {
                text-align: left;
            }
            .card-content-item-box:last-child {
                text-align: right;
            }
        }

        .card-bottom-box {
            width: 100%;
            height: 0.49rem;
        }
    }
}
</style>
