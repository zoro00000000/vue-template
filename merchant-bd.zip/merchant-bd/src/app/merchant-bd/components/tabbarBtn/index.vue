<template>
    <div class="tabbar-button-container">
        <div v-if="!custom" class="tabbar-box">
            <div :class="clickValue === leftJumpValue ? 'actived' : ''"
                class="tabbar-left"
                @click="tabbarBtnEvent(leftJumpValue)"
                clstag="jr|keycount|dl_qyyj|qyyj"
            >
                {{leftTitle}}
            </div>
            <div class="tabar-split"></div>
            <div :class="clickValue === rightJumpValue ? 'actived' : ''"
                class="tabbar-right"
                @click="tabbarBtnEvent(rightJumpValue)"
                clstag="jr|keycount|dl_wdqy|wdyq"
            >
                {{rightTitle}}
            </div>
        </div>

        <div v-if="custom" 
            class="tabbar-box"
            @click="tabbarBtnEvent(leftJumpValue)"
        >
            <slot></slot>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'tabbarBtn',
        props: {
            leftTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            rightTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            // 是否自定义
            custom: {
                type: Boolean,
                default () {
                    return false
                }
            },
            clickValue: {
                type: String,
                default () {
                    return '1'
                }
            }
        },
        data () {
            return {
                leftJumpValue: '1',
                rightJumpValue: '2'
            }
        },
        methods: {
            // leftJump () {
            //     this.$emit('leftBtnClick', '1')
            // },
            // rightJump () {
            //     this.$emit('rightBtnClick', '2')
            // },
            tabbarBtnEvent (value) {
                // this.clickValue = value
                this.$emit('btnClickValue', value)
            }
        }
    }
</script>

<style lang="scss" scoped>
.tabbar-button-container {
    width: 100%;
    height: 0.6rem;

    .tabbar-box {
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 0.6rem;
        background: linear-gradient(270deg,rgba(222,49,33,1) 0%,rgba(236,86,42,1) 100%);
        display: flex;
        // align-items: center;

        .tabbar-left {
            display: flex;
            // align-items: center;
            justify-content: center;
            width: 50%;
            height: 100%;
            font-size: 0.18rem;
            line-height: 0.18rem;
            color: #FFFFFF;
            opacity: 0.3;
            font-weight: 500;
            margin-top: 0.22rem;
        }

        .tabar-split {
            width: 0.01rem;
            height: 0.15rem;
            background-color: #EEF1F4;
            margin-top: 0.22rem;
        }

        .tabbar-right {
            display: flex;
            // align-items: center;
            justify-content: center;
            width: 50%;
            height: 100%;
            font-size: 0.18rem;
            line-height: 0.18rem;
            color: #FFFFFF;
            opacity: 0.3;
            font-weight: 500;
            margin-top: 0.22rem;
        }

        .actived {
            opacity: 1;
        }
    }
}
</style>
