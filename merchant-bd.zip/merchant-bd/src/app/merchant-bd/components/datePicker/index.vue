<template>
    <div class="select-box">
        <div class="second-title" v-if="showBtn">
            <slot></slot>
        </div>
        <div class="select-date" v-if="showBtn">
            <button class="button-style">
                <div class="bottom-text" @click="datePickerEvent()">{{dateSelectVal}}月</div>
            </button>
        </div>
        <slot  v-if="!showBtn" ></slot>
        <van-popup v-model="showDatePiker"
            position="bottom"
            :style="{height: '40%'}"
        >
            <van-datetime-picker 
                v-if="showBtn"
                v-model="currentDate"
                type="year-month"
                :min-date="minDate"
                :max-date="maxDate"
                :formatter="formatter"
                @confirm="changeDate"
                @cancel="hiddenEvent"
            />
             <van-datetime-picker 
                v-else
                v-model="currentDate"
                type="date"
                :min-date="minDate"
                :max-date="maxDate"
                @confirm="changeDate"
                @cancel="hiddenEvent"
            />
        </van-popup>
    </div>
</template>

<script>
    export default {
        name: 'datePicker',
        props: {
            dateSelectVal: {
                type: String,
                default () {
                    return ''
                }
            },
            showBtn: {
                type: Boolean,
                default () {
                    return true
                }
            }
            // datePickerEvent: {
            //     type: Function,
            //     default () {
            //         return function () {}
            //     }
            // }
        },
        data () {
            return {
                // 日期选择组件
                showDatePiker: false,
                minDate: new Date(2019, 0, 1),
                maxDate: new Date(2030, 10, 1),
                currentDate: new Date()
            }
        },
        methods: {
            // datePiker 组件文案展示修改
            formatter (type, val) {
                if (type === 'year') {
                    return `${val}年`
                } else if (type === 'month') {
                    return `${val}月`
                }
                return val
            },
            datePickerEvent () {
                this.showDatePiker = true
            },
            // 选择日期 确定变化时
            changeDate (val) {
                console.log(val)
                const d = new Date(val)
                const year = d.getFullYear()
                let month = d.getMonth() + 1
                if (month < 10) month = `0${month}`
                let day = d.getDate()
                if (day < 10) day = `0${day}`
                this.$emit('dateUpdate', `${year}-${month}`)
                this.$emit('dateUpdateDay', `${year}/${month}/${day}`)
                this.showDatePiker = false
            },
            // 
            hiddenEvent () {
                this.showDatePiker = false
            }
        }
    }
</script>

<style lang="scss" scoped>
    .select-box {
        display: flex;
        flex-direction: row;
        justify-content: space-between;

        .second-title {
            height: 0.5rem;
            // width: 30%;
            display: flex;
            align-items: center;
            padding: 0 0.13rem;
            font-size: 0.14rem;
            line-height: 0.14rem;
            color: #2E2D2D;

            .icon-gold {
                margin-right: 0.07rem;
            }
        }
        .select-date {
            // flex: 1;
            box-sizing: border-box;
            padding: 0 0.12rem;
            // display: flex;
            
            .button-style {
                width: 30vw;
                height: 100%;
                font-size: 0.14rem;
                font-weight: 400;
                display: flex;
                justify-content: flex-end;
                align-items: center;
                background-color: #F5F8FC;
                border: none;

                .bottom-text {
                    margin-right: 0.12rem;
                    font-size: 0.14rem;
                    font-weight: 400;
                    color: #2E2D2D;
                }

                .bottom-text::after {
                    position: absolute;
                    // top: 50%;
                    // right: -4px;
                    margin-top: 0.05rem;
                    margin-left: 0.03rem;
                    border: 0.03rem solid;
                    border-color: transparent transparent currentColor currentColor;
                    transform: rotate(-45deg);
                    opacity: 0.8;
                    content: '';
                }
            }
        }

        /deep/ .van-picker__cancel {
            color: #848484;
        }
        .status{
            width: 100%;
            height: .5rem;
            line-height: .5rem;
            background:#fff;
            padding-left: .12rem;
            font-size: .15rem;
        }
	}
</style>
