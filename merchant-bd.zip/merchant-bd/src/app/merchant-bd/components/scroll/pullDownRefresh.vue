<template>
    <div>
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: 'pullDownRefresh',
        props: {
            threshold: {
                type: Number,
                default: 80
            }
        },
        mounted () {
            this.$nextTick(() => {
                this.onScrollEvent()
            })
        },
        beforeDestroy () {
            this.offScrollEvent()
        },
        methods: {
            // 滚动加载
            onScrollEvent () {
                const that = this
                let scrollTop = 0
                // 监听页面滚动
                let scrolled = window.pageYOffset || document.documentElement.scrollTop // 已滚动距离
                window.$(window).on('scroll', () => {
                    let direction = true
                    scrollTop = window.pageYOffset || document.documentElement.scrollTop // 当前滚动距离
                    const scrollDistance = document.body.clientHeight - document.documentElement.clientHeight // 可滚动距离
                    if (scrolled > scrollTop) {
                        // console.log('up')
                        direction = false
                    } else {
                        // console.log('down')
                        direction = true
                    }
                    // console.log('scrolled:', scrolled)
                    scrolled = scrollTop
                    if (scrollTop >= scrollDistance - that.threshold && direction) {
                        //
                        that.$emit('scroll')
                    }
                })
            },
            offScrollEvent () {
                // 取消监听页面滚动
                window.$(window).off('scroll')
            }

        }
    }
</script>

<style scoped>
    .name{
        color: red;
    }

</style>
