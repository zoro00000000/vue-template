<template>
    <bottom-popup title="选择地址" @close="close">
        <template v-slot:popup-container-header>
            <ul class="header-tab">
                <li :class="{'active': tab === 1}"
                    @click="resetProvince">
                    {{ currentProvince && !staticPlaceholder ? getChara(5,currentProvince) : placeholders.province }}
                </li>
                <li v-if="showCityTab" :class="{'active': tab === 2}"
                    @click="resetCity">
                    {{  currentCity && !staticPlaceholder ? getChara(5,currentCity) : placeholders.city }}
                </li>
                <li v-if="showCountryTab" :class="{'active': tab === 3}"
                    @click="resetCountry">
                    {{ currentCountry && !staticPlaceholder ? getChara(5,currentCountry) : placeholders.country }}
                </li>
                <li v-if="showTownTab" :class="{'active': tab === 4}">
                    {{ currentTown && !staticPlaceholder ? getChara(5,currentTown) : placeholders.town }}
                </li>
            </ul>
        </template>
        <div class="address-container">
            <swiper :options="swiperOption" ref="mySwiper">
                <swiper-slide class="swiper-no-swiping">
                    <ul  id="province-list">
                        <li v-for="(item) in provincesList"
                            :class="{'active': item.id == currentProvinceId}"
                            @click="chooseProvince(item)"
                            :key="item.id">
                            {{ item.name }} <span></span>
                        </li>
                    </ul>
                </swiper-slide>
                <swiper-slide class="swiper-no-swiping">
                    <ul  id="city-list">
                        <li v-for="(item) in citiesList"
                            :class="{'active': item.id == currentCityId}"
                            @click="chooseCity(item)"
                            :key="item.id">
                            {{ item.name }}<span></span>
                        </li>
                    </ul>
                </swiper-slide>
                <swiper-slide class="swiper-no-swiping">
                    <ul  id="area-list">
                        <li v-for="(item) in countriesList"
                            :class="{'active': item.id == currentCountryId}"
                            @click="chooseCountry(item)"
                            :key="item.id">
                            {{ item.name }}<span></span>
                        </li>
                    </ul>
                </swiper-slide>
                <swiper-slide class="swiper-no-swiping">
                    <ul  id="town-list">
                        <li v-for="(item) in townsList"
                            :class="{'active': item.id == currentTownId}"
                            @click="chooseTown(item)"
                            :key="item.id">
                            {{ item.name }}<span></span>
                        </li>
                    </ul>
                </swiper-slide>
            </swiper>
        </div>
    </bottom-popup>
</template>
<script>
    /* eslint-disable */
    import { Swiper, SwiperSlide } from 'vue-awesome-swiper'
    import { queryAdress } from '@/merchant-bd/api'
    import bottomPopup from './bottomPopup'
    // const $ = window.$
    export default {
        name: 'v-distpicker',
        components: {
            bottomPopup,
            Swiper,
            SwiperSlide
        },
        props: {
            province: { type: [String, Number], default: '' },
            city: { type: [String, Number], default: '' },
            country: { type: [String, Number], default: '' },
            town: { type: [String, Number], default: '' },

            provinceId: { type: [String, Number], default: '' },
            cityId: { type: [String, Number], default: '' },
            countryId: { type: [String, Number], default: '' },
            townId: { type: [String, Number], default: '' },

            type: { type: String, default: '' },
            hideArea: { type: Boolean, default: false },
            onlyProvince: { type: Boolean, default: false },
            staticPlaceholder: { type: Boolean, default: false },
            placeholders: {
                type: Object,
                default () {
                    return {
                        province: '请选择',
                        city: '请选择',
                        country: '请选择',
                        town: '请选择'
                    }
                }
            },
            disabled: { type: Boolean, default: false },
            provinceDisabled: { type: Boolean, default: false },
            cityDisabled: { type: Boolean, default: false },
            areaDisabled: { type: Boolean, default: false },
            // 新增展示层级
            showTier: {
                type: Number,
                default: 4
            }
        },
        data () {
            return {
                tab: 1,
                showCityTab: false,
                showCountryTab: false,
                showTownTab: false,
                //
                currentProvince: this.province || this.placeholders.province,
                currentCity: this.city || this.placeholders.city,
                currentCountry: this.country || this.placeholders.country,
                currentTown: this.town || this.placeholders.town,

                currentProvinceId: this.provinceId,
                currentCityId: this.cityId,
                currentCountryId: this.countryId,
                currentTownId: this.townId,

                // my
                provincesList: [],
                citiesList: [],
                countriesList: [],
                townsList: [],
                queryProvinceOk: false,
                queryCitiesOk: false,
                queryCountriesOk: false,
                queryTownOk: false,
                //
                show: false,
                swiperOption: {}
            }
        },
        created () {
            this.showing()
        },
        computed: {
            swiper () {
                return this.$refs.mySwiper.$swiper
            }
        },
        watch: {
            tab () {
                this.swiper.slideTo(this.tab - 1, 300, false)
            }
        },
        methods: {
            showing () {
                this.initData()
            },
            close () {
                this.$emit('close')
            },
            initData () {
                if (this.showTier === 4) {
                    console.log('如果是4级展示')
                    if (this.town) {
                        this.tab = 4
                        this.showTownTab = true
                        this.showCountryTab = true
                        this.showCityTab = true
                        this.getTown(this.countryId)
                    } else if (this.country) {
                        this.tab = 3
                        this.showTownTab = false
                        this.showCountryTab = true
                        this.showCityTab = true
                        this.getCounty(this.cityId)
                    } else if (this.city) {
                        this.tab = 2
                        this.showTownTab = false
                        this.showCountryTab = false
                        this.showCityTab = true
                        this.getCity(this.provinceId)
                    } else {
                        this.getProvince()
                    }
                } else {
                    console.log('如果是2级展示')
                    if (this.city) {
                        this.tab = 2
                        this.showTownTab = false
                        this.showCountryTab = false
                        this.showCityTab = true
                        this.getCity(this.provinceId)
                    } else {
                        this.getProvince()
                    }
                }
            },
            resetProvince () {
                this.tab = 1
                this.showCityTab = false
                this.showCountryTab = false
                this.showTownTab = false
                if (!this.provincesList.length) {
                    // console.log(this.currentProvince)
                    this.getProvince().then(() => {
                        const index = $('#province-list .active').index()
                        if (index < 0) {
                            return
                        }
                        let height = $('#province-list li').css('height')
                        if (!height) {
                            height = 0
                        } else {
                            // eslint-disable-next-line radix
                            height = parseInt(height)
                        }
                        $('#province-list').scrollTop(height * index)
                    })
                } else {
                    const index = $('#province-list .active').index()
                    if (index < 0) {
                        return
                    }
                    let height = $('#province-list li').css('height')
                    if (!height) {
                        height = 0
                    } else {
                        height = parseInt(height)
                    }
                    $('#province-list').scrollTop(height * index)
                }
                // 使元素滚动到适当位置
                // let index = this.provincesList.indexOf(this.currentProvince)
            },
            resetCity () {
                this.tab = 2
                this.showCityTab = true
                this.showCountryTab = false
                this.showTownTab = false
                if (!this.citiesList.length) {
                    this.getCity(this.currentProvinceId).then(() => {
                        const index = $('#city-list .active').index()
                        if (index < 0) {
                            return
                        }
                        let height = $('#city-list li').css('height')
                        if (!height) {
                            height = 0
                        } else {
                            height = parseInt(height)
                        }
                        $('#city-list').scrollTop(height * index)
                    })
                } else {
                    const index = $('#city-list .active').index()
                    if (index < 0) {
                        return
                    }
                    let height = $('#city-list li').css('height')
                    if (!height) {
                        height = 0
                    } else {
                        height = parseInt(height)
                    }
                    $('#city-list').scrollTop(height * index)
                }
            },
            resetCountry () {
                this.tab = 3
                this.showCountryTab = true
                this.showTownTab = false
                if (!this.countriesList.length) {
                    this.getCounty(this.currentCityId).then(() => {
                        const index = $('#country-list .active').index()
                        if (index < 0) {
                            return
                        }
                        let height = $('#country-list li').css('height')
                        if (!height) {
                            height = 0
                        } else {
                            height = parseInt(height)
                        }
                        $('#country-list').scrollTop(height * index)
                    })
                } else {
                    const index = $('#country-list .active').index()
                    if (index < 0) {
                        return
                    }
                    $('#country-list').scrollTop(index * 37)
                }
            },
            // item 为数字  index 为 文字
            chooseProvince (item) {
                this.currentProvince = item.name
                this.currentProvinceId = item.id
                this.tab = 2
                this.showCityTab = true
                this.showCountryTab = false
                this.showTownTab = false

                this.currentCity = this.placeholders.city
                this.currentCountry = this.placeholders.country
                this.getCity(item.id)
            },
            chooseCity (item) {
                this.currentCity = item.name
                this.currentCityId = item.id
                if (this.showTier === 4) {
                    this.tab = 3
                    this.showCityTab = true
                    this.showCountryTab = true
                    this.showTownTab = false

                    this.currentCountry = this.placeholders.country
                    this.currentTown = this.placeholders.town
                    this.getCounty(item.id)
                } else {
                    this.$emit('selected', {
                        province: this.currentProvince,
                        city: this.currentCity,
                        provinceId: this.currentProvinceId,
                        cityId: this.currentCityId,
                    })
                }
            },
            chooseCountry (item) {
                const that = this
                this.currentCountry = item.name
                this.currentCountryId = item.id
                this.queryTownOk = false
                this.getTown(item.id).then(() => {

                    if (this.queryTownOk && this.townsList && JSON.stringify(this.townsList) != '[]') {
                        // 四级地址存在，需要继续选择
                        that.tab = 4
                        that.showCityTab = true
                        that.showCountryTab = true
                        that.showTownTab = true
                        that.currentTown = that.placeholders.town
                        that.currentTownId = ''
                    } else if (this.queryTownOk && !this.townsList) { // 没有数据了
                        that.$emit('selected', {
                            province: that.currentProvince,
                            city: that.currentCity,
                            country: that.currentCountry,
                            town: '',
                            provinceId: that.currentProvinceId,
                            cityId: that.currentCityId,
                            countryId: that.currentCountryId,
                            townId: 0
                        })
                    }
                })
            },
            chooseTown (item) {
                this.currentTown = item.name
                this.currentTownId = item.id
                this.$emit('selected', {
                    province: this.currentProvince,
                    city: this.currentCity,
                    country: this.currentCountry,
                    town: this.currentTown,
                    provinceId: this.currentProvinceId,
                    cityId: this.currentCityId,
                    countryId: this.currentCountryId,
                    townId: this.currentTownId
                })
            },
          
            getProvince () {
                const that = this
                return queryAdress({parentId: null}, res => {
                  console.log(res)
                  if (res && res.result && res.result.code === '0000') {
                    that.provincesList = res.data.list
                    that.queryProvinceOk = true
                  }else {
                    this.$toast(res.result.code)
                    that.provincesList = []
                    that.queryProvinceOk = false
                  }
                })
            },
            getCity (areaId) {
                this.currentTown = this.placeholders.town
                this.currentCityId = ''
                this.currentCountryId = ''
                this.currentTownId = ''
                const that = this
                return queryAdress({parentId: areaId}, res => {
                  if (res && res.result && res.result.code === '0000') {
                    that.citiesList = res.data.list
                    that.queryCitiesOk = true
                  }else {
                    this.$toast(res.result.code)
                    that.citiesList = []
                    that.queryCitiesOk = false
                  }
                })
            },
            getCounty (areaId) {
                this.currentCountryId = ''
                this.currentTownId = ''
                const that = this
              return queryAdress({parentId: areaId}, res => {
                if (res && res.result && res.result.code === '0000') {
                  that.countriesList = res.data.list
                  that.queryCountriesOk = true
                }else {
                  this.$toast(res.result.code)
                  that.countriesList = []
                  that.queryCountriesOk = false
                }
              })
            },
            getTown (areaId) {
                const that = this
                return queryAdress({parentId: areaId}, res => {
                  if (res && res.result && res.result.code === '0000') {
                    if(res.data.list && JSON.stringify(res.data.list) != '[]'){
                      that.townsList = res.data.list
                    } else {
                      that.townsList = null
                    }
                    that.queryTownOk = true
                  }else {
                    this.$toast(res.result.code)
                    that.townsList = null
                    that.queryTownOk = false
                  }
                })
            },
            // 获取规定长度的字符串，超过部分...
            getChara (length, str) {
                if (!str) {
                    return ''
                }
                if (length >= str.length) {
                    return str
                }
                return `${str.slice(0, length)}...`
            }
        }
    }
</script>

<!--suppress Stylelint -->
<style lang="scss" scoped>

    ul {
        margin: 0;
        padding: 0;

        li {
            list-style: none;
        }
    }

    ul.header-tab {
        background: rgba(249,249,249,1);
        display: flex;
        justify-content: flex-start;
        align-items: stretch;
        margin-top: -0.07rem;
        padding-left: 0.05rem;

        li {
            padding: 0 0.02rem;
            font-size: 0.14rem;
            color: #444;
            height: 0.3rem;
            line-height: 0.3rem;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            position: relative;
            margin-right: 0.14rem;

            &.active {
                color: #F0250F;

                &::after{
                    content: " ";
                    pointer-events: none; //表示该元素永远不会作为鼠标点击的目标
                    display: block;
                    position: absolute;
                  border-bottom: 1px solid #F0250F;
                    box-sizing: border-box;
                    width: 0.3rem;
                    height: 100%;
                    left: 50%;
                    bottom: 0rem;
                    transform: translate3d(-50%,0%,0);
                }
            }
        }
    }

    .address-container {
        background-color: #fff;

        ul {
            height: 2.8rem;
            overflow-x: scroll;
            -webkit-overflow-scrolling: touch;
            -ms-overflow-style: -ms-autohiding-scrollbar;
            padding-bottom: 0.3rem;
            box-sizing: border-box;

            li {
                margin-left: .16rem;
                height: 0.56rem;
                line-height: 0.56rem;
                font-size: 0.16rem;
                color: #444;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                border-bottom: 1px solid rgba(238,238,238,0.5);

                span{
                    display: none;
                }

                &.active {
                    span{
                        display: inline-block;
                        width: 0.13rem;
                        height: 0.13rem;
                        margin-left: 0.09rem;
                        background-size: 100% 100%;
                        background-repeat: no-repeat;
                        background-position: center;
                    }
                }
            }
        }
    }
</style>
