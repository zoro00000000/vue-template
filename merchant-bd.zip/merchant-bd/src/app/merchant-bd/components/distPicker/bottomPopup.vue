<template>
    <div class="fadeIn popup-container">
        <div class="popup-container-layer" @touchmove.stop.prevent></div>
        <div class="popup-container-main">
            <div class="popup-container-header" @touchmove.stop.prevent>
                <div class="df popup-container-nav">
                    <img v-if="backIcon" @click="back"  alt="" class="leftIcon">
                    <span v-else style="display: inline-block;width: 0.1rem;"> </span>
                    <span class="popup-container-title">{{title}}</span>
                    <img @click="close"  alt="" src="@/merchant-bd/assets/img/common/close.png" class="rightIcon">
                </div>
                <slot name="popup-container-header">
                </slot>
            </div>
            <div class="popup-container-content">
                <slot></slot>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data () {
            return {

            }
        },
        components: {

        },
        props: {
            title: {
                type: String,
                default: ''
            },
            backIcon: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            close () {
                this.$emit('close')
            },
            back () {
                this.$emit('back')
            }
        }

    }
</script>
<style lang="scss" scoped>
    .popup-container{
        position: fixed;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        z-index: 999;
        background: rgba(0,0,0,.5);

        /*.popup-container-layer{*/
        /*    position: absolute;*/
        /*    width: 100%;*/
        /*    height: 100%;*/
        /*    left: 0;*/
        /*    top: 0;*/
        /*    background: rgba(0,0,0,.5);*/
        /*}*/

        .popup-container-main{
            width: 100%;
            height: 3.43rem;
            position: absolute;
            bottom: 0;
            background: rgba(0,0,0,.5);

            .popup-container-header{
                background: rgba(249,249,249,1);
                border-radius: 0.08rem 0.08rem 0px 0px;

                .popup-container-nav{
                    padding: 0.18rem 0.16rem 0.17rem 0.16rem;
                    justify-content: space-between;
                    display: flex;
                }

                .rightIcon{
                    width: 0.16rem;
                    height: 0.16rem;
                }

                .leftIcon{
                    width: 0.1rem;
                    height: 0.18rem;
                }

                .popup-container-title{
                    color: #444;
                    font-size: 0.16rem;
                }
            }

        }
    }

    .fadeIn{
        animation: fadeIn 0.2s ease-in both;
        -webkit-animation: fadeIn 0.2s ease-in both;
    }

    @-webkit-keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }
</style>
