<template>
    <div class="empty-palceholder-container">
        <div class="empty-box">
            <div class="empty-image-box">
                <img v-if="!loadingStatus" width="100%" height="100%" src="../../assets/img/empty.png" />
                <van-loading v-if="loadingStatus" size="0.4rem" />
            </div>
            <div v-if="!loadingStatus" class="image-title">暂无数据</div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'emptyPalceholder',
        props: {
            loadingStatus: {
                type: Boolean,
                default () {
                    return false
                }
            }
        },
        data () {
            return {}
        },
        created () {}
    }
</script>

<style lang="scss" scoped>
.empty-palceholder-container {
    width: 100%;
    height: 2.16rem;
    display: flex;
    justify-content: center;
    align-items: center;

    .empty-box {
        .empty-image-box {
            width: 0.8rem;
            height: 0.8rem;
            text-align: center;

            img {
                display: block;
            }
        }

        .image-title {
            margin-top: 0.16rem;
            text-align: center;
            font-size: 0.13rem;
            line-height: 0.13rem;
            color: #2E2D2D;
        }
    }
}
</style>
