<template>
    <van-form @submit="onSubmit">
        <slot></slot>
    </van-form>
</template>

<script>
    export default {
        methods: {
            onSubmit (values) {
                this.$emit('fromSubmit', values)
            }
        }
    }
</script>

<style lang = "scss" scoped>
</style>
