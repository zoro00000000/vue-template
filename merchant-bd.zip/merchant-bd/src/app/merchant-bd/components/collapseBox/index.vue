<template>
    <div class="collapse-container">
        <van-collapse v-model="activeNames" :border="true">
            <van-collapse-item 
                :title="collapseTitle"
                size="large"
                :border="true"
                class="collapse-style"
            >
                <!-- {{collapseContent}} -->
                <!-- <div v-vueInnerHtml:val="collapseContent"></div> -->
                <div class="collapse-text">{{collapseText}}</div>

                <div class="collapse-img" v-for="(img, index) in collapseImgs" :key="index">
                    <img width="100%" height="auto" :src="imgUrl(img)" />
                </div>
            </van-collapse-item>
        </van-collapse>
    </div>
</template>

<script>
    import { imgHost } from '@/merchant-bd/utils/constV'

    export default {
        name: 'collapseBox',
        props: {
            collapseTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            collapseText: {
                type: String,
                default () {
                    return ''
                }
            },
            collapseImgs: {
                type: Array,
                default () {
                    return []
                }
            }
        },
        data () {
            return {
                activeNames: ['1']
            }
        },
        methods: {
            // url 拼 host
            imgUrl (url) {
                return imgHost + url
            }
        }
    }
</script>

<style lang="scss" scoped>
.collapse-container {
    width: 100%;
    height: auto;
    margin-bottom: 0.12rem;

    /deep/ .van-collapse-item__title {
        height: 0.5rem;
    }

    /deep/ .van-collapse-item__title .van-cell__title {
        font-size: 0.15rem;
        color: #2E2D2D;
        font-weight: 500;
    }

    .collapse-style {
        .collapse-text {
            font-size: 0.13rem;
            color: #848484;
            font-weight: 400;
            line-height: 20px;
            text-align: justify;
        }

        .collapse-img {
            margin-top: 0.12rem;
            width: 100%;
            height: auto;
            overflow: hidden;
            border-radius: 0.04rem;
        }
    }
}
</style>
