<template>
    <div class="text-cell-container">
        <div class="left-title">{{leftTitle}}</div>
        <div class="right-title">{{rightTitle}}</div>
    </div>
</template>

<script>
    export default {
        name: 'textCell',
        props: {
            leftTitle: {
                type: String,
                default () {
                    return ''
                }
            },
            rightTitle: {
                type: String,
                default () {
                    return ''
                }
            }
        },
        data () {
            return {}
        }
    }
</script>

<style lang="scss" scoped>
.text-cell-container {
    width: 100%;
    padding: 0.16rem 0.24rem;
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left-title {
        font-size: 0.15rem;
        line-height: 0.15rem;
        font-weight: 400;
        color: #2E2D2D;
    }

    .right-title {
        font-size: 0.12rem;
        line-height: 0.12rem;
        font-weight: 400;
        color: #848484;
    }
}
</style>
