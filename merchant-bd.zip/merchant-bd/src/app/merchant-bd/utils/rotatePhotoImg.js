import EXIF from 'exif-js'

// 对图片旋转处理
const rotateImg = (img, direction, canvas) => {
    console.log('开始旋转图片')
    // 图片旋转4次后回到原方向
    if (img == null) return
    const { height } = img
    const { width } = img
    let step = 2

    if (direction == 'right') {
        step++
    } else if (direction == 'left') {
        step--
    } else if (direction == 'horizen') {
        // 不处理
        step = 2
    }
    // 旋转角度以弧度值为参数
    const degree = step * 90 * Math.PI / 180
    const ctx = canvas.getContext('2d')
    switch (step) {
    case 0:
        canvas.width = width
        canvas.height = height
        ctx.drawImage(img, 0, 0)
        break
    case 1:
        canvas.width = height
        canvas.height = width
        ctx.rotate(degree)
        ctx.drawImage(img, 0, -height)
        break
    case 2:
        canvas.width = width
        canvas.height = height
        ctx.rotate(degree)
        ctx.drawImage(img, -width, -height)
        break
    case 3:
        canvas.width = height
        canvas.height = width
        ctx.rotate(degree)
        ctx.drawImage(img, -width, 0)
        break
    default:
        break
    }
    console.log('结束旋转图片')
}

// 将base64转换为文件
const convertBase64UrlToBlob = (dataurl, filename) => {
    const arr = dataurl.split(',')
    const mime = arr[0].match(/:(.*?);/)[1]
    const bstr = atob(arr[1]); let n = bstr.length; const 
        u8arr = new Uint8Array(n)
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
    }
    return new File([u8arr], filename, { type: mime })
}

/**
 * ? 图片旋转方法
 * 
 * @param {*} file 
 * @param {*} type 
 */
export const rotatePhotoImg = (file, type) => new Promise(reject => {
    EXIF.getData(file, () => {
        // 获取图片信息
        const Orientation = EXIF.getTag(file, 'Orientation')
        console.log('Orientation>>>>>>', Orientation)

        // 转换成base64
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = e => {
            if (Orientation == 1 || !Orientation) {
                console.log('EXIF：图片无需处理')
                let base64Img = e.target.result
                // return e.target.result
                if (type === 'base64') {
                    // 返回base64图片
                    reject(base64Img)
                    // return base64Img
                } else {
                    // 输出转换后的流
                    // base64Img = convertBase64UrlToBlob(base64Img, file.type)
                    // 'image/jpeg'
                    base64Img = convertBase64UrlToBlob(base64Img, file.type)
                    reject(base64Img)
                    // return convertBase64UrlToBlob(base64Img, file.type)
                }
            } else {
                console.log('EXIF：图片进行旋转处理')
                const uploadBase64 = new Image()
                uploadBase64.src = e.target.result

                uploadBase64.onload = function () {
                    // 修正旋转图片
                    const expectWidth = uploadBase64.width
                    const expectHeight = uploadBase64.height
        
                    const canvas = document.createElement('canvas')
                    const ctx = canvas.getContext('2d')
                    canvas.width = expectWidth
                    canvas.height = expectHeight
        
                    ctx.drawImage(uploadBase64, 0, 0, expectWidth, expectHeight)
                    let base64 = null
        
                    if (Orientation !== '' && Orientation != 1) {
                        switch (Orientation) {
                        case 6:
                            console.log('顺时针旋转270度')
                            rotateImg(uploadBase64, 'left', canvas)
                            break
                        case 8:
                            console.log('顺时针旋转90度')
                            rotateImg(uploadBase64, 'right', canvas)
                            break
                        case 3:
                            console.log('顺时针旋转180度')
                            rotateImg(uploadBase64, 'horizen', canvas)
                            break
                        default:
                            break
                        }

                        if (type === 'base64') {
                            // 输出转换后的base64图片
                            base64 = canvas.toDataURL(file.type, 1)
                            reject(base64)
                            // return base64
                        } else {
                            // 输出转换后的流
                            const newBlob = convertBase64UrlToBlob(base64, file.type)
                            reject(newBlob)
                            // return newBlob
                        }
                    }
                }
            }
        }
    })
}).catch(e => { console.log(e) })
