/* eslint-disable */
!function (e, t) {
    "object" == typeof exports && "undefined" != typeof module ? t(exports) : "function" == typeof define && define.amd ? define(["exports"], t) : t((e = e || self).jme = {})
}(this, function (e) {
    "use strict";
    var t, n = {
        default: void 0, call: function (e, t, n) {
            var a = "";
            "function" == typeof t && (n = t, t = {});
            var s = {data: void 0 === t ? null : t};
            if ("function" == typeof n) {
                var o = "dscb" + window.dscb++;
                window[o] = n, s._dscbstub = o
            }
            return s = JSON.stringify(s), window._dsbridge ? a = _dsbridge.call(e, s) : (window._dswk || -1 != navigator.userAgent.indexOf("_dsbridge")) && (a = prompt("_dsbridge=" + e, s)), JSON.parse(a || "{}").data
        }, register: function (e, t, a) {
            var s = a ? window._dsaf : window._dsf;
            window._dsInit || (window._dsInit = !0, setTimeout(function () {
                n.call("_dsb.dsinit")
            }, 0)), "object" == typeof t ? s._obs[e] = t : s[e] = t
        }, registerAsyn: function (e, t) {
            this.register(e, t, !0)
        }, hasNativeMethod: function (e, t) {
            return this.call("_dsb.hasNativeMethod", {name: e, type: t || "all"})
        }, disableJavascriptDialogBlock: function (e) {
            this.call("_dsb.disableJavascriptDialogBlock", {disable: !1 !== e})
        }
    };
    !function () {
        if (!window._dsf) {
            var e = {
                _dsf: {_obs: {}}, _dsaf: {_obs: {}}, dscb: 0, dsBridge: n, close: function () {
                    n.call("_dsb.closePage")
                }, _handleMessageFromNative: function (e) {
                    var t = JSON.parse(e.data), a = {id: e.callbackId, complete: !0}, s = this._dsf[e.method],
                        o = this._dsaf[e.method], r = function (e, s) {
                            a.data = e.apply(s, t), n.call("_dsb.returnValue", a)
                        }, i = function (e, s) {
                            t.push(function (e, t) {
                                a.data = e, a.complete = !1 !== t, n.call("_dsb.returnValue", a)
                            }), e.apply(s, t)
                        };
                    if (s) r(s, this._dsf); else if (o) i(o, this._dsaf); else {
                        var c = e.method.split(".");
                        if (c.length < 2) return;
                        var l = c.pop(), d = c.join("."), u = this._dsf._obs, f = u[d] || {}, g = f[l];
                        if (g && "function" == typeof g) return void r(g, f);
                        if ((g = (f = (u = this._dsaf._obs)[d] || {})[l]) && "function" == typeof g) return void i(g, f)
                    }
                }
            };
            for (var t in e) window[t] = e[t];
            n.register("_hasJavascriptMethod", function (e, t) {
                var n = e.split(".");
                if (n.length < 2) return !(!_dsf[n] && !_dsaf[n]);
                e = n.pop();
                var a = n.join("."), s = _dsf._obs[a] || _dsaf._obs[a];
                return s && !!s[e]
            })
        }
    }(), window.dsBridge ? t = function (e, t) {
        dsBridge.call("onAjaxRequest", e, function (n) {
            n = JSON.parse(n), "stream" === e.responseType && function (e) {
                var t = e.headers || {}, n = (t["content-type"] || t["Content-Type"] || "").toString().toLowerCase();
                -1 !== n.indexOf("image") && -1 === e.responseText.indexOf("base64") && (e.responseText = "data:" + n + ";base64," + e.responseText)
            }(n), t(n)
        })
    } : console.error("dsBridge is not exist!");
    var a = "undefined" != typeof document;

    function s(e) {
        return e.replace(/(^\s*)|(\s*$)/g, "")
    }

    function o() {
        if (window && window.location.protocol.indexOf("file") > -1) {
            var e = function (e) {
                var t = function () {
                    this.requestHeaders = {}, this.readyState = 0, this.timeout = 0, this.responseURL = "", this.responseHeaders = {}
                };
                return t.prototype._call = function (e) {
                    this[e] && this[e].apply(this, [].splice.call(arguments, 1))
                }, t.prototype._changeReadyState = function (e) {
                    this.readyState = e, this._call("onreadystatechange")
                }, t.prototype.open = function (e, t) {
                    if (this.method = e, t) {
                        if (0 !== (t = s(t)).indexOf("http") && a) {
                            var n = document.createElement("a");
                            n.href = t, t = n.href
                        }
                    } else t = location.href;
                    this.responseURL = t, this._changeReadyState(1)
                }, t.prototype.send = function (t) {
                    var n = this;
                    t = t || null;
                    var s = this;
                    if (e) {
                        var o, r = {method: s.method, url: s.responseURL, headers: s.requestHeaders || {}, body: t};
                        !function (e, t) {
                            for (var n in t) e.hasOwnProperty(n) ? this.isObject(t[n], 1) && this.isObject(e[n], 1) && this.merge(e[n], t[n]) : e[n] = t[n]
                        }(r, s._options || {}), "GET" === r.method && (r.body = null), s._changeReadyState(3), s.timeout = s.timeout || 0, s.timeout > 0 && (o = setTimeout(function () {
                            3 === s.readyState && (n._call("onloadend"), s._changeReadyState(0), s._call("ontimeout"))
                        }, s.timeout)), r.timeout = s.timeout, e(r, function (e) {
                            function t(t) {
                                var n = e[t];
                                return delete e[t], n
                            }

                            if (3 === s.readyState) {
                                clearTimeout(o), s.status = t("statusCode") - 0;
                                var n = t("responseText"), r = t("statusMessage");
                                if (s.status) {
                                    var i = t("headers"), c = {};
                                    for (var l in i) {
                                        var d = i[l], u = l.toLowerCase();
                                        "object" == typeof d ? c[u] = d : (c[u] = c[u] || [], c[u].push(d))
                                    }
                                    var f = c["set-cookie"];
                                    a && f && f.forEach(function (e) {
                                        document.cookie = e.replace(/;\s*httpOnly/gi, "")
                                    }), s.responseHeaders = c, s.statusText = r || "", s.response = s.responseText = n, s._response = e, s._changeReadyState(4), s._call("onload")
                                } else s.statusText = n, s._call("onerror", {msg: r});
                                s._call("onloadend")
                            }
                        })
                    } else console.error("Ajax require adapter")
                }, t.prototype.setRequestHeader = function (e, t) {
                    this.requestHeaders[s(e)] = t
                }, t.prototype.getResponseHeader = function (e) {
                    return (this.responseHeaders[e.toLowerCase()] || "").toString() || null
                }, t.prototype.getAllResponseHeaders = function () {
                    var e = "";
                    for (var t in this.responseHeaders) e += t + ":" + this.getResponseHeader(t) + "\r\n";
                    return e || null
                }, t.prototype.abort = function (e) {
                    this._changeReadyState(0), this._call("onerror", {msg: e}), this._call("onloadend")
                }, t.setAdapter = function (t) {
                    e = t
                }, t
            }(t);
            XMLHttpRequest = e
        }
    }

    var r = {
        getDeviceInfo: function () {
            return dsBridge.call("devinfo.deviceInfo")
        }
    }, i = {
        getAppInfo: function () {
            return dsBridge.call("appInfo.appInfo")
        }, canOpenUrl: function () {
            return dsBridge.call("application.canOpenUrl")
        }, openAppletUrl: function (e) {
            dsBridge.call("application.openUrl", {url: e.url}, function (t) {
                e.success && e.success(t)
            })
        }
    }, c = {
        openCamera: function (e) {
            dsBridge.call("camera.shooting", {}, function (t) {
                e && e(t)
            })
        }, openCameraEx: function (e) {
            dsBridge.call("camera.shooting", e, function (t) {
                e.callback && e.callback(t)
            })
        }
    }, l = {
        chooseImage: function (e) {
            var t = Object.assign({multiple: !1, count: 9, success: null}, e);
            t.multiple ? dsBridge.call("photoalbum.chooseASetPhoto", {count: t.count}, function (e) {
                t.success && t.success(e)
            }) : dsBridge.call("photoalbum.chooseAPhoto", function (e) {
                t.success && t.success(e)
            })
        }, getImageBase64: function (e) {
            dsBridge.call("photoalbum.chooseAPhoto", function (t) {
                var n = dsBridge.call("file.getFileData", {filePath: t.localUrl, format: "base64"});
                e.success && e.success({base64: "data:image/jpeg;base64," + n})
            })
        }
    }, d = {
        setNaviBarHidden: function (e) {
            null === e && (t = !0);
            var t = e;
            dsBridge.call("browser.setNaviBarHidden", {isHidden: t})
        }, closeWeb: function () {
            dsBridge.call("browser.close")
        }, refreshWeb: function () {
            dsBridge.call("browser.refresh")
        }, goback: function () {
            dsBridge.call("browser.goback")
        }, forward: function () {
            dsBridge.call("browser.forward")
        }, showError: function (e) {
            var t = Object.assign({errCode: null, message: ""}, e);
            dsBridge.call("browser.showError", {errCode: t.errCode, message: t.message})
        }, openUrl: function (e) {
            var t = Object.assign({type: 1, url: "", isHideNaviBar: !1}, e),
                n = {url: t.url, isHideNaviBar: t.isHideNaviBar};
            switch (t.type) {
                case 1:
                    dsBridge.call("browser.openUrl", n);
                    break;
                case 2:
                    dsBridge.call("browser.openLocalUrl", n);
                    break;
                case 3:
                    dsBridge.call("browser.openDeepLink", n);
                    break;
                case 4:
                    dsBridge.call("browser.openSafariUrl", {url: t.url})
            }
        }, setShareButtonHidden: function () {
            dsBridge.call("browser.setShareButtonHidden", {isHidden: !0})
        }, setShareButtonShow: function () {
            dsBridge.call("browser.setShareButtonHidden", {isHidden: !1})
        }, onKeyboardHeightChange: function (e) {
            dsBridge.call("browser.onKeyboardHeightChange", function (t) {
                e.change && e.change(t)
            })
        }, setPopAllowedLeftEdge: function (e) {
            dsBridge.call("browser.setPopAllowedLeftEdge", {persent: e.persent || 0})
        }
    }, u = {
        getNetworkStatus: function (e) {
            return dsBridge.call("network.networkStatus", function (t) {
                e && e({status: t})
            })
        }
    }, f = {
        scanCode: function (e) {
            dsBridge.call("imagescan.scanning", function (t) {
                e && e(t)
            })
        }, scanCodeEx: function (e) {
            var t = Object.assign({onlyFromCamera: !1, scanType: ["barCode", "qrCode"]}, e);
            dsBridge.call("imagescan.scanning", t, function (t) {
                e.callback && e.callback(t)
            })
        }
    }, g = {
        shareNormal: function (e, t) {
            var n = Object.assign({title: "", content: "", url: "", icon: ""}, e);
            dsBridge.call("share.share", n, function (e) {
                t && t(e)
            })
        }, shareCustom: function (e) {
            var t = Object.assign({title: "", content: "", url: "", icon: ""}, e.shareData),
                n = Object.assign({shareData: t, typeList: null}, e);
            dsBridge.call("share.shareCustom", n, function (t) {
                e.callback && e.callback(t)
            })
        }
    }, p = {
        setStorage: function (e) {
            dsBridge.call("storageKV.setObject", {obj: e.value, key: e.key})
        }, getStorage: function (e) {
            return dsBridge.call("storageKV.objForKey", {key: e.key})
        }, removeStorage: function (e) {
            dsBridge.call("storageKV.removeObjForKey", {key: e.key})
        }, clearStorage: function () {
            dsBridge.call("storageKV.clear")
        }
    }, h = {
        sendShareCardMessage: function (e) {
            var t = Object.assign({app: "", pin: "", type: 1, isSecret: !1}, e.session), n = Object.assign({
                session: t,
                url: "",
                title: "",
                content: "",
                icon: "",
                source: "",
                sourceIcon: ""
            }, e);
            dsBridge.call("im.sendShareCardMessage", n, function (t) {
                e.callback && e.callback(t)
            })
        }, openContactSelector: function (e) {
            var t = Object.assign({selected: null, title: "", maxNum: 50}, e);
            dsBridge.call("im.openContactSelector", t, function (t) {
                e.callback && e.callback(t)
            })
        }
    }, b = {
        startSpeechRecognition: function (e) {
            dsBridge.call("speechrecognition.startSpeechRecognition", function (t) {
                e.callback && e.callback(t)
            })
        }
    }, m = {
        portrait: function () {
            dsBridge.call("screencontrol.portrait")
        }, landscape: function () {
            dsBridge.call("screencontrol.landscape")
        }
    }, v = {
        getFileData: function (e) {
            var t = Object.assign({filePath: e.filePath || "", format: e.format || "base64"}, e);
            return "data:image/jpeg;base64," + dsBridge.call("file.getFileData", {
                filePath: t.filePath,
                format: t.format
            })
        }
    }, B = {
        getJDPinToken: function (e) {
            dsBridge.call("userinfo.getJDPinToken", {url: e.url}, function (t) {
                e.success && e.success(t)
            })
        }
    }, y = {
        getJDPinToken: function (e) {
            dsBridge.call("login.getJDPinToken", {url: e.url}, function (t) {
                e.callback && e.callback(t)
            })
        }, getOTPSeed: function (e) {
            var t = Object.assign({}, e);
            dsBridge.call("login.getOTPSeed", t, function (t) {
                e.callback && e.callback(t)
            })
        }, getOTP: function (e) {
            var t = Object.assign({length: 0}, e);
            dsBridge.call("login.getOTP", t, function (t) {
                e.callback && e.callback(t)
            })
        }
    };
    o(), e.initDsBridge = o, e.device = r, e.applet = i, e.camera = c, e.album = l, e.browser = d, e.network = u, e.scan = f, e.share = g, e.storage = p, e.im = h, e.speechrecognition = b, e.screen = m, e.file = v, e.user = B, e.login = y, e.version = "0.0.4", Object.defineProperty(e, "__esModule", {value: !0})
});
