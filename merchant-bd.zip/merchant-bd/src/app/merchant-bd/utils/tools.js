/* eslint-disable */
export const getUrlString = name => {
    const reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i')
    const r = window.location.search.substr(1).match(reg)
    if (r != null) return decodeURIComponent(r[2])
    return null
}

// 纵坐标格式化
export const amountFormat = value => {
    if (value == null || typeof (value) == 'undefined' || isNaN(value)) return ''
    const n = 2
    let wanStr = ''
    if (value >= 10000) {
        value /= 10000
        wanStr = '万'
    }
    value = `${parseFloat((`${value}`).replace(/[^\d\.-]/g, '')).toFixed(n)}`
    const l = value.split('.')[0].split('').reverse(); const
        r = value.split('.')[1]
    let t = ''
    for (let i = 0; i < l.length; i++) {
        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? ',' : '')
    }
    if (r == '00') {
        return t.split('').reverse().join('') + wanStr
    } else {
        return `${t.split('').reverse().join('')}.${r}${wanStr}`
    }
}
export const dateFormat = value => {
    if (value == null || typeof (value) == 'undefined' || isNaN(value)) return ''
    return value.substring(6,8)
    // return value
}

export function ruleTxt(data){
    let data1=data
    console.log("data--",data1)
    data1=data1.replace(/\%/g,"%25");
    data1=data1.replace(/\#/g,"%23");
    data1=data1.replace(/\&/g,"%26");
    data1=data1.replace(/\+/g,"%2B");
    data1=data1.replace(/\ /g,"%20");
    data1=data1.replace(/\//g,"%2F");
    data1=data1.replace(/\?/g,"%3F");
    data1=data1.replace(/\=/g,"%3D");
    return data1
}

/**
 * 时间戳转换成指定格式日期
 * @param formats(Y-m-d, Y-m-d H:i:s, Y年m月d日, Y年m月d日 H时i分)
 * @param timestamp 时间戳
 * */
export function timestampToYear(timestamp, formats,add) {
    if (!timestamp) return "";
    formats = formats || 'Y-m-d';
    let zero = function (value) {
        if (value < 10) {
            return '0' + value;
        }
        return value;
    };
    let myDate;
    if (timestamp && timestamp.toString().length === 10) {
        timestamp = parseInt(timestamp);
        myDate = new Date(timestamp * 1000);
    } else {
        timestamp = parseInt(timestamp);
        myDate = new Date(timestamp)
    }
    let year = myDate.getFullYear();
    let month = zero(myDate.getMonth() + 1);
    let day;
    if(add && add=="day1"){
        day = zero(myDate.getDate()+1);
    }else{
        day = zero(myDate.getDate());
    }
    //let day = zero(myDate.getDate());
    let hour = zero(myDate.getHours());
    let minite = zero(myDate.getMinutes());
    let second = zero(myDate.getSeconds());
    return formats.replace(/Y|m|d|H|i|s/ig, function (matches) {
        return ({
            Y: year,
            m: month,
            d: day,
            H: hour,
            i: minite,
            s: second
        })[matches];
    });
}