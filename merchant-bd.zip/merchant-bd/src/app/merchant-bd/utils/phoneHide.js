/**
 * 手机号脱敏方法
 * @param {phone} 手机号
 * @param {number} 脱敏个数
 */
export const phoneHide = (phone, number) => {
    const count = number || 4
    const newPhone = phone.split('')
    for (let i = 0; i < count; i++) {
        newPhone.splice(3 + i, 1, '*')
    }
    // console.log('newPhone:', newPhone.join(''))
    return newPhone.join('')
}
