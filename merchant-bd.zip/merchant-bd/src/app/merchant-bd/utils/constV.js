// 测试环境
/**
 * 图片拼接地址
 * @type {string}
 */
export const imgHost = 'https://m.360buyimg.com/yocial/'
