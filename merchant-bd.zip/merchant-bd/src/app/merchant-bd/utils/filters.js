import dayjs from 'dayjs'

export function dateFilter (time, format = 'YYYY.MM.DD HH:mm') {
    const date = dayjs(time)
    return dayjs(date).format(format)
}

export function numberFilter (number, fixed = 2) {
    if (number > 10000) {
        return Number((number / 10000).toFixed(fixed))
    } else {
        return number
    }
}
export function textLengthFilter (text, length) {
    if (!text) {
        return ''
    } else if (text.length <= length) {
        return text
    } else {
        return `${text.substring(0, length)}..`
    }
}

// 保留两位有效数字
export function toFixed2 (text) {
    return (Math.floor(text * 1000) / 1000).toFixed(2)
}

const ImgUrlTester = /^((http|https)?:)?\/\//
export function imageLoadFilter (src) {
    if (!src) {
        return ''
    }
    if (ImgUrlTester.test(src)) {
        return src
    } else {
        return `https://m.360buyimg.com/yocial/${src}`
    }
}

export default {
    install (Vue) {
        [
            { filter: dateFilter, name: 'dateFilter' },
            { filter: numberFilter, name: 'numberFilter' },
            { filter: imageLoadFilter, name: 'imageLoadFilter' },
            { filter: textLengthFilter, name: 'textLengthFilter' },
            { filter: toFixed2, name: 'toFixed2' }
        ].forEach(filter => {
            Vue.filter(filter.name, filter.filter)
        })
    }
}
