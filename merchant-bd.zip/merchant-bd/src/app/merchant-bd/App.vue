<template>
    <div>
        <!-- 全局返回按钮 -->
        <return-button v-if="showStatus"></return-button>

        <keep-alive>
            <router-view v-if="$route.meta.keepAlive"></router-view>
        </keep-alive>
        
        <router-view v-if="!$route.meta.keepAlive"></router-view>
    </div>
</template>

<script>
    // 引入 返回按钮
    import returnButton from '@/merchant-bd/components/returnBtn'

    export default {
        name: 'app',
        components: {
            returnButton
        },
        data () {
            return {
                freezeIdStatus: false,
                showStatus: true
            }
        },
        watch: {
        },
        created () {}
    }
</script>

<style lang="scss">
    @import "assets/css/_rem";
    html{
        background-color: #F5F8FC;
    }

    #app {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: center;
        color: #2c3e50;
        margin-top: 60px;
    }
</style>
