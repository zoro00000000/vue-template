import Vue from 'vue'
import VueRouter from 'vue-router'
import api from '@/merchant-bd/api/main'
import { Toast } from 'vant'
import routes from './routes'
import filterRouters from './filter'

Vue.use(VueRouter)

const routerPage = new VueRouter({
    routes,
    scrollBehavior (to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition
        } else {
            return { x: 0, y: 0 }
        }
    }
})
// 新增路由拦截
routerPage.beforeEach((to, from, next) => {
    if (filterRouters.indexOf(to.path) > -1) {
        console.log(1)
        // 当进入 代理系统 路由时
        api.performance.queryBDStaffInfoByPin({}, res => {
            console.log('res:', res)
            if (res.data.length > 0) {
                if (localStorage.getItem('organId')) {
                    res.data.map(item => {
                        if (item.organId === JSON.parse(localStorage.getItem('organId'))) {
                            if (item.freeze || item.organFreeze) {
                                // 企业 或 个人 状态冻结
                                next({
                                    path: '/permission/error',
                                    name: '/permission/error',
                                    query: {
                                        title: '企业账户、个人账户已被冻结，已无法正常使用系统，请联系相关工作人员处理!'
                                    }
                                })
                                return
                            } else if (item.mature) {
                                // 企业 或 个人 合同到期
                                next({
                                    path: '/permission/error',
                                    name: '/permission/error',
                                    query: {
                                        title: '合同已到期，已无法正常使用系统，请联系相关工作人员处理!'
                                    }
                                })
                                return
                            }
                        }
                        return item
                    }) 
                    next()
                } else {
                    localStorage.setItem('organId', JSON.stringify(res.data[0].organId))
                    localStorage.setItem('staffId', JSON.stringify(res.data[0].staffId))
                    // 1. 是通过接口获取新的 staffId
                    // 2. 直接跳转到首页
                    // 暂时先跳转套首页
                    if (res.data[0].freeze || res.data[0].organFreeze) {
                        // 企业 或 个人 状态冻结
                        next({
                            path: '/permission/error',
                            name: '/permission/error',
                            query: {
                                title: '企业账户、个人账户已被冻结，已无法正常使用系统，请联系相关工作人员处理!'
                            }
                        })
                    } else if (res.data[0].mature) {
                        // 企业 或 个人 合同到期
                        next({
                            path: '/permission/error',
                            name: '/permission/error',
                            query: {
                                title: '合同已到期，已无法正常使用系统，请联系相关工作人员处理!'
                            }
                        })
                    } else {
                        next({
                            path: '/business/performance/company'
                        })
                    }
                }
                // next()
            } else {
                // 如果无此员工的处理
                Toast('账户信息异常，无此员工数据！')
                next({
                    path: '/permission/error',
                    name: '/permission/error',
                    query: {
                        title: '该账户未创建或创建错误!'
                    }
                })
            }
        }).catch(e => {
            console.log(e)
            // 如果无此员工的处理
            Toast('网络请求异常！')
            next({
                path: '/permission/error',
                name: '/permission/error',
                query: {
                    title: '网络请求异常!'
                }
            })
        })
    } else {
        console.log(2)
        next()
    }
})

routerPage.afterEach((to, from) => {
    if (window.__qd__ && window.__qd__.page) {
        // 上报事件
        // console.log("上报事件")
        window.__qd__.page(to.fullPath, from.fullPath)
    }
    const title = to.meta.title || 'BD'
    document.title = title
})

export default routerPage
