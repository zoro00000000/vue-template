/**
 * 需要做 登录态校验的 页面
 */

// 需要过滤的路由
const filterRouters = [
    '/business/performance/company',
    '/business/performance/personal',
    '/business/performance/employee',
    '/business/performance/record',
    '/business/performance/exploit',
    '/business/my/questions',
    '/business/my/operation-log',
    '/business/my/approval',
    '/business/my/city-data',
    '/business/my/store-deal',
    '/business/my/success',
    '/business/manage',
    '/business/manage/change-log',
    '/business/manage/change-staff',
    '/business/manage/commission',
    '/company/myCompany',
    '/company/deliveryAddress',
    '/company/agencyArea',
    '/company/agencyShop',
    '/company/addWorker',
    '/company/result',
    '/company/accounts',
    '/business/my',
    '/business/freezeemploy',
    '/white-bd-entry'
]
export default filterRouters
