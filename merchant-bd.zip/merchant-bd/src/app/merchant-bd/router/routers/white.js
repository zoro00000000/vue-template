/**
 * ! BD系统 路由
 * ? 白名单 
 * 
 * @param {}
 */

const router = [
    // 新增 白名单 我的预览账号 路由
    {
        path: '/white',
        name: '/white',
        component: () => import('@/merchant-bd/pages/white/whiteList'),
        meta: {
            // hideReturn: true,
            title: '我的预览账号'
        }
    },
    {
        path: '/white-entry',
        name: '/white-entry',
        component: () => import('@/merchant-bd/pages/white/whiteEntry'),
        meta: {
            // hideReturn: true,
            title: '设置'
        }
    },
    {
        path: '/white-bd-entry',
        name: '/white-bd-entry',
        component: () => import('@/merchant-bd/pages/white/whiteBDEntry'),
        meta: {
            // hideReturn: true,
            title: '设置'
        }
    }
]

export default router
