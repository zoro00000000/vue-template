/**
 * ! 代理系统 路由
 * ? 我的企业——商户管理 
 * 
 * @param {}
 */

const router = [
    {
        path: '/business/my/questions',
        component: () => import('@/merchant-bd/pages/business/my/questions'),
        meta: {
            title: '帮助中心'
        }
    },
    {
        path: '/business/my/operation-log',
        component: () => import('@/merchant-bd/pages/business/my/operationLog'),
        meta: {
            title: '操作记录'
        }
    },
    {
        path: '/business/my/approval',
        name: '/business/my/approval',
        component: () => import('@/merchant-bd/pages/business/my/approval'),
        meta: {
            title: '待核佣金'
        }
    },
    {
        path: '/business/my/city-data',
        name: '/business/my/city-data',
        component: () => import('@/merchant-bd/pages/business/my/approval/cityData'),
        meta: {
            title: '待核佣金'
        }
    },
    {
        path: '/business/my/store-deal',
        name: '/business/my/store-deal',
        component: () => import('@/merchant-bd/pages/business/my/approval/storeDeal'),
        meta: {
            title: '商户交易佣金'
        }
    },
    // demo
    {
        path: '/business/my/success',
        component: () => import('@/merchant-bd/pages/business/my/success'),
        meta: {
            title: '结果'
        }
    },
    {
        path: '/business/manage',
        name: '/business/manage',
        component: () => import('@/merchant-bd/pages/business/manage/index'),
        meta: {
            title: '商户管理'
        }
    },
    {
        path: '/business/manage/change-log',
        name: '/business/manage/change-log',
        component: () => import('@/merchant-bd/pages/business/manage/changeLog'),
        meta: {
            title: '变更记录'
        }
    },
    {
        path: '/business/manage/change-staff',
        name: '/business/manage/change-staff',
        component: () => import('@/merchant-bd/pages/business/manage/changeStaff'),
        meta: {
            title: '员工变更'
        }
    },
    {
        path: '/business/manage/commission',
        name: '/business/manage/commission',
        component: () => import('@/merchant-bd/pages/business/manage/commission'),
        meta: {
            title: '佣金核发'
        }
    },
    {
        path: '/business/my',
        name: 'my',
        component: () => import('@/merchant-bd/pages/business/my'),
        meta: {
            title: '我的企业'
        }
    },
    {
        path: '/business/freezeemploy',
        component: () => import('@/merchant-bd/pages/business/freezeemploy/index'),
        meta: {
            title: '员工信息'
        }
    }
]

export default router
