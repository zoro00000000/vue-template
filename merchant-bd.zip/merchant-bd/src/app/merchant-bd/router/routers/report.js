/*
 * @Author: ZYZ
 * @Date: 2020-01-02 09:48:38
 * @LastEditTime: 2020-03-15 15:42:42
 * @LastEditors: Zhaoyongzhen
 * @Description: In User Settings Edit
 * @FilePath: /job/campus-consumer/develop/merchant-bd/src/router/routes.js
 */
import forbid from '@/merchant-bd/pages/error/forbid'
import reportDistrict from '@/merchant-bd/pages/report/ReportDistrict'
import reportProvincial from '@/merchant-bd/pages/report/ReportProvincial'
import reportPersonal from '@/merchant-bd/pages/report/ReportPersonal'

// import merchantEntry from '@/merchant-bd/pages/MerchantEntry'
// import merchantDetails from '@/merchant-bd/pages/MerchantDetails'
// import tradingRecord from '@/merchant-bd/pages/tradingRecord'
// import photoAlbum from '@/merchant-bd/pages/photoAlbum'
// import album from '../pages/album'
// import urlTest from '@/pages/urlTest'
// import updateMerchantInfo from '../pages/updateMerchantInfo'

export default [
    {
        path: '/updateMerchantInfo/:merchantId',
        component: () => import('@/merchant-bd/pages/merchant/updateMerchantInfo'),
        meta: {
            title: '修改商家'
        }
    },
    {
        path: '/merchantDetails/:merchantId/:status',
        component: () => import('@/merchant-bd/pages/merchant/MerchantDetails'),
        meta: {
            title: '商户详情'
        }
    },
    {
        path: '/merchantEntry',
        name: '/merchantEntry',
        component: () => import('@/merchant-bd/pages/merchant/MerchantEntry'),
        meta: {
            title: '新建商户',
            keepAlive: true,
            name: 'addMerchant'
        }
    },
    // {
    //     path: '/report/:duty/:erp',
    //     component: report,
    //     meta: {
    //         title: '战报'
    //     }
    // },
    {
        path: '/report-district/:erp',
        component: reportDistrict,
        meta: {
            hideReturn: true,
            title: '大区战报'
        }
    },
    {
        path: '/report-province/:erp',
        component: reportProvincial,
        meta: {
            hideReturn: true,
            title: '省主管战报'
        }
    },
    {
        path: '/report-personal/:erp',
        component: reportPersonal,
        meta: {
            hideReturn: true,
            title: '个人战报'
        }
    },
    {
        path: '/album/:merchantId',
        component: () => import('@/merchant-bd/pages/merchant/album'),
        meta: {
            title: '门店相册'
        }
    },
    {
        path: '/tradingRecord',
        component: () => import('@/merchant-bd/pages/merchant/tradingRecord'),
        name: 'tradingRecord',
        meta: {
            title: '合伙人邀请码关联'
        }
    },
    {
        path: '/photoAlbum',
        component: () => import('@/merchant-bd/pages/merchant/photoAlbum'),
        meta: {
            title: '相册'
        }
    },
    {
        path: '/forbid',
        component: forbid,
        meta: {
            hideReturn: true,
            title: '商户拓展管理系统'
        }
    },
    {
        path: '*',
        component: forbid,
        meta: {
            hideReturn: true,
            title: '商户拓展管理系统'
        }
    }
]
