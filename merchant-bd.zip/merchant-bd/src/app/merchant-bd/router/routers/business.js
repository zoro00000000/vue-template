/**
 * ! 代理系统 路由
 * ? 企业业绩 
 * 
 * @param {}
 */

const router = [
    /**
     * 新增 代理系统页面 路由
     */
    {
        path: '/business/performance/company',
        name: '/business/performance/company',
        component: () => import('@/merchant-bd/pages/business/performance/company'),
        meta: {
            hideReturn: true,
            title: '企业业绩'
        }
    },
    {
        path: '/business/performance/personal',
        name: '/business/performance/personal',
        component: () => import('@/merchant-bd/pages/business/performance/personal'),
        meta: {
            title: '个人业绩'
        }
    },
    {
        path: '/business/performance/employee',
        name: '/business/performance/employee',
        component: () => import('@/merchant-bd/pages/business/performance/employee'),
        meta: {
            title: '员工业绩'
        }
    },
    {
        path: '/business/performance/record',
        name: '/business/performance/record',
        component: () => import('@/merchant-bd/pages/business/performance/record'),
        meta: {
            title: '交易记录'
        }
    },
    {
        path: '/business/performance/exploit',
        name: '/business/performance/exploit',
        component: () => import('@/merchant-bd/pages/business/performance/exploit'),
        meta: {
            title: '拓店追踪'
        }
    }
]

export default router
