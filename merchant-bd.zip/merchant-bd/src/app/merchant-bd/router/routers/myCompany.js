/**
 * ! 代理系统 路由
 * ? 我的企业 
 * 
 * @param {}
 */

const router = [
    // 新增 代理系统页面 路由
    {
        path: '/company/myCompany',
        name: 'myCompany',
        component: () => import('@/merchant-bd/pages/business/company/myCompany'),
        meta: {
            hideReturn: true,
            title: '我的企业'
        }
    },
    {
        path: '/company/deliveryAddress',
        name: 'deliveryAddress',
        component: () => import('@/merchant-bd/pages/business/company/deliveryAddress'),
        meta: {
            title: '企业信息'
        }
    },
    {
        path: '/company/agencyArea',
        name: 'agencyArea',
        component: () => import('@/merchant-bd/pages/business/company/agencyArea'),
        meta: {
            title: '代理区域'
        }
    },
    {
        path: '/company/agencyShop',
        name: 'agencyShop',
        component: () => import('@/merchant-bd/pages/business/company/agencyShop'),
        meta: {
            title: '代理企业对公户'
        }
    },
    {
        path: '/company/addWorker',
        name: 'addWorker',
        component: () => import('@/merchant-bd/pages/business/company/addWorker'),
        meta: {
            title: '新增员工'
        }
    },
    {
        path: '/company/result',
        name: 'result',
        component: () => import('@/merchant-bd/pages/business/company/result'),
        meta: {
            title: '新增员工'
        }
    },
    {
        path: '/company/accounts',
        name: 'accounts',
        component: () => import('@/merchant-bd/pages/business/company/accounts'),
        meta: {
            title: '员工账户管理'
        }
    }
]

export default router
