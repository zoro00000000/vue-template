/**
 * ! 代理系统 路由
 * ? 公共页面路由 
 * 
 * @param {}
 */

const router = [
    {
        path: '/permission/error',
        name: '/permission/error',
        component: () => import('@/merchant-bd/pages/error/noAccess'),
        meta: {
            hideReturn: true,
            title: '暂无权限'
        }
    }
]

export default router
