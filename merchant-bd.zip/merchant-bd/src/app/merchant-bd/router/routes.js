/*
 * @Author: ZYZ
 * @Date: 2020-01-02 09:48:38
 * @LastEditTime: 2020-03-31 15:14:03
 * @LastEditors: Zhaoyongzhen
 * @Description: In User Settings Edit
 * @FilePath: /job/campus-consumer/develop/merchant-bd/src/router/routes.js
 */

import report from './routers/report'
import business from './routers/business'
import myCompany from './routers/myCompany'
import common from './routers/common'
import merchant from './routers/merchant'
import white from './routers/white'

const routers = [].concat(
    report,
    business,
    myCompany,
    common,
    merchant,
    white
)

export default routers
