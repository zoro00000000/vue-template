import axios from 'axios'
import { Toast } from 'vant'

import Router from 'vue-router'

import { getQueryString } from '../utils/getQueryString'

import filterRepetition from './filterRepetition'

// const getQueryString = require('../utils/getQueryString')


// 生产
let apiHostname = ''
let uploadImageHost = ''
console.log('process.env---->', process.env)
if (process.env.VUE_APP_BUILD_ENV === 'dev') {
    // ! 开发环境 dev
    apiHostname = '//mstest.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else if (process.env.VUE_APP_BUILD_ENV === 'test') {
    // ! 测试环境 test
    // apiHostname = '//ms.jr.jd.com/gw/generic/bt/h5/m'
    apiHostname = '//mstest.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else if (process.env.VUE_APP_BUILD_ENV === 'staging') {
    // ! 预发环境 staging
    apiHostname = '//msinner.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else if (process.env.VUE_APP_BUILD_ENV === 'online') {
    // ! 线上环境 online
    apiHostname = '//ms.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else {
    apiHostname = '//ms.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
}
export const apiUrl = {
    /**
     * 相册api
     */
    uploadImage: `${uploadImageHost}0/b1eb963204b948e899ba458c683b59ef`,
    /**
     * 增加商家api
     * 1. queryMerchantIndustry 查询行业资质列表
     * 2. queryBDMerchantBusinessRange 经营范围
     */
    querySchoolList: `${apiHostname}/queryBDSchoolInfoListByCoordinate`,
    queryMerchantIndustry: `${apiHostname}/queryBDMerchantTypeList`,
    queryBDMerchantBusinessRange: `${apiHostname}/queryBDMerchantBusinessRange`,
    queryBDLevAddressList: `${apiHostname}/queryBDLevAddressList`,
    queryBDMerchantBusinessDiscountLimit: `${apiHostname}/queryBDMerchantBusinessDiscountLimit`,
    generateVenderId: `${apiHostname}/generateVenderId`,
    createBdVender: `${apiHostname}/createBdVender`,
    updateBdVender: `${apiHostname}/updateBdVender`,
    /**
     * 主管战报
     */
    queryBDUserInfoByERP: `${apiHostname}/queryBDUserInfoByERP`, // 据用户erp 查询用户职位信息
    queryBDManagerReportInfoByERP: `${apiHostname}/queryBDManagerReportInfoByERP`, // 大区主管战报
    queryBDProvinceManagerReportInfoByERP: `${apiHostname}/queryBDProvinceManagerReportInfoByERP`, // 省主管战报
    queryBDNumberReportInfoByERP: `${apiHostname}/queryBDNumberReportInfoByERP`, // 省专员战报
    queryCircleTradeInfoByERP: `${apiHostname}/queryCircleTradeInfoByERP`, // 按照时间查询部门的充值数，交易数
    // 个人战报汇总信息
    queryPersonalSummarReport: `${apiHostname}/queryPersonalSummarReport`,
    queryPersonalReport: `${apiHostname}/queryPersonalReport`, // 个人页面 基础信息
    // merchant 商家
    queryBDMerchantBaseInfo: `${apiHostname}/queryBDMerchantBaseInfo`,
    // 商家相册
    queryBDMerchantAlbumInfo: `${apiHostname}/queryBDMerchantAlbumInfo`,
    queryBDMerchantOtherImageAlbumInfo: `${apiHostname}/queryBDMerchantOtherImageAlbumInfo`,
    // 下属信息
    queryBDUserNumberInfoByERP: `${apiHostname}/queryBDUserNumberInfoByERP`,
    // 查询商户的历史记录
    searchBDRecordByType: `${apiHostname}/searchBDRecordByType`,
    // 新增访问记录
    createBDRecord: `${apiHostname}/createBDRecord`,
    // 充值明细
    queryBDMerchantRechargeFlowList: `${apiHostname}/queryBDMerchantRechargeFlowList`,
    // 交易流水明细
    queryBDMerchantRevenueFlowList: `${apiHostname}/queryBDMerchantRevenueFlowList`,
    // 查询商户绑定的合伙人邀请码
    queryBDBindPartnerCode: `${apiHostname}/queryBDBindPartnerCode`,
    // 查询商户绑定的合伙人邀请码历史
    queryBDPartnerCodeBindHistory: `${apiHostname}/queryBDPartnerCodeBindHistory`,
    // 通过合伙人邀请码查询用户pin
    queryBDPinByPartnerCode: `${apiHostname}/queryBDPinByPartnerCode`,
    // 绑定合伙人邀请码
    bindBDPartnerCode: `${apiHostname}/bindBDPartnerCode`,
    // 查询机构信息列表（代理服务）
    queryBDOrganInfoByOrganId: `${apiHostname}/queryBDOrganInfoByOrganId`,
    // 查询机构信息列表
    queryBDOrganInfoByPin: `${apiHostname}/queryBDOrganInfoByPin`,
    // 查询机构代理区域
    // 查询机构信息列表
    queryBDOrganInfo: `${apiHostname}/queryBDOrganInfo`,
    // 查询机构代理区域
    queryBDOrganRegion: `${apiHostname}/queryBDOrganRegion`,
    // 新增员工记录
    addBDStaffInfo: `${apiHostname}/addBDStaffInfo`,
    // 查询员工服务
    queryBDStaffInfo: `${apiHostname}/queryBDStaffInfo`,
    // 查询员工服务
    querySettleFlowById: `${apiHostname}/querySettleFlowById`,
    // 确认佣金
    modifyModifySettle: `${apiHostname}/modifyModifySettle`,
    // 申请打款
    updateModifySettle: `${apiHostname}/updateModifySettle`,
    // 操作记录列表
    queryRecordDataList: `${apiHostname}/queryRecordDataList`,
    // 填写快递单号
    addMailNumReq: `${apiHostname}/addMailNumReq`,
    // 添加差异结算单
    addDiffSettleFlow: `${apiHostname}/addDiffSettleFlow`,
    // ORC身份证识别接口
    ocrBDIdCard: `${apiHostname}/ocrBDIdCard`,
    // 新增 代理系统 查看 商户详情
    queryAgentMerchantBaseInfo: `${apiHostname}/queryAgentMerchantBaseInfo`
}

function defaultErrorFn (error) {
    if (error.response) {
        console.log('defaultErrorFn')
        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
        console.log('errorData', error.response.data)
        console.log('errorStatus', error.response.status)
        console.log('errorHeader', error.response.headers)
    } else {
        // Toast({message: '网络连接异常'})
        console.log('defaultErrorFn')
        console.log('Error', error)
    }
}

/*
 * 创建异步实例 定义默认参数*
 *axiosInsImage  上传图片 不走网关
 * */
const axiosIns = axios.create({
    timeout: 5000,
    withCredentials: true
})
const axiosInsImage = axios.create({
    timeout: 25000,
    withCredentials: true
})
// 设置全局的请求次数，请求的间隙
axiosIns.defaults.retry = 3
axiosIns.defaults.retryDelay = 1000

// TODO: 新增数据
// 正在进行中的请求列表
export const reqList = []

/**
 * 阻止重复请求
 * @param {array} reqList - 请求缓存列表
 * @param {string} url - 当前请求地址
 * @param {function} cancel - 请求中断函数
 * @param {string} errorMessage - 请求中断时需要显示的错误信息
 */
const stopRepeatRequest = function (requestList, url, cancel, errorMessage) {
    const errorMsg = errorMessage || ''
    for (let i = 0; i < requestList.length; i++) {
        if (requestList[i].url === url && (filterRepetition.indexOf(url.replace(`${apiHostname}/`, ''))) >= 0) {
            console.log('取消接口')
            requestList[i].cancel(errorMsg)
        }
    }
    reqList.push({
        url,
        cancel
    })
    // console.log(reqList)
}

/**
 * 允许某个请求可以继续进行
 * @param {array} reqList 全部请求列表
 * @param {string} url 请求地址
 */
const allowRequest = function (requestList, url) {
    for (let i = 0; i < requestList.length; i++) {
        if (requestList[i].url === url) {
            reqList.splice(i, 1)
            // break
        }
    }
}

// 添加请求拦截器
axiosIns.interceptors.request.use(config => {
    let cancel
    // 设置cancelToken对象
    config.cancelToken = new axios.CancelToken((c => {
        cancel = c
    }))
    // 阻止重复请求。当上个请求未完成时，相同的请求不会进行
    stopRepeatRequest(reqList, config.url, cancel, `${config.url}`)

    // 一些配置项
    if (config.config) {
        for (const item in config.config) {
            config[item] = config.config[item]
        }
        if (config.config.cache) {
            config.url += /\?/g.test(config.url) ? `&_=${new Date().getTime()}` : `?_=${new Date().getTime()}`
        }
    }
    // 在发送请求之前做些什么
    // 这里可以添加loading效果
    return config
}, error => Promise.reject(error))
// 登录链接
// let loginUrl = 'https://plogin.m.jd.com/user/login.action?appid=474&returnurl='
// let currentUrl = window.location.href
axiosIns.interceptors.response.use(response => {
    // 增加延迟，相同请求不得在短时间内重复发送
    // setTimeout(() => {
    //     allowRequest(reqList, response.config.url)
    // }, 100)
    allowRequest(reqList, response.config.url)

    const result = response.data
    // let resultData = result.resultData
    const always = (response.config.config && response.config.config.always) ? response.config.config.always : false
    
    // 网关接口响应失败
    if (!always) {
        if (result.resultCode && result.resultCode !== 0) {
            // 未登录
            if (result.resultCode === 3) {
                Toast('未登陆')
                // const localUrl = encodeURIComponent(window.location.href)
                const localUrl = encodeURIComponent(`${window.location.protocol}//${window.location.host}${window.location.pathname}#/business/performance/company`)
                // window.location.href = `https://plogin.m.jd.com/user/login.action?appid=566&returnurl=${localUrl}`
                const newUrl = `//plogin.m.jd.com/user/login.action?appid=566&wxautologin=false&returnurl=${localUrl}`
                window.location.href = newUrl

                console.log('已经走完跳转2')
                // window.location.href = loginUrl + encodeURIComponent(currentUrl)
                return response
            } else {
                Toast('系统异常，请稍后重试~~')
                // 接口异常上报
                // unionlogErrorReport(response, errorMsg + '(' + result.resultCode + ')')
            }
            return false
        }
    } else if (result.resultData.result.code === '0007' || getQueryString('logoutstatus') === 'false') {
        Router.push('/permission/error')
    }

    return response
}, error => {
    // 请求错误时做些事
    if (axios.isCancel(error)) {
        console.log(error.message)
        // allowRequest(reqList, error.message)
        return Promise.reject(error)
    } else {
        console.log(error)
        // 增加延迟，相同请求不得在短时间内重复发送
        // setTimeout(() => {
        //     allowRequest(reqList, error.config.url)
        // }, 100)
        allowRequest(reqList, error.config.url)
    }

    // 请求超时的之后，抛出 error.code = ECONNABORTED的错误..错误信息是 timeout of  xxx ms exceeded
    if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) {
        const { config } = error
        config.__retryCount = config.__retryCount || 0
        if (config.__retryCount >= config.retry) {
            // Reject with the error
            // window.location.reload()
            return Promise.reject(error)
        }
        // Increase the retry count
        config.__retryCount += 1
        // Create new promise to handle exponential backoff
        const backoff = new Promise((resolve => {
            setTimeout(() => {
                // console.log('resolve')
                resolve()
            }, config.retryDelay || 1)
        }))
        return backoff.then(() => axiosIns(config))
    } else {
        Toast('系统异常，请稍后重试~~')
        return Promise.reject(error)
    }
})

axiosInsImage.interceptors.response.use(response => {
    const result = response.data
    return result
}, error => {
    // 请求错误时做些事
    // 请求超时的之后，抛出 error.code = ECONNABORTED的错误..错误信息是 timeout of  xxx ms exceeded
    if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) {
        const { config } = error
        config.__retryCount = config.__retryCount || 0
        if (config.__retryCount >= config.retry) {
            // Reject with the error
            // window.location.reload()
            return Promise.reject(error)
        }
        // Increase the retry count
        config.__retryCount += 1
        // Create new promise to handle exponential backoff
        const backoff = new Promise((resolve => {
            setTimeout(() => {
                // console.log('resolve')
                resolve()
            }, config.retryDelay || 1)
        }))
        return backoff.then(() => axiosIns(config))
    } else {
        console.log(error)
        Toast('系统异常，请稍后重试~~')
        return Promise.reject(error)
    }
})

export const fetch = {
    post (params, successCb, errorCb) {
        let paramData = {}
        // 先从cookie里读取 staffId  后面如果接口自己传了再覆盖当前这个
        if (localStorage.getItem('staffId')) paramData.staffId = JSON.parse(localStorage.getItem('staffId'))
        
        // 是否需要 organId 这个参数
        if (params.data.needOrganId !== undefined && params.data.needOrganId === false) {
            delete params.data.organId
            // paramData = { ...params.data }
            paramData = Object.assign(paramData, params.data)
        } else {
            paramData.organId = JSON.parse(localStorage.getItem('organId'))
            paramData = Object.assign(paramData, params.data)
        }
        const requestData = `reqData=${JSON.stringify(paramData)}`
        return axiosIns({
            method: 'post',
            url: params.url,
            data: requestData
        }).then(res => {
            successCb && successCb(res.data.resultData)
        }).catch(error => {
            console.log('post请求 network 报错')
            if (errorCb) {
                errorCb(error)
            } else {
                defaultErrorFn(error)
            }
            return Promise.reject()
        })
    },
    /**
     * 上传ORC
     * @param {*} params 
     * @param {*} successCb 
     * @param {*} errorCb 
     */
    postOCRImage (params, successCb, errorCb) {
        const paramData = `reqData=${encodeURIComponent(JSON.stringify(params.data))}`
        return axiosIns({
            method: 'post',
            url: params.url,
            data: paramData
        }).then(res => {
            console.log('res:', res)
            if (res.status === 200) {
                successCb && successCb(res.data)
            } else {
                return Promise.reject()
            }
        }).catch(error => {
            Toast('上传失败,图片格式有误')
            if (errorCb) {
                errorCb(error)
            } else {
                defaultErrorFn(error)
            }
            return Promise.reject(error)
        })
    },
    postImage (params, successCb, errorCb) {
        const paramData = params.data || {}
        return axiosInsImage({
            method: 'post',
            url: params.url,
            data: paramData,
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then(res => {
            if (res.id === '1') {
                successCb && successCb(res)
            } else {
                return Promise.reject()
            }
        }).catch(error => {
            Toast('上传失败,图片格式有误')
            if (errorCb) {
                errorCb(error)
            } else {
                defaultErrorFn(error)
            }
            return Promise.reject()
        })
    },
    get (params, successCb, errorCb) {
        // 序列化入参 网关入参格式
        const paramData = params.data || {}
        const requestData = {
            reqData: paramData
        }
        // get
        return axiosIns({
            method: 'get',
            url: params.url,
            config: params.config || null,
            params: requestData
        }).then(res => {
            const { config } = params
            // 特殊数据格式
            if (config && config.always) {
                successCb && successCb(res.data)
                return
            }
            // 网关返回的 code != 0 时，因为上面 返回的是 false， 其会走到该分支 也就是说 res可能等于 false
            if (!res) {
                // console.log("error")
                // successCb && successCb({})
                errorCb && errorCb({})
                return
            } else if (res && res.data.resultCode == 3) {
                // 网关未登录
                // console.log('res')
                // console.log(res)
                errorCb && errorCb(res.data) // 未登录按照错误处理流程搞
                return
            }
            successCb && successCb(res.data.resultData)
        }).catch(error => {
            // 网络请求发生未知错误
            if (errorCb) {
                errorCb(error)
            } else {
                defaultErrorFn(error)
            }
        })
    },
    mget (url) {
        return axios.get(url)
    },
    spread (cb) {
        return axios.spread(cb)
    },
    all (getArry, cb) {
        axios.all(getArry).then(fetch.spread(cb))
    }
}
