export default [
    // 代理系统新增接口
    'queryBDStaffInfoByPin',
    'queryBDStaffInfo',
    'queryBDStaffInfoByStaffId',
    'getBDOrganBaseSummary',
    'queryBDOrganMerchant',
    'getBDCommissionRecord',
    'getBDOrganSummary',
    'getBDStaffAchievement',
    'getBDOrganPersonSummary',
    'queryBDAchievementTrack',
    'queryBDMerchantOrderRecord',
    'queryBDNumberReportInfoByERP',
    'getBDAgentStaffMerReport',
    'getBDPersonCommissionRecord',
    'getCheckStaffPinFit',
    // 佣金部分接口
    'queryAddInfoByCityId',
    'waitConfirm',
    'queryBDMerchantRevenueFlowList',
    // 我的企业
    'listComnQuestion',
    // 管理员工
    'queryBDOrganMerchant',
    'queryBDStaffInfo',
    'updateBDMerchantAgent',
    'getBDStaffChangeRecord',
    'updateBDStaffInfo',
    'updateBDStaffInfoFreeze',
    'waitConfirm',
    // 原BD项目更换的接口
    'queryAgentMerchantBaseInfo',
    'createAgentVender',
    'updateAgentVender',
    'createAgentRecord',
    'queryAgentMerchantRevenueFlowList',
    'queryAgentMerchantRechargeFlowList'
]
