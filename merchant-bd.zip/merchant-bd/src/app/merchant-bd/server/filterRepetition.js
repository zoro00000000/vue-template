/** 
 * 需要处理重复请求的 接口
 */

export default [
    // 代理系统新增接口
    'queryBDNumberReportInfoByERP',
    'queryBDAchievementTrack'
]
