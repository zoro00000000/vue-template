import { fetch } from '@/merchant-bd/server/getData'
import { timestampToYear } from '@/merchant-bd/utils/tools'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`
/**
 * 商户管理-查询机构信息列表
 * @param param
 * @return {*}
 */
export function queryBDOrganMerchant (param, callBack) {
    return fetch.post({
        url: `${apiHostname}queryBDOrganMerchant`,
        data: {
            ...param
        }
    }, res => {
        res.data.forEach(item => {
            item.createTime = timestampToYear(item.createTime, 'Y/m/d')
        })
        quest(res, callBack)
    })
}

/**
 * 商户管理-员工变更列表
 * @param param
 * @return {*}
 */
export function queryBDStaffInfo (param, callBack) {
    return fetch.post({
        url: `${apiHostname}queryBDStaffInfo`,
        data: {
            ...param
        }
    }, res => {
        res.data.forEach((item, index) => {
            item.key = (param.currentPage - 1) * 10 + index
            item.disabled = !!item.freeze 
            item.createTime = timestampToYear(item.createTime, 'Y/m/d')
            item.rename = `${item.name}(${item.phone.substr(7, 11)})`
        })
        quest(res, callBack)
    })
}

/**
 * 商户管理-据ID查询员工信息
 * @param param
 * @return {*}
 */
export function queryBDStaffInfoByStaffId (param, callBack) {
    return fetch.post({
        url: `${apiHostname}queryBDStaffInfoByStaffId`,
        data: {
            ...param
        }
    }, res => {
        res.data.disabled = !!res.data.freeze 
        res.data.createTime = timestampToYear(res.data.createTime, 'Y/m/d')
        res.data.rename = `${res.data.name}(${res.data.phone.substr(7, 11)})`
        quest(res, callBack)
    })
}

/**
 * 商户管理-员工变更提交
 * @param param
 * @return {*}
 */
export function updateBDMerchantAgent (param, callBack) {
    return fetch.post({
        url: `${apiHostname}updateBDMerchantAgent`,
        data: {
            ...param
        }
    }, res => {
        quest(res, callBack)
    })
}

/**
 * 商户管理-员工变更记录
 * @param param
 * @return {*}
 */
export function getBDStaffChangeRecord (param, callBack) {
    return fetch.post({
        url: `${apiHostname}getBDStaffChangeRecord`,
        data: {
            ...param
        }
    }, res => {
        const newRes = {
            data: [],
            result: {}
        }
        res.data.forEach(item => {
            newRes.data.push({ 
                to: `${item.to}(${item.toPhone.substr(7, 11)})`, 
                from: `${item.from}(${item.fromPhone.substr(7, 11)})`, 
                createTime: timestampToYear(item.createTime, 'Y/m/d') 
            })
        })
        newRes.result = res.result
        quest(newRes, callBack)
    })
}

/**
 * 新增员工-更新用户状态
 * @param param
 * @return {*}
 */
export function updateBDStaffInfo (param, callBack) {
    return fetch.post({
        url: `${apiHostname}updateBDStaffInfo`,
        data: {
            ...param
        }
    }, res => {
        quest(res, callBack)
    })
}

/**
 * 商户管理-员工变更列表-员工冻结解冻
 * @param param
 * @return {*}
 */
export function updateBDStaffInfoFreeze (param, callBack) {
    return fetch.post({
        url: `${apiHostname}updateBDStaffInfoFreeze`,
        data: {
            ...param
        }
    }, res => {
        quest(res, callBack)
    })
}

/**
 * 佣金待核-城市列表
 * @param param
 * @return {*}
 */
export function waitConfirm (param, callBack) {
    return fetch.post({
        url: `${apiHostname}waitConfirm`,
        data: {
            ...param
        }
    }, res => {
        console.log(res)
        quest(res, callBack)
    })
}
