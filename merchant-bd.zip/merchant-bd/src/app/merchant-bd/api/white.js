import { fetch } from '@/merchant-bd/server/getData'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`

/**
 * 白名单（代理）
 * ?接口（10.6）
 * 查询商户设置的白名单
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryAgentSchoolWhiteList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryAgentSchoolWhiteList`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 白名单（代理）
 * ?接口（10.6）
 * 新增白名单
 * @param {*} param 
 * @param {*} callBack 
 */
export const addAgentCampusWhiteList = (param, callBack) => fetch.post({
    url: `${apiHostname}addAgentCampusWhiteList`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 白名单（BD）
 * ?接口（10.6）
 * 查询商户设置的白名单
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDSchoolWhiteList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDSchoolWhiteList`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 白名单（BD）
 * ?接口（10.6）
 * 新增白名单
 * @param {*} param 
 * @param {*} callBack 
 */
export const addBDCampusWhiteList = (param, callBack) => fetch.post({
    url: `${apiHostname}addBDCampusWhiteList`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 白名单（BD）
 * ?接口（3.1）
 * 根据四级地址查询学校信息列表【待补充，没有数据源】
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDSchoolInfoListByLevAddr = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDSchoolInfoListByLevAddr`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})
