import { apiUrl, fetch } from '@/merchant-bd/server/getData'

/**
 * 13. 查询四级地址
 * @param param
 * @return {*}
 */
export function queryAdress (param, callBack) {
    return fetch.get({
        url: apiUrl.queryBDLevAddressList,
        data: {
            ...param
        }
    }, res => {
        callBack && callBack(res)
    })
}

/**
 * 18.上传图片
 * @param param
 * @return {*}
 */
export function uploadImage (param, callBack) {
    return fetch.postImage({
        url: apiUrl.uploadImage,
        data: param
    }, res => {
        console.log('愿返回---', res)
        callBack && callBack(res)
    }, e => {
        console.log('失败---', e)

        Promise.reject()
    })
}

/**
 * 3.4 身份证ORC识别
 * @param param
 * @return {*}
 */
export function uploadImageORC (param, callBack) {
    return fetch.postOCRImage({
        url: apiUrl.ocrBDIdCard,
        data: param
    }, res => {
        console.log('愿返回---', res)
        callBack && callBack(res)
    }, e => {
        console.log('失败---', e)
        Promise.reject()
    })
}
