import * as performance from './performance'
import * as commission from './commission'
import * as newBusiness from './newBusiness'
import * as company from './company'
import * as white from './white'
import * as merchant from './merchant'

export default {
    performance,
    commission,
    newBusiness,
    company,
    merchant,
    white
}
