import { fetch } from '@/merchant-bd/server/getData'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`

/**
 * 代理系统
 * ?接口（6.10）
 * 获取员工基本信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDStaffInfoByPin = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDStaffInfoByPin`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（6.1）
 * 获取员工基本信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDStaffInfo = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDStaffInfo`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（6.8）
 * 获取员工基本信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDStaffInfoByStaffId = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDStaffInfoByStaffId`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.12）
 * @param {*} param 
 * @param {*} callBack 
 */
export const getBDOrganBaseSummary = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDOrganBaseSummary`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 代理系统
 * 商家机构信息
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */

export const queryBDOrganMerchant = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDOrganMerchant`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.1）
 * 佣金数据(echart 数据)
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getBDCommissionRecord = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDCommissionRecord`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.10）
 * 员工业绩——总计
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getBDOrganSummary = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDOrganSummary`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.2）
 * 员工业绩——员工列表
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getBDStaffAchievement = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDStaffAchievement`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * ! 这个接口需要修改
 * 代理系统
 * ?接口（7.11）
 * 代理人的——商户数据
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getBDOrganPersonSummary = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDOrganPersonSummary`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.8）
 * 个人的——业绩追踪
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryBDAchievementTrack = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDAchievementTrack`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.9）
 * 个人的——商户交易记录
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryBDMerchantOrderRecord = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantOrderRecord`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.5）
 * 个人的——查询商户状态
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getBDAgentStaffMerReport = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDAgentStaffMerReport`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（1.5）
 * 个人的——查询商户列表
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryBDNumberReportInfoByERP = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDNumberReportInfoByERP`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.4）
 * 个人——佣金数据(echart 数据)
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getBDPersonCommissionRecord = (param, callBack) => fetch.post({
    url: `${apiHostname}getBDPersonCommissionRecord`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.4）
 * 全局——判断登录态接口
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const getCheckStaffPinFit = (param, callBack) => fetch.post({
    url: `${apiHostname}checkStaffPinFit`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（7.13）
 * 个人——新业绩追踪接口
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryBDAchievementTrackList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDAchievementTrackList`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})
