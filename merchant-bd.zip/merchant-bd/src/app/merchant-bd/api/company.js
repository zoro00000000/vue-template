import { fetch } from '@/merchant-bd/server/getData'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`

/**
 * 代理系统
 * ?接口（6.10）
 * 获取常见问题
 * @param {*} param 
 * @param {*} callBack 
 */
export const listComnQuestion = (param, callBack) => fetch.post({
    url: `${apiHostname}listComnQuestion`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})
