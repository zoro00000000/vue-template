import { fetch } from '@/merchant-bd/server/getData'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`

/**
 * 代理系统
 * ?接口（11.1）
 * 资质上传——查看商家信息
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryAgentMerchantBaseInfo = (param, callBack) => fetch.post({
    url: `${apiHostname}queryAgentMerchantBaseInfo`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（12.11）
 * 资质上传——提交商家资质信息
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const createAgentVender = (param, callBack) => fetch.post({
    url: `${apiHostname}createAgentVender`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（12.12）
 * 资质上传——修改商家资质
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const updateAgentVender = (param, callBack) => fetch.post({
    url: `${apiHostname}updateAgentVender`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（12.13）
 * 商户详情——添加访问记录
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const createAgentRecord = (param, callBack) => fetch.post({
    url: `${apiHostname}createAgentRecord`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（9.1）
 * 商户详情——交易记录
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryAgentMerchantRevenueFlowList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryAgentMerchantRevenueFlowList`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
}, e => {
    Promise.reject(e)
})

/**
 * 代理系统
 * ?接口（9.2）
 * 商户详情——充值记录
 * @export
 * @param {*} param
 * @param {*} callBack
 * @returns
 */
export const queryAgentMerchantRechargeFlowList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryAgentMerchantRechargeFlowList`,
    data: {
        ...param
    }
}, res => {
    // callBack && callBack(res)
    quest(res, callBack)
}, e => {
    Promise.reject(e)
})
