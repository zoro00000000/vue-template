import { Toast } from 'vant'
// 生产
let apiHostname = ''
let uploadImageHost = ''
// console.log(process.env)
// console.log('process.env---->', process.env)
if (process.env.VUE_APP_BUILD_ENV === 'dev') {
    // ! 开发环境 dev
    apiHostname = '//mstest.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else if (process.env.VUE_APP_BUILD_ENV === 'test') {
    // ! 测试环境 test
    // apiHostname = '//ms.jr.jd.com/gw/generic/bt/h5/m'
    apiHostname = '//mstest.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else if (process.env.VUE_APP_BUILD_ENV === 'staging') {
    // ! 预发环境 staging
    apiHostname = '//msinner.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else if (process.env.VUE_APP_BUILD_ENV === 'online') {
    // ! 线上环境 online
    apiHostname = '//ms.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
} else {
    apiHostname = '//ms.jr.jd.com/gw/generic/bt/h5/m'
    uploadImageHost = 'https://pic.jd.com/'
}

export const apiUrl = {
    apiHostname,
    uploadImageHost
}

export function quest (res, callBack) {
    if (res.result.code == '0000') {
        callBack && callBack(res)
    } else {
        Toast(res.result.info)
    }    
}
