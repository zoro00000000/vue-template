import { fetch } from '@/merchant-bd/server/getData'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`

/**
 * BD系统
 * 
 * ?接口（4.3）
 * 查看商家经营范围列表
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantBusinessRange = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantBusinessRange`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.2）
 * 查看商家类型列表
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantTypeList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantTypeList`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.10）
 * 获取商户ID
 * @param {*} param 
 * @param {*} callBack 
 */
export const generateVenderId = (param, callBack) => fetch.post({
    url: `${apiHostname}generateVenderId`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.1）
 * 查看商家基本信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantBaseInfo = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantBaseInfo`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.5）
 * 查看商家相册信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantAlbumInfo = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantAlbumInfo`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.13）
 * 查看商家其他相册信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantOtherImageAlbumInfo = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantOtherImageAlbumInfo`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.11）
 * 提交商家资质信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const createBdVender = (param, callBack) => fetch.post({
    url: `${apiHostname}createBdVender`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（4.12）
 * 更新商家资质信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const updateBdVender = (param, callBack) => fetch.post({
    url: `${apiHostname}updateBdVender`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（3.3）
 * 根据经纬度坐标查询学校信息列表
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDSchoolInfoListByCoordinate = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDSchoolInfoListByCoordinate`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * BD系统
 * 
 * ?接口（5.1）
 * 查询商家行业最低折扣信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantBusinessDiscountLimit = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantBusinessDiscountLimit`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})
