import { fetch } from '@/merchant-bd/server/getData'
import { apiUrl, quest } from './hostUrl'

const apiHostname = `${apiUrl.apiHostname}/`

/**
 * 代理系统
 * ?接口（8.10）
 * 待核佣金——各级别城市拓店信息
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryAddInfoByCityId = (param, callBack) => fetch.post({
    url: `${apiHostname}queryAddInfoByCityId`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（8.7）
 * 待核佣金——商户交易
 * @param {*} param 
 * @param {*} callBack 
 */
export const waitConfirm = (param, callBack) => fetch.post({
    url: `${apiHostname}waitConfirm`,
    data: {
        ...param
    }
}, res => {
    quest(res, callBack)
})

/**
 * 代理系统
 * ?接口（）
 * 商户交易
 * @param {*} param 
 * @param {*} callBack 
 */
export const queryBDMerchantRevenueFlowList = (param, callBack) => fetch.post({
    url: `${apiHostname}queryBDMerchantRevenueFlowList`,
    data: {
        needOrganId: false,
        ...param
    }
}, res => { 
    quest(res, callBack)
})
