/*
 * @Date: 2020-02-28 16:43:04
 * @LastEditors: Zhaoyongzhen
 * @LastEditTime: 2020-03-09 11:35:56
 */
import Vue from 'vue'
import {
    Divider,
    DropdownMenu,
    DropdownItem,
    Dialog,
    Popup,
    Toast,
    Cell,
    CellGroup,
    Uploader,
    Field,
    Icon,
    Picker,
    Button,
    Overlay,
    Collapse,
    CollapseItem,
    List,
    Search,
    Radio,
    RadioGroup,
    IndexBar, 
    IndexAnchor,
    Form,
    DatetimePicker,
    Loading,
    Switch,
    Checkbox, 
    CheckboxGroup
} from 'vant'
import VConsole from 'vconsole'
import router from '@/merchant-bd/router'
import App from './App.vue'
import 'vant/lib/index.less'
// import router from './router'
import filter from './utils/filters'
import '@/merchant-bd/assets/css/_base.less'

Vue.use(filter)
Vue.config.productionTip = false
const compoments = [
    Divider,
    DropdownItem,
    DropdownMenu,
    Dialog,
    Popup,
    Toast,
    Cell,
    CellGroup,
    Uploader,
    Field,
    Icon,
    Picker,
    Button,
    Overlay,
    Collapse,
    CollapseItem,
    List,
    Search,
    Radio,
    RadioGroup,
    IndexBar, 
    IndexAnchor,
    Form,
    DatetimePicker,
    Loading,
    Switch,
    Checkbox, 
    CheckboxGroup
]

// 除online情况下 显示 vconsolelog
if (process.env.VUE_APP_BUILD_ENV === 'dev_mobile') {
    // !，在pc上调试的时候 影响了映射源文件
    new VConsole()
}

compoments.forEach(component => {
    Vue.use(component)
    Vue.component(component.name, component)
})

// 全局注册自定义指令————将 string html 插入到 dom 指令
Vue.directive('vueInnerHtml', {      
    bind (el, val) {
        // console.log(el, val)
        el.innerHTML += val.value
    }
})

new Vue({
    render: h => h(App),
    router
}).$mount('#app')
